package com.nocluetool.activation.code;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import java.security.MessageDigest;

public class SecurityCheck {

    // 👇 REPLACE THIS WITH YOUR ACTUAL HASH 👇
    private static final String EXPECTED_SHA256 = "82ac04dbcc62cc902503d944f3a23c6dd460fa2d5aec22f076be8316b2434d8c";

    public static boolean isAppTampered(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), PackageManager.GET_SIGNATURES);
            
            for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(signature.toByteArray());
                byte[] digest = md.digest();
                
                StringBuilder toHexString = new StringBuilder();
                for (byte b : digest) {
                    toHexString.append(String.format("%02x", b));
                }
                
                String currentHash = toHexString.toString();

                if (currentHash.equalsIgnoreCase(EXPECTED_SHA256)) {
                    return false; // Safe
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true; // Tampered
    }
}