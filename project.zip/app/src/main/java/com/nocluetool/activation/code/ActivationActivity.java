package com.nocluetool.activation.code;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.nocluetools.pro.MainActivity;
import com.nocluetools.pro.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ActivationActivity extends AppCompatActivity {

    // 🚨 YOUR FIREBASE URL
    private static final String FIREBASE_URL = "https://nocluetoolscodegenerator-default-rtdb.asia-southeast1.firebasedatabase.app/codes/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_activation);

// 👇 SAFE FULL SCREEN CODE 👇
getWindow().getDecorView().setSystemUiVisibility(
        android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
        | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
// 👆 END SAFE FULL SCREEN CODE 👆

        // 1. Check if already activated
        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        if (prefs.getBoolean("is_activated", false)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        TextView tvDeviceName = findViewById(R.id.tvDeviceName);
        TextView tvAndroidInfo = findViewById(R.id.tvAndroidInfo);
        TextView tvDeviceId = findViewById(R.id.tvDeviceId);
        TextView btnCopyId = findViewById(R.id.btnCopyId);
        TextView btnExit = findViewById(R.id.btnExit);
        TextView btnClose = findViewById(R.id.btnClose);
        EditText etCode = findViewById(R.id.etCode);
        TextView btnActivate = findViewById(R.id.btnActivate);

        // 2. Get Device Info
        String deviceModel = Build.MANUFACTURER + " " + Build.MODEL;
        String androidVersion = "Android " + Build.VERSION.RELEASE + " • API " + Build.VERSION.SDK_INT;
        String deviceId = getHardwareDeviceId();

        tvDeviceName.setText(deviceModel);
        tvAndroidInfo.setText(androidVersion);
        tvDeviceId.setText("AID • " + deviceId);

        // 3. Copy AID Button
        btnCopyId.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Device ID", deviceId);
            if (clipboard != null) clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "AID Copied!", Toast.LENGTH_SHORT).show();
        });

        // 4. Exit / Close Buttons
        btnExit.setOnClickListener(v -> finishAffinity());
        btnClose.setOnClickListener(v -> finishAffinity());

        // 5. Activate Button
        btnActivate.setOnClickListener(v -> {
            String enteredCode = etCode.getText().toString().trim().toUpperCase();
            
            if (!enteredCode.startsWith("NOCLUE2K-") && enteredCode.length() > 0) {
                enteredCode = "NOCLUE2K-" + enteredCode;
            }

            if (enteredCode.length() < 10) {
                Toast.makeText(this, "Invalid Code Length", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isNetworkAvailable()) {
                Toast.makeText(this, "Internet required for first activation!", Toast.LENGTH_LONG).show();
                return;
            }

            btnActivate.setText("VERIFYING...");
            btnActivate.setEnabled(false);

            final String finalCodeToVerify = enteredCode;
            
            new Thread(() -> {
                String result = claimCode(finalCodeToVerify, deviceId);
                
                runOnUiThread(() -> {
                    btnActivate.setText("Activate");
                    btnActivate.setEnabled(true);

                    if (result.equals("SUCCESS")) {
    SharedPreferences.Editor editor = getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit();
    editor.putBoolean("is_activated", true);
    // 👇 ADD THIS LINE 👇
    editor.putString("activation_code", finalCodeToVerify); 
    editor.apply(); 
    
    Toast.makeText(this, "Activated Successfully!", Toast.LENGTH_SHORT).show();
    startActivity(new Intent(this, MainActivity.class));
    finish();
} else if (result.equals("ALREADY_USED")) {
                        Toast.makeText(this, "Error: This code is bundled with another device!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Invalid Code or Network Error.", Toast.LENGTH_LONG).show();
                    }
                });
            }).start();
        });
    }

    // --- NETWORK & FIREBASE LOGIC (Same as before) ---
    private String claimCode(String code, String deviceId) {
        try {
            URL url = new URL(FIREBASE_URL + code + ".json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) response.append(line);
            reader.close();
            String dbResponse = response.toString();

            if (dbResponse.equals("null")) return "INVALID";

            if (dbResponse.contains("UNCLAIMED")) {
                URL claimUrl = new URL(FIREBASE_URL + code + ".json");
                HttpURLConnection putConn = (HttpURLConnection) claimUrl.openConnection();
                putConn.setRequestMethod("PUT");
                putConn.setDoOutput(true);
                try (OutputStream os = putConn.getOutputStream()) {
                    byte[] input = ("\"" + deviceId + "\"").getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                if (putConn.getResponseCode() == 200) return "SUCCESS";
            } else if (dbResponse.contains(deviceId)) {
                return "SUCCESS";
            } else {
                return "ALREADY_USED";
            }
        } catch (Exception e) { e.printStackTrace(); }
        return "ERROR";
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    private String getHardwareDeviceId() {
        String hardwareInfo = Build.BOARD + Build.BRAND + Build.DEVICE + Build.HARDWARE +
                Build.MANUFACTURER + Build.MODEL + Build.PRODUCT;
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            byte[] hash = digest.digest(hardwareInfo.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().substring(0, 16);
        } catch (Exception e) { return "ERROR_ID"; }
    }
}