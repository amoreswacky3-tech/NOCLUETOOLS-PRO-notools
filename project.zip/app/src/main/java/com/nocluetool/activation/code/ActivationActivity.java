package com.nocluetool.activation.code;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.nocluetools.pro.MainActivity; // Imports your main app
import com.nocluetools.pro.R;           // Imports your main app layouts

import java.security.MessageDigest;

public class ActivationActivity extends AppCompatActivity {
    // 🚨 THIS MUST MATCH THE ADMIN APP 🚨
    public static final String SECRET_KEY = "N0_clu3_T00ls_d0_n0t_cr4ck_88590!@#"; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activation); // This layout goes in res/layout

        TextView tvDeviceId = findViewById(R.id.tvDeviceId);
        EditText etCode = findViewById(R.id.etCode);
        Button btnActivate = findViewById(R.id.btnActivate);

        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        tvDeviceId.setText("Device ID:\n" + deviceId);

        btnActivate.setOnClickListener(v -> {
            String enteredCode = etCode.getText().toString().trim().toUpperCase();
            if (enteredCode.equals(generateCode(deviceId))) {
                SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
                prefs.edit().putBoolean("is_activated", true).apply();
                
                Toast.makeText(this, "Activated Successfully!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid Code", Toast.LENGTH_LONG).show();
            }
        });
    }

    public static String generateCode(String deviceId) {
        try {
            String input = deviceId + SECRET_KEY;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().substring(0, 8).toUpperCase();
        } catch (Exception e) { return "ERROR"; }
    }
}