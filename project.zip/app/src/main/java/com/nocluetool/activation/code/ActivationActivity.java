package com.nocluetool.activation.code;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.nocluetools.pro.MainActivity;
import com.nocluetools.pro.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

public class ActivationActivity extends AppCompatActivity {

    // 🚨 PASTE YOUR FIREBASE URL HERE (Make sure it ends with /codes/ and a slash!)
    private static final String FIREBASE_URL = "https://nocluetoolscodegenerator-default-rtdb.asia-southeast1.firebasedatabase.app/codes/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activation);

        TextView tvDeviceId = findViewById(R.id.tvDeviceId);
        EditText etCode = findViewById(R.id.etCode);
        Button btnActivate = findViewById(R.id.btnActivate);

        String deviceId = getHardwareDeviceId();
        tvDeviceId.setText("Device ID:\n" + deviceId);

        btnActivate.setOnClickListener(v -> {
            String enteredCode = etCode.getText().toString().trim().toUpperCase();
            
            // If user forgot the prefix, add it automatically
            if (!enteredCode.startsWith("NOCLUE2K-") && enteredCode.length() > 0) {
                enteredCode = "NOCLUE2K-" + enteredCode;
            }

            if (enteredCode.length() < 10) {
                Toast.makeText(this, "Invalid Code Length", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isNetworkAvailable()) {
                Toast.makeText(this, "Internet required for first activation!", Toast.LENGTH_LONG).show();
                return;
            }

            btnActivate.setText("VERIFYING...");
            btnActivate.setEnabled(false);

            final String finalCodeToVerify = enteredCode;
            
            new Thread(() -> {
                String result = claimCode(finalCodeToVerify, deviceId);
                runOnUiThread(() -> {
                    btnActivate.setText("ACTIVATE");
                    btnActivate.setEnabled(true);

                    if (result.equals("SUCCESS")) {
                        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
                        prefs.edit().putBoolean("is_activated", true).commit();
                        Toast.makeText(this, "Activated Successfully!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, MainActivity.class));
                        finish();
                    } else if (result.equals("ALREADY_USED")) {
                        Toast.makeText(this, "Error: This code is bundled with another device!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Invalid Code or Network Error.", Toast.LENGTH_LONG).show();
                    }
                });
            }).start();
        });
    }

    private String claimCode(String code, String deviceId) {
    try {
        // 1. Check if code exists in Firebase
        URL url = new URL(FIREBASE_URL + code + ".json");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) response.append(line);
        reader.close();

        String dbResponse = response.toString();

        if (dbResponse.equals("null")) {
            return "INVALID"; // Code doesn't exist (Hacker made it up)
        }

        // 2. Check if it's UNCLAIMED
        if (dbResponse.contains("UNCLAIMED")) {
            // It's valid! Claim it by writing the device ID
            URL claimUrl = new URL(FIREBASE_URL + code + ".json");
            HttpURLConnection putConn = (HttpURLConnection) claimUrl.openConnection();
            putConn.setRequestMethod("PUT");
            putConn.setDoOutput(true);

            try (OutputStream os = putConn.getOutputStream()) {
                byte[] input = ("\"" + deviceId + "\"").getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (putConn.getResponseCode() == 200) {
                return "SUCCESS"; // Claimed!
            }
        } else if (dbResponse.contains(deviceId)) {
            return "SUCCESS"; // Already claimed by THIS device
        } else {
            return "ALREADY_USED"; // Claimed by someone else
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
    return "ERROR";
}

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    private String getHardwareDeviceId() {
        String hardwareInfo = android.os.Build.BOARD + android.os.Build.BRAND +
                android.os.Build.DEVICE + android.os.Build.HARDWARE +
                android.os.Build.MANUFACTURER + android.os.Build.MODEL + android.os.Build.PRODUCT;
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] hash = digest.digest(hardwareInfo.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().substring(0, 16);
        } catch (Exception e) { return "ERROR_ID"; }
    }
}