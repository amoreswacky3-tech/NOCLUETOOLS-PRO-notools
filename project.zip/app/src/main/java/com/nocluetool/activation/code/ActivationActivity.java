package com.nocluetool.activation.code;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.nocluetools.pro.MainActivity;

public class ActivationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 🔓 ACTIVATION BYPASS: Go straight to MainActivity
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}