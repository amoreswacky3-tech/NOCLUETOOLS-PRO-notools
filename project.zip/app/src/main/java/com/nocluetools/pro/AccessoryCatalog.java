package com.nocluetools.pro;

import java.util.ArrayList;

public final class AccessoryCatalog {
    private static final String[] SHOE_BRAND = {"Generic / No Brand", "Nike", "Adidas", "Jordan", "Converse", "Reebok", "Under Armour", "Spalding"};
    private static final String[] UNDERSHIRT = {"None", "Body Shirt", "Short-Sleeve Shirt", "Long-Sleeve Shirt"};
    private static final String[] ELBOW = {"None", "Elbow Pad", "Elbow Sleeve", "Small Elbow Band", "Elbow Band", "Large Elbow Band", "Elbow Brace", "Elbow Strap"};
    private static final String[] WRIST = {"None", "Forearm Band", "Wristband", "Protective Wristband", "Double Wristband", "Rubber Band", "Double Rubber Band", "I Promise Band", "Powerband", "Wrist Tape Wrap", "Hand Wrap", "Arm Sleeve 11", "Arm Sleeve 2", "Arm Sleeve 8", "Arm Sleeve 9", "Arm Sleeve 21"};
    private static final String[] ARM = {"None", "Arm Sleeve", "Arm Sleeve w/ Pad", "Short Sleeve", "Shoulder Sleeve", "Full Arm Sleeve", "Adidas Arm Sleeve"};
    private static final String[] LEG = {"None", "Leg Sleeve", "Calf Sleeve", "Full Padded Calf Sleeve", "Half Calf Sleeve", "Hex-Pad Half Calf Sleeve", "Jordan Calf Sleeve", "Mid Calf Sleeve"};
    private static final String[] FINGER = {"None", "Finger Strap", "Double Finger Strap", "Long Index Finger Strap", "Long Middle Finger Strap"};
    private static final String[] KNEE = {"None", "Knee Pad", "Hex Knee Pad", "Knee Brace", "Knee Sleeve", "Knee Strap"};
    private static final String[] ANKLE = {"None", "Ankle Brace", "Ankle Wrap"};
    private static final String[] SOCK = {"Ankle Socks", "Low Socks", "Double Low Socks", "Medium Socks", "Double Medium Socks", "Medium-Long Socks", "High Socks", "Striped Socks"};

    public static String[] optionsFor(String label, int maxValue) {
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i <= maxValue; i++) {
            String name;
            if ("Headband".equals(label)) {
                name = i == 0 ? "Off (0)" : "On (1)";
            } else if ("Shorts".equals(label)) {
                name = i == 0 ? "Normal Shorts (0)" : "Short Shorts (1)";
            } else if ("Shoe Brand".equals(label)) {
                name = nativeName(SHOE_BRAND, i, "Brand Slot");
            } else if (label.contains("Shoe Trim")) {
                name = i == 0 ? "Default Trim (0)" : "Trim Slot " + i + " (" + i + ")";
            } else if (label.contains("Color")) {
                name = i == 0 ? "Default / Team (0)" : "Color Slot " + i + " (" + i + ")";
            } else if ("Headband Logo".equals(label)) {
                name = i == 0 ? "No Logo (0)" : "Logo Slot " + i + " (" + i + ")";
            } else if (label.endsWith("Elbow")) {
                name = nativeName(ELBOW, i, "Elbow Style");
            } else if (label.endsWith("Wrist")) {
                name = nativeName(WRIST, i, "Wrist Style");
            } else if (label.endsWith("Arm")) {
                name = nativeName(ARM, i, "Arm Style");
            } else if (label.endsWith("Leg")) {
                name = nativeName(LEG, i, "Leg Style");
            } else if (label.endsWith("Fingers")) {
                name = nativeName(FINGER, i, "Finger Style");
            } else if (label.endsWith("Knee")) {
                name = nativeName(KNEE, i, "Knee Style");
            } else if (label.endsWith("Ankle")) {
                name = nativeName(ANKLE, i, "Ankle Style");
            } else if ("Socks".equals(label)) {
                name = nativeName(SOCK, i, "Sock Style");
            } else if ("Undershirt".equals(label)) {
                name = nativeName(UNDERSHIRT, i, "Undershirt Style");
            } else {
                name = i == 0 ? "None (0)" : "Style " + i + " (" + i + ")";
            }
            list.add(name);
        }
        return list.toArray(new String[0]);
    }

    private static String nativeName(String[] arr, int i, String fallback) {
        return (i < 0 || i >= arr.length) ? fallback + " " + i + " (" + i + ")" : arr[i] + " (" + i + ")";
    }
}