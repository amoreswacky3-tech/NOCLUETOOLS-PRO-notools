package com.nocluetools.pro;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class RosterStaffMap {
    public static final int STAFF_APPEARANCE_ID_A_BITS = 1067;
    public static final int STAFF_APPEARANCE_ID_B_BITS = 1088;
    public static final int STAFF_APPEARANCE_ID_MAX = 8191;
    public static final int STAFF_APPEARANCE_ID_WIDTH = 13;
    public static final int STAFF_FIRST_REF_BITS = 0;
    public static final int STAFF_LAST_REF_BITS = 32;
    public static final int STAFF_STRIDE_BITS = 1248;
    public static final long STAFF_TAG_BASE = 572522496;
    public static final int STAFF_TAG_BITS = 32;
    public static final int TEAM_ASSISTANT_COACH_REF_BITS = 1344;
    public static final int TEAM_HEAD_COACH_REF_BITS = 1312;

    public static final class StaffRecord {
        public final int appearanceIdA;
        public final int appearanceIdB;
        public final String displayName;
        public final String firstName;
        public final long firstNameRef;
        public final String lastName;
        public final long lastNameRef;
        public final int slot;

        StaffRecord(int i, long j, long j2, String str, String str2, int i2, int i3) {
            this.slot = i;
            this.firstNameRef = j;
            this.lastNameRef = j2;
            this.firstName = clean(str);
            this.lastName = clean(str2);
            this.appearanceIdA = i2;
            this.appearanceIdB = i3;
            String strTrim = (this.firstName + " " + this.lastName).trim();
            this.displayName = strTrim.length() == 0 ? String.format(Locale.US, "Staff %04d", i) : strTrim;
        }
    }

    public static final class Result {
        public final List<StaffRecord> staff;
        public final long staffTableBitOffset;

        Result(long j, List<StaffRecord> list) {
            this.staffTableBitOffset = j;
            this.staff = Collections.unmodifiableList(list);
        }

        public StaffRecord get(int i) {
            return (i < 0 || i >= this.staff.size()) ? null : this.staff.get(i);
        }
    }

    public static Result parse(byte[] bArr) throws IOException {
        if (bArr == null || bArr.length < 1024) {
            throw new IOException("Roster payload is empty.");
        }
        long jFindSequentialTable = findSequentialTable(bArr, STAFF_TAG_BASE, STAFF_STRIDE_BITS, 8);
        if (jFindSequentialTable < 0) {
            throw new IOException("STAFF/COACH table was not found.");
        }
        int iCountSequentialRecords = countSequentialRecords(bArr, jFindSequentialTable, STAFF_TAG_BASE, STAFF_STRIDE_BITS, 4096);
        if (iCountSequentialRecords < 30) {
            throw new IOException("STAFF/COACH table is too small: " + iCountSequentialRecords);
        }
        
        ArrayList<StaffRecord> arrayList = new ArrayList<>(iCountSequentialRecords);
        
        for (int i = 0; i < iCountSequentialRecords; i++) {
            long j = jFindSequentialTable + (((long) i) * ((long) STAFF_STRIDE_BITS)) + 32L;
            long bits = readBits(bArr, j, 32);
            long bits2 = readBits(bArr, j + 32, 32);
            
            String str = RosterLoader.readRosterString(bits);
            String str2 = RosterLoader.readRosterString(bits2);
            
            arrayList.add(new StaffRecord(i, bits, bits2, str, str2, 
                (int) readBits(bArr, j + STAFF_APPEARANCE_ID_A_BITS, 13), 
                (int) readBits(bArr, j + STAFF_APPEARANCE_ID_B_BITS, 13)));
        }
        
        return new Result(jFindSequentialTable, arrayList);
    }

    public static int getHeadCoachSlot(byte[] bArr, long j, int i) {
        return staffSlotFromRef(readTeamStaffRef(bArr, j, i, TEAM_HEAD_COACH_REF_BITS));
    }

    public static int getAssistantCoachSlot(byte[] bArr, long j, int i) {
        return staffSlotFromRef(readTeamStaffRef(bArr, j, i, TEAM_ASSISTANT_COACH_REF_BITS));
    }

    public static long makeStaffRef(int i) {
        if (i < 0 || i > 1048575) {
            throw new IllegalArgumentException("staffSlot");
        }
        return STAFF_TAG_BASE | (((long) i) & 1048575);
    }

    public static int staffSlotFromRef(long j) {
        long j2 = j - STAFF_TAG_BASE;
        if (j2 < 0 || j2 > 1048575) {
            return -1;
        }
        return (int) j2;
    }

    public static int findUnusedStaffSlot(byte[] bArr, long j, int i, Result result) {
        if (bArr == null || result == null || result.staff.size() == 0) {
            return -1;
        }
        boolean[] zArr = new boolean[result.staff.size()];
        int iMax = Math.max(0, i);
        for (int i2 = 0; i2 < iMax; i2++) {
            long j2 = j + (((long) i2) * 6356) + 32;
            if (j2 + TEAM_ASSISTANT_COACH_REF_BITS + 32 > ((long) bArr.length) * 8) {
                break;
            }
            int iStaffSlotFromRef = staffSlotFromRef(readBits(bArr, j2 + TEAM_HEAD_COACH_REF_BITS, 32));
            int iStaffSlotFromRef2 = staffSlotFromRef(readBits(bArr, j2 + TEAM_ASSISTANT_COACH_REF_BITS, 32));
            if (iStaffSlotFromRef >= 0 && iStaffSlotFromRef < zArr.length) {
                zArr[iStaffSlotFromRef] = true;
            }
            if (iStaffSlotFromRef2 >= 0 && iStaffSlotFromRef2 < zArr.length) {
                zArr[iStaffSlotFromRef2] = true;
            }
        }
        for (int length = zArr.length - 1; length >= 0; length--) {
            if (!zArr[length]) {
                return length;
            }
        }
        return -1;
    }

    public static void writePlayerIdentityIntoExistingCoach(byte[] bArr, Result result, int i, RosterLoader.Player player) throws IOException {
        if (bArr == null || result == null || player == null) {
            throw new IOException("Player/coach data is unavailable.");
        }
        if (i < 0 || i >= result.staff.size()) {
            throw new IOException("Active coach STAFF slot is invalid.");
        }
        long j = result.staffTableBitOffset + (((long) i) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
        writeBits(bArr, j, 32, player.firstNameRef);
        writeBits(bArr, j + 32, 32, player.lastNameRef);
        
        if (readBits(bArr, j, 32) != (player.firstNameRef & 4294967295L) || readBits(bArr, j + 32, 32) != (player.lastNameRef & 4294967295L)) {
            throw new IOException("Active coach identity verification failed.");
        }
    }

    public static void writePlayerIdentityAndAppearanceIntoExistingCoach(byte[] bArr, Result result, int i, RosterLoader.Player player) throws IOException {
        if (bArr == null || result == null || player == null) {
            throw new IOException("Player/coach data is unavailable.");
        }
        if (i < 0 || i >= result.staff.size()) {
            throw new IOException("Active coach STAFF slot is invalid.");
        }
        if (player.cyberfaceId <= 0 || player.cyberfaceId >= 65280) {
            throw new IOException("Selected player does not have a usable cyberface ID.");
        }
        if (player.cyberfaceId > 8191) {
            throw new IOException("Player CFID " + player.cyberfaceId + " is too large for the 13-bit coach appearance field (max 8191).");
        }
        writePlayerIdentityIntoExistingCoach(bArr, result, i, player);
        long j = result.staffTableBitOffset + (((long) i) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
        int i2 = player.cyberfaceId;
        writeBits(bArr, j + STAFF_APPEARANCE_ID_A_BITS, 13, i2);
        writeBits(bArr, j + STAFF_APPEARANCE_ID_B_BITS, 13, i2);
        int bits = (int) readBits(bArr, j + STAFF_APPEARANCE_ID_A_BITS, 13);
        int bits2 = (int) readBits(bArr, j + STAFF_APPEARANCE_ID_B_BITS, 13);
        if (bits != i2 || bits2 != i2) {
            throw new IOException("Coach appearance CFID verification failed.");
        }
    }

    private static long readTeamStaffRef(byte[] bArr, long j, int i, int i2) {
        if (i < 0 || i >= 30) {
            throw new IllegalArgumentException("teamSlot");
        }
        return readBits(bArr, j + (((long) i) * 6356) + 32 + ((long) i2), 32);
    }

    private static int countSequentialRecords(byte[] bArr, long j, long j2, int i, int i2) {
        int i3 = 0;
        long length = ((long) bArr.length) * 8;
        while (i3 < i2) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) {
                break;
            }
            if (readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) {
                break;
            }
            i3++;
        }
        return i3;
    }

    private static long findSequentialTable(byte[] bArr, long j, int i, int i2) {
        byte[] bArr2 = {(byte) ((j >>> 24) & 255), (byte) ((j >>> 16) & 255), (byte) ((j >>> 8) & 255), (byte) (j & 255)};
        for (int i3 = 0; i3 <= bArr.length - 4; i3++) {
            if (bArr[i3] == bArr2[0] && bArr[i3 + 1] == bArr2[1] && bArr[i3 + 2] == bArr2[2] && bArr[i3 + 3] == bArr2[3]) {
                long j2 = ((long) i3) * 8;
                if (verify(bArr, j2, j, i, i2)) {
                    return j2;
                }
            }
        }
        for (int i4 = 1; i4 < 8; i4++) {
            for (int i5 = 0; i5 < bArr.length - 4; i5++) {
                if (shiftedByte(bArr, i5, i4) == (bArr2[0] & 255) && shiftedByte(bArr, i5 + 1, i4) == (bArr2[1] & 255) && shiftedByte(bArr, i5 + 2, i4) == (bArr2[2] & 255) && shiftedByte(bArr, i5 + 3, i4) == (bArr2[3] & 255)) {
                    long j3 = (((long) i5) * 8) + ((long) i4);
                    if (verify(bArr, j3, j, i, i2)) {
                        return j3;
                    }
                }
            }
        }
        return -1L;
    }

    private static boolean verify(byte[] bArr, long j, long j2, int i, int i2) {
        long length = ((long) bArr.length) * 8;
        for (int i3 = 0; i3 < i2; i3++) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) return false;
            if (readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) return false;
        }
        return true;
    }

    private static int shiftedByte(byte[] bArr, int i, int i2) {
        return (((bArr[i] & 255) << i2) & 255) | ((bArr[i + 1] & 255) >>> (8 - i2));
    }

    private static String clean(String str) {
        return str == null ? "" : str.trim().replaceAll("\\s+", " ");
    }
    
    private static long readBits(byte[] buf, long bitPos, int width) {
        long result = 0;
        for (int i = 0; i < width; i++) {
            long p = bitPos + i;
            int b = buf[(int)(p >>> 3)] & 255;
            result = (result << 1) | ((b >>> (7 - (int)(p & 7))) & 1);
        }
        return result & 0xFFFFFFFFL;
    }

    private static void writeBits(byte[] buf, long bitPos, int width, long value) {
        long mask = (1L << width) - 1;
        value &= mask;
        for (int i = 0; i < width; i++) {
            long p = bitPos + i;
            int byteIndex = (int) (p >>> 3);
            int bitIndex = 7 - (int) (p & 7);
            if (((value >> (width - 1 - i)) & 1) != 0) {
                buf[byteIndex] |= (1 << bitIndex);
            } else {
                buf[byteIndex] &= ~(1 << bitIndex);
            }
        }
    }

    RosterStaffMap() {}
}