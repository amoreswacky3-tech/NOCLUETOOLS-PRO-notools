package com.nocluetools.pro;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class ObbRepacker {

    private static final String TAG = "ObbRepacker";

    public static final class ObbHeader {
        public int    version;
        public int    flags;
        public String packageName;
        public String versionName;
        public byte[] mainSalt, mainKey, mainIV;
        public int    mainEncrypted;
        public byte[] patchSalt, patchKey, patchIV;
        public int    patchEncrypted;
        public int    fileCount;
        public long   fileListOffset, fileListSize;
        public long   signatureLength, signatureOffset, signatureSize;
        public long   zipStart;
        public byte[] raw;
    }

    public static ObbHeader readHeader(File obb) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(obb, "r")) {
            long len = raf.length();
            if (len < 0x6C) throw new IOException("File too small to be OBB");
            int readLen = (int) Math.min(len, 0x4000);
            byte[] hdr = new byte[readLen];
            raf.readFully(hdr);
            ByteBuffer bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN);
            if (bb.getInt(0x00) != 0) throw new IOException("Not an OBB (bad magic)");

            ObbHeader h = new ObbHeader();
            h.version = bb.getInt(0x04);
            if (h.version != 1 && h.version != 2)
                throw new IOException("Unsupported OBB v" + h.version);
            h.flags = bb.getInt(0x08);

            int pnLen = bb.getInt(0x0C), pnOff = bb.getInt(0x10);
            int vnLen = bb.getInt(0x14), vnOff = bb.getInt(0x18);
            h.packageName = new String(hdr, pnOff, pnLen, StandardCharsets.UTF_8);
            h.versionName = new String(hdr, vnOff, vnLen, StandardCharsets.UTF_8);

            h.mainSalt = slice(hdr, bb.getInt(0x1C), bb.getInt(0x20));
            h.mainKey  = slice(hdr, bb.getInt(0x24), bb.getInt(0x28));
            h.mainIV   = slice(hdr, bb.getInt(0x2C), bb.getInt(0x30));
            h.mainEncrypted = bb.getInt(0x34);

            h.patchSalt = slice(hdr, bb.getInt(0x38), bb.getInt(0x3C));
            h.patchKey  = slice(hdr, bb.getInt(0x40), bb.getInt(0x44));
            h.patchIV   = slice(hdr, bb.getInt(0x48), bb.getInt(0x4C));
            h.patchEncrypted = bb.getInt(0x50);

            h.fileCount       = bb.getInt(0x54);
            h.fileListOffset  = bb.getInt(0x58) & 0xFFFFFFFFL;
            h.fileListSize    = bb.getInt(0x5C) & 0xFFFFFFFFL;
            h.signatureLength = bb.getInt(0x60) & 0xFFFFFFFFL;
            h.signatureOffset = bb.getInt(0x64) & 0xFFFFFFFFL;
            h.signatureSize   = bb.getInt(0x68) & 0xFFFFFFFFL;

            long lastEnd = 0x6C;
            lastEnd = Math.max(lastEnd, (long) pnOff + pnLen);
            lastEnd = Math.max(lastEnd, (long) vnOff + vnLen);
            lastEnd = Math.max(lastEnd, (long) bb.getInt(0x20) + h.mainSalt.length);
            lastEnd = Math.max(lastEnd, (long) bb.getInt(0x28) + h.mainKey.length);
            lastEnd = Math.max(lastEnd, (long) bb.getInt(0x30) + h.mainIV.length);
            lastEnd = Math.max(lastEnd, (long) bb.getInt(0x3C) + h.patchSalt.length);
            lastEnd = Math.max(lastEnd, (long) bb.getInt(0x44) + h.patchKey.length);
            lastEnd = Math.max(lastEnd, (long) bb.getInt(0x4C) + h.patchIV.length);
            if (h.version == 2) lastEnd = Math.max(lastEnd, h.fileListOffset + h.fileListSize);

            h.zipStart = lastEnd;
            h.raw = Arrays.copyOfRange(hdr, 0, (int) h.zipStart);
            return h;
        }
    }

    public static void saveAsNew(File originalObb,
                                 Map<String, File> replacements,
                                 File outputObb) throws IOException {

        ObbHeader h = readHeader(originalObb);
        Log.d(TAG, "OBB v" + h.version + " pkg=" + h.packageName
                + " zipStart=0x" + Long.toHexString(h.zipStart)
                + " encrypted=" + h.mainEncrypted);

        File cacheDir = outputObb.getParentFile();
        File innerZip = new File(cacheDir, ".inner_" + System.currentTimeMillis() + ".zip");
        File outZip   = new File(cacheDir, ".out_"   + System.currentTimeMillis() + ".zip");

        try {
            extractRange(originalObb, h.zipStart, originalObb.length(), innerZip);
            rebuildZip(innerZip, outZip, replacements);

            try (FileOutputStream fos = new FileOutputStream(outputObb)) {
                fos.write(h.raw);
                try (FileInputStream fis = new FileInputStream(outZip)) {
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = fis.read(buf)) > 0) fos.write(buf, 0, n);
                }
                if (h.signatureLength > 0) {
                    fos.write(new byte[(int) h.signatureLength]);
                }
            }
            Log.d(TAG, "Wrote: " + outputObb.getAbsolutePath()
                    + " (" + outputObb.length() + " bytes)");
        } finally {
            innerZip.delete();
            outZip.delete();
        }
    }

    private static void extractRange(File src, long start, long end, File dst) throws IOException {
        try (RandomAccessFile in = new RandomAccessFile(src, "r");
             FileOutputStream out = new FileOutputStream(dst)) {
            in.seek(start);
            byte[] buf = new byte[1 << 16];
            long remaining = end - start;
            while (remaining > 0) {
                int r = in.read(buf, 0, (int) Math.min(buf.length, remaining));
                if (r < 0) break;
                out.write(buf, 0, r);
                remaining -= r;
            }
        }
    }

    private static void rebuildZip(File srcZip, File outZip,
                                   Map<String, File> replacements) throws IOException {
        Set<String> handled = new HashSet<>();
        byte[] buf = new byte[1 << 16];

        try (ZipInputStream zin = new ZipInputStream(
                    new BufferedInputStream(new FileInputStream(srcZip)));
             ZipOutputStream zout = new ZipOutputStream(
                    new BufferedOutputStream(new FileOutputStream(outZip)))) {

            zout.setLevel(Deflater.DEFAULT_COMPRESSION);

            ZipEntry ze;
            while ((ze = zin.getNextEntry()) != null) {
                String name = ze.getName();
                File repl = replacements.get(name);

                if (repl == null && replacements.containsKey(name)) {
                    handled.add(name);
                    zin.closeEntry();
                    continue;
                }

                zout.putNextEntry(new ZipEntry(name));

                if (repl != null) {
                    try (FileInputStream fis = new FileInputStream(repl)) {
                        int n;
                        while ((n = fis.read(buf)) > 0) zout.write(buf, 0, n);
                    }
                    handled.add(name);
                    Log.d(TAG, "Replaced: " + name);
                } else {
                    int n;
                    while ((n = zin.read(buf)) > 0) zout.write(buf, 0, n);
                }
                zout.closeEntry();
            }

            for (Map.Entry<String, File> e : replacements.entrySet()) {
                if (handled.contains(e.getKey())) continue;
                if (e.getValue() == null) continue;
                zout.putNextEntry(new ZipEntry(e.getKey()));
                try (FileInputStream fis = new FileInputStream(e.getValue())) {
                    int n;
                    while ((n = fis.read(buf)) > 0) zout.write(buf, 0, n);
                }
                zout.closeEntry();
                Log.d(TAG, "Added: " + e.getKey());
            }
        }
    }

    private static byte[] slice(byte[] src, int off, int len) {
        if (len <= 0 || off < 0 || off + len > src.length) return new byte[0];
        return Arrays.copyOfRange(src, off, off + len);
    }

    private ObbRepacker() { }
}