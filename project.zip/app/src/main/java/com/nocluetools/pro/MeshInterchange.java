package com.nocluetools.pro;

import java.io.IOException;

/** Neutral geometry validation; not an IFF mapping or rig/material serializer. */
public final class MeshInterchange {
    private MeshInterchange() {}
    public static final int MAX_BYTES=32*1024*1024, MAX_VERTICES=100000, MAX_FACES=100000, MAX_CORNERS=300000;
    public static final String NOTICE="Static interchange only. Raw XYZ/UV preserved; no rig, morph, material/texture binding or IFF save. Consumer/game compatibility not certified.";
    public static void validate(ObjEngine.ObjModel m)throws IOException {
        if(m==null||m.vertices.isEmpty()||m.faces.isEmpty())throw new IOException("Geometry and faces required");
        if(m.vertices.size()>MAX_VERTICES||m.texcoords.size()>MAX_CORNERS||m.normals.size()>MAX_CORNERS||m.faces.size()>MAX_FACES)throw new IOException("Interchange count limit");
        values(m.vertices,3,"positions");values(m.texcoords,2,"UVs");values(m.normals,3,"normals");
        long corners=0;
        for(ObjEngine.ObjModel.Face f:m.faces){
            if(f==null||f.v==null||f.v.length<3||f.v.length>1024)throw new IOException("Invalid face size");
            corners+=f.v.length;if(corners>MAX_CORNERS)throw new IOException("Face-corner limit");
            if(f.vt==null||f.vn==null||f.vt.length!=f.v.length||f.vn.length!=f.v.length)throw new IOException("Face attribute lengths differ");
            for(int i=0;i<f.v.length;i++){
                if(f.v[i]<0||f.v[i]>=m.vertices.size())throw new IOException("Position index outside range");
                if(f.vt[i]<-1||f.vt[i]>=m.texcoords.size())throw new IOException("UV index outside range");
                if(f.vn[i]<-1||f.vn[i]>=m.normals.size())throw new IOException("Normal index outside range");
            }
        }
    }
    private static void values(java.util.List<float[]> rows,int width,String name)throws IOException {
        for(float[] row:rows){if(row==null||row.length!=width)throw new IOException("Unsupported "+name+" width");
            for(float v:row)if(Float.isNaN(v)||Float.isInfinite(v))throw new IOException("Nonfinite "+name);}
    }
    public static void validatePreview(ObjEngine.ObjModel m)throws IOException {
        validate(m);
        if(m.vertices.size()>20000||m.triangleCount()>40000)throw new IOException("Editable viewer limit: 20000 vertices / 40000 derived triangles");
        for(float[] v:m.vertices)for(float f:v)if(Math.abs(f)>1000000f)throw new IOException("Viewer coordinate limit: 1000000 units; raw geometry is not silently rescaled");
    }
}
