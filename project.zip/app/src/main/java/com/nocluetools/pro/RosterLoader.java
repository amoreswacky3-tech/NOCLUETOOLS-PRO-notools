package com.nocluetools.pro;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public final class RosterLoader {

    private static final int[] BASE_SCHEDULE = {
        -2080324580, 1187958024, 339253324, 33999628, 10794140, -2142795003,
        -1333481328, 210521920, -1875858348, 1158466240, 205058268, 17401478,
        1220573344, -2079749179, -2133793560, 244091080, 341324896, 1078576840,
        606629060, -2077520763, 545316008, -2004155199, -2146677656, 1283477440,
        337177708, 1090995459, 1277171772, -2012281081, 1086340120, -930723448,
        1347721276, 1174490432
    };

    private static final int[] SP = {
        34080768, 524288, 33554434, 34080770, 33554432, 526338, 524290, 33554434,
        526338, 34080768, 34078720, 2050, 33556482, 33554432, 0, 524290,
        524288, 2, 33556480, 526336, 34080770, 34078720, 2050, 33556480,
        2, 2048, 526336, 34078722, 2048, 33556482, 34078722, 0,
        0, 34080770, 33556480, 524290, 34080768, 524288, 2050, 33556480,
        34078722, 2048, 526336, 33554434, 526338, 2, 33554434, 34078720,
        34080770, 526336, 34078720, 33556482, 33554432, 2050, 524290, 0,
        524288, 33554432, 33556482, 34080768, 2, 34078722, 2048, 526338,
        1074823184, 0, 1081344, 1074790400, 1073741840, 32784, 1073774592, 1081344,
        32768, 1074790416, 16, 1073774592, 1048592, 1074823168, 1074790400, 16,
        1048576, 1073774608, 1074790416, 32768, 1081360, 1073741824, 0, 1048592,
        1073774608, 1081360, 1074823168, 1073741840, 1073741824, 1048576, 32784, 1074823184,
        1048592, 1074823168, 1073774592, 1081360, 1074823184, 1048592, 1073741840, 0,
        1073741824, 32784, 1048576, 1074790416, 32768, 1073741824, 1081360, 1073774608,
        1074823168, 32768, 0, 1073741840, 16, 1074823184, 1081344, 1074790400,
        1074790416, 1048576, 32784, 1073774592, 1073774608, 16, 1074790400, 1081344,
        67108865, 67371264, 256, 67109121, 262145, 67108864, 67109121, 262400,
        67109120, 262144, 67371008, 1, 67371265, 257, 1, 67371009,
        0, 262145, 67371264, 256, 257, 67371265, 262144, 67108865,
        67371009, 67109120, 262401, 67371008, 262400, 0, 67108864, 262401,
        67371264, 256, 1, 262144, 257, 262145, 67371008, 67109121,
        0, 67371264, 262400, 67371009, 262145, 67108864, 67371265, 1,
        262401, 67108865, 67108864, 67371265, 262144, 67109120, 67109121, 262400,
        67109120, 0, 67371009, 257, 67108865, 262401, 256, 67371008,
        4198408, 268439552, 8, 272633864, 0, 272629760, 268439560, 4194312,
        272633856, 268435464, 268435456, 4104, 268435464, 4198408, 4194304, 268435456,
        272629768, 4198400, 4096, 8, 4198400, 268439560, 272629760, 4096,
        4104, 0, 4194312, 272633856, 268439552, 272629768, 272633864, 4194304,
        272629768, 4104, 4194304, 268435464, 4198400, 268439552, 8, 272629760,
        268439560, 0, 4096, 4194312, 0, 272629768, 272633856, 4096,
        268435456, 272633864, 4198408, 4194304, 272633864, 8, 268439552, 4198408,
        4194312, 4198400, 272629760, 268439560, 4104, 268435456, 268435464, 272633856,
        134217728, 65536, 1024, 134284320, 134283296, 134218752, 66592, 134283264,
        65536, 32, 134217760, 66560, 134218784, 134283296, 134284288, 0,
        66560, 134217728, 65568, 1056, 134218752, 66592, 0, 134217760,
        32, 134218784, 134284320, 65568, 134283264, 1024, 1056, 134284288,
        134284288, 134218784, 65568, 134283264, 65536, 32, 134217760, 134218752,
        134217728, 66560, 134284320, 0, 66592, 134217728, 1024, 65568,
        134218784, 1024, 0, 134284320, 134283296, 134284288, 1056, 65536,
        66560, 134283296, 134218752, 1056, 32, 66592, 134283264, 134217760,
        -2147483584, 2097216, 0, -2145378304, 2097216, 8192, -2147475392, 2097152,
        8256, -2145378240, 2105344, Integer.MIN_VALUE, -2147475456, -2147483584, -2145386496, 2105408,
        2097152, -2147475392, -2145386432, 0, 8192, 64, -2145378304, -2145386432,
        -2145378240, -2145386496, Integer.MIN_VALUE, 8256, 64, 2105344, 2105408, -2147475456,
        8256, Integer.MIN_VALUE, -2147475456, 2105408, -2145378304, 2097216, 0, -2147475456,
        Integer.MIN_VALUE, 8192, -2145386432, 2097152, 2097216, -2145378240, 2105344, 64,
        -2145378240, 2105344, 2097152, -2147475392, -2147483584, -2145386496, 2105408, 0,
        8192, -2147483584, -2147475392, -2145378304, -2145386496, 8256, 64, -2145386432,
        16384, 512, 16777728, 16777220, 16794116, 16388, 16896, 0,
        16777216, 16777732, 516, 16793600, 4, 16794112, 16793600, 516,
        16777732, 16384, 16388, 16794116, 0, 16777728, 16777220, 16896,
        16793604, 16900, 16794112, 4, 16900, 16793604, 512, 16777216,
        16900, 16793600, 16793604, 516, 16384, 512, 16777216, 16793604,
        16777732, 16900, 16896, 0, 512, 16777220, 4, 16777728,
        0, 16777732, 16777728, 16896, 516, 16384, 16794116, 16777216,
        16794112, 4, 16388, 16794116, 16777220, 16794112, 16793600, 16388,
        545259648, 545390592, 131200, 0, 537001984, 8388736, 545259520, 545390720,
        128, 536870912, 8519680, 131200, 8519808, 537002112, 536871040, 545259520,
        131072, 8519808, 8388736, 537001984, 545390720, 536871040, 0, 8519680,
        536870912, 8388608, 537002112, 545259648, 8388608, 131072, 545390592, 128,
        8388608, 131072, 536871040, 545390720, 131200, 536870912, 0, 8519680,
        545259648, 537002112, 537001984, 8388736, 545390592, 128, 8388736, 537001984,
        545390720, 8388608, 545259520, 536871040, 8519680, 131200, 537002112, 545259520,
        128, 545390592, 8519808, 0, 536870912, 545259648, 131072, 8519808
    };

    private static final byte[] MASK_ORIGINAL  = new byte[64];
    private static final byte[] MASK_NIKZ      = paddedAscii("Nikzworldofficial");
    private static final byte[] MASK_LEGACY    = paddedAscii("89bbd133503c996c");
    private static final byte[] MASK_JAMES     = paddedAscii("JAMESGAMING01");
    private static final byte[] MASK_2KHUZLERS = paddedAscii("2khuslherz");
    private static final byte[][] MASKS = {
        MASK_ORIGINAL, MASK_NIKZ, MASK_LEGACY, MASK_JAMES, MASK_2KHUZLERS
    };
    private static final String[] MASK_NAMES = {
        "ORIGINAL", "NIKZ", "LEGACY", "JAMES", "2KHUZLERS"
    };

    private static final long PLAYER_TAG_BASE = 543162368L;
    private static final int  PLAYER_STRIDE   = 4075;
    private static final long TEAM_TAG_BASE   = 557842432L;
    private static final int  TEAM_STRIDE     = 6356;

    private static final int P_FIRST_REF = 0;
    private static final int P_LAST_CRC  = 64;
    private static final int P_FIRST_CRC = 96;
    private static final int P_PORTRAIT  = 256;
    private static final int P_JERSEY    = 301;
    private static final int P_CF        = 528;
    private static final int P_BODY_TYPE = 1461;
    private static final int P_MUSCLE    = 1463;
    private static final int P_SKIN      = 1464;
    private static final int P_EYE       = 1477;

    private static final int T_TEAM_NAME_REF = 640;
    private static final int T_ABBREV_REF    = 672;
    private static final int T_CITY_REF      = 704;
    private static final int T_DISPLAY_REF   = 736;
    private static final int T_NAME_CRC      = 768;
    private static final int T_SHORT_CRC     = 800;
    private static final int T_PLAYER_COUNT  = 1000;
    private static final int T_MAX_PLAYERS   = 20;

    private static final long STRING_INDEX_MASK = 0x1FFFFFL;
    private static final int  STRING_SECTION    = 48;
    private static final long STD_POOL   = 36432787L;
    private static final long CAREER_POOL = 71905107L;
    
    
// ═══════════════════════════════════════════════════════════
//  PUBLIC RESULT TYPES
// ═══════════════════════════════════════════════════════════

public static class Player {
    public int slot;
    public int cyberfaceId;
    public int portraitId;
    public int jerseyNumber;
    public int bodyType;
    public int muscleType;
    public int skinTone;
    public int eyeColor;
    public long firstNameRef, lastNameRef;
    public long firstNameCrc, lastNameCrc;
    public int activeTeamSlot = -1;
    public String firstName = "";
    public String lastName = "";
    public String displayName = "";
}

public static class Team {
    public int slot;
    public int playerCount;
    public int[] playerSlots = new int[0];
    public long teamNameRef, abbreviationRef, cityRef, displayRef;
    public long teamNameCrc, shortNameCrc;
    public String teamName = "";
    public String abbreviation = "";
    public String cityName = "";
    public String fullName = "";
}

public static class Result {
    public String cryptoMode = "UNKNOWN";
    public int playerCount;
    public int teamCount;
    public List<Player> players = new ArrayList<>();
    public List<Team> teams = new ArrayList<>();
}

// ═══════════════════════════════════════════════════════════
//  PUBLIC ENTRY
// ═══════════════════════════════════════════════════════════

public static Result load(File file) throws IOException {
    byte[] raw = readAll(file);
    return load(raw);
}

public static Result load(byte[] input) throws IOException {
    byte[] data = input;
    if (hasModWrapper(data)) data = toggleModWrapper(data);

    if (data.length < 40) throw new IOException("Roster file too small");

    int payloadLen = readBe32(data, 12);
    if (payloadLen != data.length - 24)
        throw new IOException("Payload length mismatch");

    byte[] payload = new byte[data.length - 24];
    System.arraycopy(data, 24, payload, 0, payload.length);

    Result result = null;
    byte[] decryptedBytes = null;
    for (int m = 0; m < MASKS.length; m++) {
        try {
            byte[] dec = tryDecrypt(payload, MASKS[m]);
            if (dec != null) {
                result = parseRoster(dec);
                result.cryptoMode = MASK_NAMES[m];
                decryptedBytes = dec;
                initWriteEngine(data, decryptedBytes, MASKS[m]); 
                break;
            }
        } catch (Exception ignored) {}
    }
    if (result == null) throw new IOException("Could not decrypt");

    resolveNames(decryptedBytes, result);
    return result;
}

// ═══════════════════════════════════════════════════════════
//  MOD WRAPPER
// ═══════════════════════════════════════════════════════════

private static boolean hasModWrapper(byte[] d) {
    return d != null && d.length >= 40
            && readBe32(d, 16) == 305419947
            && (readBe32(d, 12) ^ 305419947) == d.length - 24;
}

private static byte[] toggleModWrapper(byte[] d) {
    byte[] out = d.clone();
    int[] key = {0x12, 0x34, 0x56, 0xAB};
    for (int i = 0; i < out.length; i++) out[i] ^= key[i & 3];
    return out;
}

// ═══════════════════════════════════════════════════════════
//  DECRYPT
// ═══════════════════════════════════════════════════════════

private static byte[] tryDecrypt(byte[] payload, byte[] mask) throws IOException {
    int[] sched3 = applyMask(BASE_SCHEDULE, mask);
    byte[] plain = decryptCbc(payload, BASE_SCHEDULE, BASE_SCHEDULE, sched3);

    if (plain.length < 18) return null;
    int b16 = plain[16] & 0xFF;
    int b17 = plain[17] & 0xFF;
    if (!looksLikeZlib(b16, b17)) return null;

    int csize = readLe32(plain, 12);
    if (csize <= 0 || csize > plain.length - 16) return null;

    try {
        return inflate(plain, 16, csize);
    } catch (Exception e) {
        return null;
    }
}
        // ═══════════════════════════════════════════════════════════
//  WRITE ENGINE & SAVE API
// ═══════════════════════════════════════════════════════════

private static byte[] originalFileBytes;
private static byte[] rawRosterBytes;
private static byte[] activeCryptoMask;

// Called inside load() to save the state
public static void initWriteEngine(byte[] fileBytes, byte[] rawBytes, byte[] mask) {
    originalFileBytes = fileBytes;
    rawRosterBytes = rawBytes.clone();
    activeCryptoMask = mask;
}

private static long playerPayload(int slot) {
    return 32L + ((long) slot * PLAYER_STRIDE);
}

// Standard MSB-first bit writer
public static void writeBits(long bitPos, int width, long value) {
    if (rawRosterBytes == null) return;
    long mask = (1L << width) - 1;
    value &= mask;
    for (int i = 0; i < width; i++) {
        long p = bitPos + i;
        int byteIndex = (int) (p >>> 3);
        int bitIndex = 7 - (int) (p & 7);
        if (((value >> (width - 1 - i)) & 1) != 0) {
            rawRosterBytes[byteIndex] |= (1 << bitIndex);
        } else {
            rawRosterBytes[byteIndex] &= ~(1 << bitIndex);
        }
    }  
}

// --- SETTERS ---
public static void setJersey(int slot, int jersey) {
    writeBits(playerPayload(slot) + P_JERSEY, 7, jersey);
}

public static void setCyberface(int slot, int cfId) {
    writeBits(playerPayload(slot) + P_CF, 16, cfId);
}

public static void setPortrait(int slot, int portraitId) {
    writeBits(playerPayload(slot) + P_PORTRAIT, 16, portraitId);
}

public static void setRating(int slot, int ratingIdx, int rating) {
    if (rating < 25) rating = 25;
    if (rating > 99) rating = 99;
    long bitOffset = playerPayload(slot) + 3154L + (ratingIdx * 8L);
    int serializedValue = (rating - 25) * 3;
    writeBits(bitOffset, 8, serializedValue);
}

public static void setTendency(int slot, int tendIdx, int value) {
    long bitOffset = playerPayload(slot) + 3490L + (tendIdx * 8L);
    writeBits(bitOffset, 8, value);
}

public static void setBadgeLevel(int slot, int badgeIdx, int level) {
    long bitOffset = playerPayload(slot) + 3955L + (badgeIdx * 2L);
    writeBits(bitOffset, 2, level);
}

// --- ACCESSORIES ---
// Base offset for accessories (usually around 1200-1500 in 2K20)
// You may need to adjust this if accessories don't save correctly!
private static final int ACCESSORY_BASE_BITS = 1177; 

// A simple struct to hold the accessory definitions
public static class AccessoryField {
    public final String label;
    public final int offset;
    public final int width;
    public AccessoryField(String label, int offset, int width) {
        this.label = label; this.offset = offset; this.width = width;
    }
}

// The list of accessories we will show in the UI
public static final AccessoryField[] ACCESSORY_FIELDS = {
    new AccessoryField("Shoe Brand", 0, 4),
    new AccessoryField("Left Arm", 4, 4),
    new AccessoryField("Right Arm", 8, 4),
    new AccessoryField("Left Knee", 12, 4),
    new AccessoryField("Right Knee", 16, 4),
    new AccessoryField("Left Ankle", 20, 2),
    new AccessoryField("Right Ankle", 24, 2),
    new AccessoryField("Undershirt", 26, 2),
    new AccessoryField("Headband", 28, 1)
};

public static int getAccessory(int slot, int accIdx) {
    if (accIdx < 0 || accIdx >= ACCESSORY_FIELDS.length) return 0;
    AccessoryField f = ACCESSORY_FIELDS[accIdx];
    return (int) RosterPlayerMap.readBits(rawRosterBytes, playerPayload(slot) + ACCESSORY_BASE_BITS + f.offset, f.width);
}

public static void setAccessory(int slot, int accIdx, int value) {
    if (accIdx < 0 || accIdx >= ACCESSORY_FIELDS.length) return;
    AccessoryField f = ACCESSORY_FIELDS[accIdx];
    writeBits(playerPayload(slot) + ACCESSORY_BASE_BITS + f.offset, f.width, value);
}

public static void setDraftInfo(int slot, int year, int round, int pick) {
    long payload = playerPayload(slot);
    
    // If year is 2019, it writes 19 (fits in 5 bits).
    if (year >= 2000) {
        writeBits(payload + 1757, 5, year - 2000);
    }
    
    writeBits(payload + 2960, 2, round);
    writeBits(payload + 2086, 5, pick);
}

// --- SAVE METHOD ---
public static void save(File outputFile) throws IOException {
    if (originalFileBytes == null || rawRosterBytes == null || activeCryptoMask == null) {
        throw new IOException("No roster loaded to save.");
    }
    // Use the exact encoder from the decompiled APK
    byte[] encryptedOutput = RosterCrypto.encode(originalFileBytes, rawRosterBytes, activeCryptoMask);
    
    try (java.io.FileOutputStream fos = new java.io.FileOutputStream(outputFile)) {
        fos.write(encryptedOutput);
        fos.flush();
    }
}
    
    // --- CYBERFACE ALLOCATION ---
public static int findNextFreeCyberfaceId(Result result) {
    if (result == null || result.players == null) return -1;
    
    java.util.Set<Integer> used = new java.util.HashSet<>();
    
    // 1. Collect all currently used CF IDs
    for (Player p : result.players) {
        if (p.cyberfaceId > 0 && p.cyberfaceId < 65280) {
            used.add(p.cyberfaceId);
        }
    }
    
    // 2. Find the next free ID between 9000 and 9999
    for (int i = 9000; i <= 9999; i++) {
        if (!used.contains(i)) {
            return i;
        }
    }
    
    return -1; // No free IDs in the custom range
}
    
    // --- ANIMATIONS ---
public static class AnimationField {
    public final String label;
    public final int serializedBit;
    public final int width;
    public AnimationField(String label, int serializedBit, int width) {
        this.label = label;
        this.serializedBit = serializedBit;
        this.width = width;
    }
}

public static final AnimationField[] ANIMATION_FIELDS = {
    new AnimationField("Jump Shot", 1906, 8),
    new AnimationField("Shot Release", 1914, 8),
    new AnimationField("Free Throw", 1922, 8),
    new AnimationField("Dunk", 1930, 8),
    new AnimationField("Fadeaway", 1938, 8),
    new AnimationField("Layup", 1946, 8),
    new AnimationField("Crossover", 1954, 6),
    new AnimationField("Spin", 1962, 6),
    new AnimationField("Behind Back", 1970, 6),
    new AnimationField("Hesitation", 1978, 6),
    new AnimationField("Dribble Pullup", 1986, 8),
    new AnimationField("Side Hop", 1994, 8),
    new AnimationField("Post Hook", 2002, 8),
    new AnimationField("Post Roll", 2010, 8),
    new AnimationField("Post Shimmy", 2018, 6),
    new AnimationField("Post Protect", 2026, 6),
    new AnimationField("Post 1-Step", 2034, 6)
};

public static int getAnimation(int slot, int animIdx) {
    if (animIdx < 0 || animIdx >= ANIMATION_FIELDS.length) return 0;
    AnimationField f = ANIMATION_FIELDS[animIdx];
    return (int) RosterPlayerMap.readBits(rawRosterBytes, playerPayload(slot) + f.serializedBit, f.width);
}

public static void setAnimation(int slot, int animIdx, int value) {
    if (animIdx < 0 || animIdx >= ANIMATION_FIELDS.length) return;
    AnimationField f = ANIMATION_FIELDS[animIdx];
    writeBits(playerPayload(slot) + f.serializedBit, f.width, value);
}


private static boolean looksLikeZlib(int a, int b) {
    return a == 120 && (b == 218 || b == 156 || b == 1 || b == 94);
}

private static byte[] inflate(byte[] data, int off, int len) throws IOException {
    Inflater inf = new Inflater();
    ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(len * 3, 8388608));
    try {
        inf.setInput(data, off, len);
        byte[] buf = new byte[65536];
        while (!inf.finished()) {
            int n = inf.inflate(buf);
            if (n > 0) out.write(buf, 0, n);
            else if (inf.needsInput() || inf.needsDictionary())
                throw new IOException("Inflater stalled");
        }
        return out.toByteArray();
    } catch (Exception e) {
        throw new IOException("Invalid compressed payload");
    } finally {
        inf.end();
        try { out.close(); } catch (Exception ignored) {}
    }
}

private static int[] applyMask(int[] base, byte[] mask) {
    int[] out = base.clone();
    for (int i = 0; i < 16; i++) {
        int k = readLe32(mask, i * 4);
        out[i * 2]     = base[i * 2] ^ k;
        out[i * 2 + 1] = base[i * 2 + 1] ^ k;
    }
    return out;
}

private static byte[] decryptCbc(byte[] data, int[] k1, int[] k2, int[] k3) {
    if (data.length < 16 || (data.length & 7) != 0)
        throw new IllegalArgumentException("Invalid encrypted payload");

    byte[] out = data.clone();
    byte[] prev = new byte[8];
    System.arraycopy(data, 0, prev, 0, 8);

    for (int off = 8; off < data.length; off += 8) {
        byte[] cur = new byte[8];
        System.arraycopy(data, off, cur, 0, 8);
        byte[] plainBlock = decrypt3Block(cur, k1, k2, k3);
        for (int i = 0; i < 8; i++) out[off + i] = (byte) (plainBlock[i] ^ prev[i]);
        prev = cur;
    }
    return out;
}

private static byte[] decrypt3Block(byte[] block, int[] k1, int[] k2, int[] k3) {
    int[] ip = ip(readLe32(block, 0), readLe32(block, 4));
    int[] a = enc2(ip[0], ip[1], k3, false);
    int[] b = enc2(a[0], a[1], k2, true);
    int[] c = enc2(b[0], b[1], k1, false);
    int[] fp = fp(c[0], c[1]);
    byte[] out = new byte[8];
    writeLe32(out, 0, fp[0]);
    writeLe32(out, 4, fp[1]);
    return out;
}

private static int[] enc2(int a, int b, int[] sched, boolean forward) {
    a = Integer.rotateRight(a, 29);
    b = Integer.rotateRight(b, 29);
    boolean toggle = false;
    if (forward) {
        for (int i = 0; i < 16; i++) {
            if (!toggle) b ^= f(a, sched[i * 2], sched[i * 2 + 1]);
            else         a ^= f(b, sched[i * 2], sched[i * 2 + 1]);
            toggle = !toggle;
        }
    } else {
        for (int i = 15; i >= 0; i--) {
            if (!toggle) b ^= f(a, sched[i * 2], sched[i * 2 + 1]);
            else         a ^= f(b, sched[i * 2], sched[i * 2 + 1]);
            toggle = !toggle;
        }
    }
    return new int[]{ Integer.rotateRight(b, 3), Integer.rotateRight(a, 3) };
}

private static int f(int a, int k1, int k2) {
    int x = a ^ k1;
    int y = Integer.rotateRight(a ^ k2, 4);
    return SP[(x >>> 2) & 63]
         ^ SP[128 + ((x >>> 10) & 63)]
         ^ SP[256 + ((x >>> 18) & 63)]
         ^ SP[384 + ((x >>> 26) & 63)]
         ^ SP[64  + ((y >>> 2) & 63)]
         ^ SP[192 + ((y >>> 10) & 63)]
         ^ SP[320 + ((y >>> 18) & 63)]
         ^ SP[448 + ((y >>> 26) & 63)];
}

private static int[] ip(int a, int b) {
    int c = (a ^ (b >>> 4)) & 0x0F0F0F0F;
    int d = a ^ c;
    int e = b ^ (c << 4);
    int f_ = (e ^ (d >>> 16)) & 0xFFFF;
    int g = e ^ f_;
    int h = d ^ (f_ << 16);
    int i_ = (h ^ (g >>> 2)) & 0x33333333;
    int j = h ^ i_;
    int k = g ^ (i_ << 2);
    int l = (k ^ (j >>> 8)) & 0x00FF00FF;
    int m = k ^ l;
    int n = j ^ (l << 8);
    int o = (n ^ (m >>> 1)) & 0x55555555;
    return new int[]{ n ^ o, m ^ (o << 1) };
}

private static int[] fp(int a, int b) {
    int c = (a ^ (b >>> 1)) & 0x55555555;
    int d = a ^ c;
    int e = b ^ (c << 1);
    int f_ = (e ^ (d >>> 8)) & 0x00FF00FF;
    int g = e ^ f_;
    int h = d ^ (f_ << 8);
    int i_ = (h ^ (g >>> 2)) & 0x33333333;
    int j = h ^ i_;
    int k = g ^ (i_ << 2);
    int l = (k ^ (j >>> 16)) & 0xFFFF;
    int m = k ^ l;
    int n = j ^ (l << 16);
    int o = (n ^ (m >>> 4)) & 0x0F0F0F0F;
    return new int[]{ n ^ o, m ^ (o << 4) };
}


    // ═══════════════════════════════════════════════════════════
    //  BIT READ
    // ═══════════════════════════════════════════════════════════

    static long readBits(byte[] d, long bitPos, int width) {
        long v = 0;
        for (int i = 0; i < width; i++) {
            long bp = bitPos + i;
            int bit = (d[(int) (bp >>> 3)] >>> (7 - ((int) bp & 7))) & 1;
            v = (v << 1) | bit;
        }
        return v & 0xFFFFFFFFL;
    }

    // ═══════════════════════════════════════════════════════════
    //  TABLE DISCOVERY
    // ═══════════════════════════════════════════════════════════

    private static long findSequentialTable(byte[] d, long tagBase, int stride, int minRecords) {
        byte[] pattern = {
            (byte) ((tagBase >>> 24) & 0xFF),
            (byte) ((tagBase >>> 16) & 0xFF),
            (byte) ((tagBase >>> 8) & 0xFF),
            (byte) (tagBase & 0xFF)
        };
        for (int i = 0; i <= d.length - 4; i++) {
            if (d[i] == pattern[0] && d[i+1] == pattern[1]
                    && d[i+2] == pattern[2] && d[i+3] == pattern[3]) {
                long bp = (long) i * 8;
                if (verifySequence(d, bp, tagBase, stride, minRecords)) return bp;
            }
        }
        for (int shift = 1; shift < 8; shift++) {
            for (int i = 0; i <= d.length - 4; i++) {
                if (shiftedByte(d, i, shift) == (pattern[0] & 0xFF)
                        && shiftedByte(d, i + 1, shift) == (pattern[1] & 0xFF)
                        && shiftedByte(d, i + 2, shift) == (pattern[2] & 0xFF)
                        && shiftedByte(d, i + 3, shift) == (pattern[3] & 0xFF)) {
                    long bp = (long) i * 8 + shift;
                    if (verifySequence(d, bp, tagBase, stride, minRecords)) return bp;
                }
            }
        }
        return -1L;
    }

    private static boolean verifySequence(byte[] d, long startBit, long tagBase, int stride, int count) {
        long totalBits = (long) d.length * 8;
        for (int i = 0; i < count; i++) {
            long bp = startBit + (long) i * stride;
            if (bp + 32 > totalBits) return false;
            if (readBits(d, bp, 32) != (tagBase | (i & 0xFFFFF))) return false;
        }
        return true;
    }

    private static int countSequentialRecords(byte[] d, long startBit, long tagBase, int stride, int maxCount) {
        long totalBits = (long) d.length * 8;
        int count = 0;
        while (count < maxCount) {
            long bp = startBit + (long) count * stride;
            if (bp + 32 > totalBits) break;
            if (readBits(d, bp, 32) != (tagBase | (count & 0xFFFFF))) break;
            count++;
        }
        return count;
    }

    private static int shiftedByte(byte[] d, int i, int shift) {
        if (i < 0 || i >= d.length) return -1;
        int b0 = d[i] & 0xFF;
        if (shift == 0) return b0;
        if (i + 1 >= d.length) return -1;
        return ((b0 << shift) & 0xFF) | ((d[i + 1] & 0xFF) >>> (8 - shift));
    }

    // ═══════════════════════════════════════════════════════════
    //  PARSE TABLES
    // ═══════════════════════════════════════════════════════════

    private static Result parseRoster(byte[] d) throws IOException {
        if (d == null || d.length < 1024) throw new IOException("Decoded payload empty");

        long playerStart = findSequentialTable(d, PLAYER_TAG_BASE, PLAYER_STRIDE, 3);
        if (playerStart < 0) throw new IOException("PLAYERDATA not found");

        int playerCount = countSequentialRecords(d, playerStart, PLAYER_TAG_BASE, PLAYER_STRIDE, 10000);
        if (playerCount < 100) throw new IOException("PLAYERDATA too small");

        Result result = new Result();
        result.playerCount = playerCount;

        for (int i = 0; i < playerCount; i++) {
            long base = playerStart + (long) i * PLAYER_STRIDE + 32;
            Player p = new Player();
            p.slot         = i;
            p.cyberfaceId  = (int) readBits(d, base + P_CF, 16);
            p.portraitId   = (int) readBits(d, base + P_PORTRAIT, 16);
            p.jerseyNumber = (int) readBits(d, base + P_JERSEY, 7);
            p.bodyType     = (int) readBits(d, base + P_BODY_TYPE, 2);
            p.muscleType   = (int) readBits(d, base + P_MUSCLE, 1);
            p.skinTone     = (int) readBits(d, base + P_SKIN, 3);
            p.eyeColor     = (int) readBits(d, base + P_EYE, 3);
            p.lastNameRef  = readBits(d, base + 0, 32);
            p.firstNameRef = readBits(d, base + 32, 32);
            p.lastNameCrc  = readBits(d, base + P_LAST_CRC, 32);
            p.firstNameCrc = readBits(d, base + P_FIRST_CRC, 32);
            result.players.add(p);
        }

        long teamStart = findSequentialTable(d, TEAM_TAG_BASE, TEAM_STRIDE, 4);
        if (teamStart < 0) throw new IOException("TEAMDATA not found");

        int teamCount = countSequentialRecords(d, teamStart, TEAM_TAG_BASE, TEAM_STRIDE, 1024);
        if (teamCount < 30) throw new IOException("TEAMDATA too small");
        result.teamCount = 30;

        for (int i = 0; i < 30; i++) {
            long base = teamStart + (long) i * TEAM_STRIDE + 32;
            Team t = new Team();
            t.slot = i;

            int pc = (int) readBits(d, base + T_PLAYER_COUNT, 8);
            if (pc < 0) pc = 0;
            if (pc > T_MAX_PLAYERS) pc = T_MAX_PLAYERS;

            int[] slots = new int[pc];
            int real = 0;
            for (int j = 0; j < pc; j++) {
                long ref = readBits(d, base + (long) j * 32, 32);
                long slotVal = ref - PLAYER_TAG_BASE;
                if (slotVal >= 0 && slotVal < playerCount) {
                    int s = (int) slotVal;
                    slots[real++] = s;
                    Player pp = result.players.get(s);
                    if (pp.activeTeamSlot < 0) pp.activeTeamSlot = i;
                }
            }
            t.playerSlots = new int[real];
            System.arraycopy(slots, 0, t.playerSlots, 0, real);
            t.playerCount = real;
            t.teamNameRef     = readBits(d, base + T_TEAM_NAME_REF, 32);
            t.abbreviationRef = readBits(d, base + T_ABBREV_REF, 32);
            t.cityRef         = readBits(d, base + T_CITY_REF, 32);
            t.displayRef      = readBits(d, base + T_DISPLAY_REF, 32);
            t.teamNameCrc     = readBits(d, base + T_NAME_CRC, 32);
            t.shortNameCrc    = readBits(d, base + T_SHORT_CRC, 32);
            result.teams.add(t);
        }

        return result;
    }

    // ═══════════════════════════════════════════════════════════
    //  NAMES
    // ═══════════════════════════════════════════════════════════

    private static void resolveNames(byte[] d, Result r) {
        long pool = findPool(d, r.teams);
        if (pool < 0) {
            for (Player p : r.players) p.displayName = "Player " + p.slot;
            for (Team t : r.teams) t.fullName = "Team " + t.slot;
            return;
        }
        for (Team t : r.teams) {
            t.teamName     = clean(readString(d, pool, t.teamNameRef));
            t.abbreviation = clean(readString(d, pool, t.abbreviationRef));
            t.cityName     = clean(readString(d, pool, t.cityRef));
            String disp    = clean(readString(d, pool, t.displayRef));
            String full    = joinTeam(t.cityName, t.teamName, disp);
            t.fullName = full.isEmpty() ? "Team " + t.slot : full;
        }
        for (Player p : r.players) {
            p.firstName   = clean(readString(d, pool, p.firstNameRef));
            p.lastName    = clean(readString(d, pool, p.lastNameRef));
            p.displayName = joinPlayer(p.firstName, p.lastName, p.slot);
        }
    }

    private static long findPool(byte[] d, List<Team> teams) {
        if (validatePool(d, STD_POOL, teams)) return STD_POOL;
        if (validatePool(d, CAREER_POOL, teams)) return CAREER_POOL;
        return findPoolByAnchors(d, teams);
    }

    private static boolean validatePool(byte[] d, long pool, List<Team> teams) {
        int sane = 0;
        int n = Math.min(30, teams.size());
        for (int i = 0; i < n; i++) {
            Team t = teams.get(i);
            String name = clean(readString(d, pool, t.teamNameRef));
            String abbr = clean(readString(d, pool, t.abbreviationRef));
            if (name.length() >= 2 && name.length() <= 32
                    && abbr.length() >= 2 && abbr.length() <= 5) sane++;
        }
        return sane >= 26;
    }

    private static long findPoolByAnchors(byte[] d, List<Team> teams) {
        int[] slots = {0, 1, 2, 4, 13, 28};
        String[] names = {"76ers", "Bucks", "Bulls", "Celtics", "Lakers", "Warriors"};
        for (int s = 0; s < slots.length; s++) {
            int slot = slots[s];
            if (slot >= teams.size()) continue;
            long ref = teams.get(slot).teamNameRef;
            if (!isStringRef(ref)) continue;
            byte[] needle = utf16le(names[s]);
            long idx = ref & STRING_INDEX_MASK;
            long expectedOffset = idx * 16;
            for (int shift = 0; shift < 8; shift++) {
                for (int pos = 0; pos <= d.length - needle.length; pos++) {
                    if (matchShifted(d, pos, shift, needle)) {
                        long candidate = (long) pos * 8 + shift - expectedOffset;
                        if (candidate >= 0 && candidate < (long) d.length * 8
                                && validatePool(d, candidate, teams)) return candidate;
                    }
                }
            }
        }
        return -1;
    }

    private static boolean matchShifted(byte[] d, int pos, int shift, byte[] needle) {
        for (int i = 0; i < needle.length; i++) {
            if (shiftedByte(d, pos + i, shift) != (needle[i] & 0xFF)) return false;
        }
        return true;
    }

    private static byte[] utf16le(String s) {
        byte[] out = new byte[s.length() * 2];
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            out[i * 2]     = (byte) (c & 0xFF);
            out[i * 2 + 1] = (byte) ((c >>> 8) & 0xFF);
        }
        return out;
    }

    private static boolean isStringRef(long ref) {
        return ((ref >>> 21) & 0xFF) == STRING_SECTION;
    }

    private static String readString(byte[] d, long poolOffset, long ref) {
        if (!isStringRef(ref)) return "";
        long idx = ref & STRING_INDEX_MASK;
        long start = poolOffset + idx * 16;
        long totalBits = (long) d.length * 8;
        if (start < 0 || start + 16 > totalBits) return "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 96; i++) {
            long bp = start + (long) i * 16;
            if (bp + 16 > totalBits) break;
            int raw = (int) readBits(d, bp, 16);
            int code = ((raw & 0xFF) << 8) | ((raw >>> 8) & 0xFF);
            if (code == 0 || code == 0xFFFF) break;
            if (code < 32 && code != 9) return "";
            sb.append((char) code);
        }
        return sb.toString();
    }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.trim();
        StringBuilder sb = new StringBuilder();
        boolean pending = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) {
                if (sb.length() > 0) pending = true;
            } else {
                if (pending) sb.append(' ');
                pending = false;
                sb.append(c);
            }
        }
        return sb.toString().trim();
    }

    private static String joinPlayer(String first, String last, int slot) {
        String f = clean(first);
        String l = clean(last);
        if (f.isEmpty() && l.isEmpty()) return "Player " + slot;
        if (f.isEmpty()) return l;
        if (l.isEmpty()) return f;
        return f + " " + l;
    }

    private static String joinTeam(String city, String team, String display) {
        String c = clean(city);
        String t = clean(team);
        String dd = clean(display);
        if (!c.isEmpty() && !t.isEmpty()) {
            if (t.toLowerCase().startsWith(c.toLowerCase() + " ")) return t;
            return c + " " + t;
        }
        if (!t.isEmpty()) return t;
        if (!c.isEmpty()) return c;
        return dd;
    }

    private static byte[] paddedAscii(String s) {
        byte[] out = new byte[64];
        try {
            byte[] b = s.getBytes("US-ASCII");
            System.arraycopy(b, 0, out, 0, Math.min(b.length, 64));
        } catch (Exception ignored) {}
        return out;
    }

    private static byte[] readAll(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream((int) f.length())) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static int readBe32(byte[] d, int o) {
        return ((d[o] & 0xFF) << 24) | ((d[o+1] & 0xFF) << 16)
             | ((d[o+2] & 0xFF) << 8) | (d[o+3] & 0xFF);
    }

    private static int readLe32(byte[] d, int o) {
        return (d[o] & 0xFF) | ((d[o+1] & 0xFF) << 8)
             | ((d[o+2] & 0xFF) << 16) | ((d[o+3] & 0xFF) << 24);
    }

    private static void writeLe32(byte[] d, int o, int v) {
        d[o]   = (byte) v;
        d[o+1] = (byte) (v >>> 8);
        d[o+2] = (byte) (v >>> 16);
        d[o+3] = (byte) (v >>> 24);
    }

    private RosterLoader() {}
   
    // Add this to help translate the web scraper's string names to rating indices
public static int getRatingIndexFromLabel(String label) {
    String[][] ratingMap = {
        {"Close Shot", "Close Shot"}, {"Mid-Range Shot", "Mid-Range Shot"},
        {"Ball Handle", "Ball Handle"}, {"Three-Point Shot", "Three-Point Shot"},
        {"Free Throw", "Free Throw"}, {"Layup", "Layup"},
        {"Dunk", "Driving Dunk"}, {"Standing Dunk", "Standing Dunk"},
        {"Hustle", "Hustle"}, {"Passing", "Pass Accuracy"},
        {"Low Post Defense", "Interior Defense"}, {"Low Post Offense", "Post Control"},
        {"Block", "Block"}, {"Hands", "Hands"}, {"Steal", "Steal"},
        {"Speed", "Speed"}, {"Stamina", "Stamina"}, {"Vertical", "Vertical"},
        {"Offensive Rebound", "Offensive Rebound"}, {"Defensive Rebound", "Defensive Rebound"},
        {"Durability", "Overall Durability"}, {"Consistency", "Offensive Consistency"},
        {"On Ball Defense", "Perimeter Defense"}, {"Quickness", "Agility"},
        {"Strength", "Strength"}, {"Post Fadeaway", "Post Fade"},
        {"Post Hook", "Post Hook"}
    };

    for (int i = 0; i < ratingMap.length; i++) {
        // Check if the passed label matches either the web name or the local name
        if (ratingMap[i][0].equalsIgnoreCase(label) || ratingMap[i][1].equalsIgnoreCase(label)) {
            return i; // Return the index (0 to 26)
        }
    }
    return -1; // Not found
}
    
    // Translate web tendency names to local tendency indices
public static int getTendencyIndexFromLabel(String label) {
    String[][] map = {
        {"Shot", "Shot"}, {"Shot Close", "Shot Close"}, {"Shot Medium", "shot midrange t"},
        {"Shot Three", "shot three t"}, {"Drive", "Drive"}, {"Drive Right", "Drive Right"},
        {"Triple Threat Pump Fake", "TT Pump Fake"}, {"Triple Threat Jab Step", "TT Jab Step"},
        {"Triple Threat Nothing", "triple threat nothing t"}, {"Triple Threat Shoot", "TT Shoot"},
        {"Setup Sizeup", "setup sizeup t"}, {"Setup Hesitation", "setup hesitation t"},
        {"Setup Nothing", "setup nothing t"}, {"Dribble Crossover", "dribble crossover t"},
        {"Dribble Spin", "dribble spin t"}, {"Dribble Step Back", "dribble step back t"},
        {"Dribble Half Spin", "dribble half spin t"}, {"Dribble Double Cross", "dribble double cross t"},
        {"Dribble Behind Back", "dribble behind back t"}, {"Dribble Hesitation", "dribble hesitation t"},
        {"Dribble In And Out", "dribble in and out t"}, {"Dribble Nothing", "dribble nothing t"},
        {"Finish Attack", "finish attack t"}, {"Crash", "Crash"}, {"Touch", "touch t"},
        {"Post Up", "Post Up"}, {"Roll Vs Fade", "roll vs fade t"}, {"Post Spin", "Post Spin"},
        {"Post Shimmy Shot", "Post Shimmy Shot"}, {"Post Face Up", "Post Face Up"},
        {"Post Back Down", "Post Back Down"}, {"Post Aggressive Back Down", "post aggressive back down t"},
        {"Post Shoot", "post shoot t"}, {"Post Drive", "Post Drive"}, {"Post Hop Shot", "Post Hop Shot"},
        {"Putback", "Putback"}, {"Flashy Pass", "Flashy Pass"}, {"Alley Oop", "Alley-Oop"},
        {"Interception", "interception t"}, {"Take Charge", "Take Charge"}, {"On Ball Steal", "On-Ball Steal"},
        {"Contest Shot", "Contest Shot"}, {"Foul", "Foul"}, {"Hard Foul", "Hard Foul"},
        {"Use Glass", "Use Glass"}, {"Spin Jumper", "Spin Jumper"}, {"Alley Oop Pass", "Alley-Oop Pass"}
    };
    for (int i = 0; i < map.length; i++) {
        if (map[i][0].equalsIgnoreCase(label) || map[i][1].equalsIgnoreCase(label)) {
            return i;
        }
    }
    return -1;
}

// Translate web badge names to the actual 2K20 badge IDs
public static int getBadgeIdFromLabel(String label) {
    String[][] map = {
        {"Posterizer", "1"}, {"Acrobat", "4"}, {"Deadeye", "7"},
        {"Corner Specialist", "8"}, {"Dimer", "12"}, {"Break Starter", "13"},
        {"Brick Wall", "15"}, {"Interceptor", "18"}, {"Bruiser", "23"}
    };
    for (String[] entry : map) {
        if (entry[0].equalsIgnoreCase(label)) {
            return Integer.parseInt(entry[1]);
        }
    }
    return -1;
}
    
}