package com.nocluetools.pro;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class RosterCollegeMap {
    private static final int COLLEGE_NAME_REF_BITS = 0;
    private static final int COLLEGE_STRIDE_BITS = 192;
    public static final long COLLEGE_TAG_BASE = 559939584;
    private static final int COLLEGE_TAG_BITS = 32;

    public static final class CollegeRecord {
        public final int index;
        public final String name;
        public final long nameRef;
        public final long reference;

        CollegeRecord(int i, long j, long j2, String str) {
            this.index = i;
            this.reference = j;
            this.nameRef = j2;
            this.name = (str == null || str.trim().length() == 0) ? String.format(Locale.US, "College %03d", i) : str.trim();
        }
    }

    public static final class Result {
        public final List<CollegeRecord> colleges;
        public final long tableBitOffset;

        Result(long j, List<CollegeRecord> list) {
            this.tableBitOffset = j;
            this.colleges = Collections.unmodifiableList(list);
        }

        public int indexFromReference(long j) {
            long j2 = j - RosterCollegeMap.COLLEGE_TAG_BASE;
            if (j2 < 0 || j2 >= this.colleges.size()) {
                return -1;
            }
            return (int) j2;
        }

        public String[] toChoiceNames() {
            String[] strArr = new String[this.colleges.size() + 1];
            strArr[0] = "None / Unassigned";
            for (int i = 0; i < this.colleges.size(); i++) {
                strArr[i + 1] = this.colleges.get(i).name;
            }
            return strArr;
        }

        public long referenceFromChoice(int i) {
            if (i <= 0) {
                return 0L;
            }
            int i2 = i - 1;
            if (i2 < 0 || i2 >= this.colleges.size()) {
                return 0L;
            }
            return this.colleges.get(i2).reference;
        }

        public int choiceFromReference(long j) {
            int iIndexFromReference = indexFromReference(j);
            return iIndexFromReference < 0 ? 0 : iIndexFromReference + 1;
        }
    }

    public static Result parse(byte[] bArr) throws IOException {
        if (bArr == null || bArr.length < 1024) {
            throw new IOException("Decoded roster payload is empty.");
        }
        long jFindSequentialTable = findSequentialTable(bArr, COLLEGE_TAG_BASE, COLLEGE_STRIDE_BITS, 4);
        if (jFindSequentialTable < 0) {
            throw new IOException("COLLEGEDATA table signature was not found.");
        }
        int iCountSequentialRecords = countSequentialRecords(bArr, jFindSequentialTable, COLLEGE_TAG_BASE, COLLEGE_STRIDE_BITS, 4096);
        if (iCountSequentialRecords < 50) {
            throw new IOException("COLLEGEDATA table is too small: " + iCountSequentialRecords);
        }
        
        ArrayList<CollegeRecord> arrayList = new ArrayList<>(iCountSequentialRecords);
        for (int i = 0; i < iCountSequentialRecords; i++) {
            long bits = readBits(bArr, jFindSequentialTable + (((long) i) * ((long) COLLEGE_STRIDE_BITS)) + 32L, 32);
            // Note: String resolution requires RosterNameResolver which isn't ported yet.
            // We will use the placeholder "College XXX" for now.
            arrayList.add(new CollegeRecord(i, COLLEGE_TAG_BASE | (((long) i) & 1048575), bits, null));
        }
        return new Result(jFindSequentialTable, arrayList);
    }

    private static int countSequentialRecords(byte[] bArr, long j, long j2, int i, int i2) {
        int i3 = 0;
        long length = ((long) bArr.length) * 8;
        while (i3 < i2) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) break;
            if (readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) break;
            i3++;
        }
        return i3;
    }

    private static long findSequentialTable(byte[] bArr, long j, int i, int i2) {
        byte[] bArr2 = {(byte) ((j >>> 24) & 255), (byte) ((j >>> 16) & 255), (byte) ((j >>> 8) & 255), (byte) (j & 255)};
        for (int i3 = 0; i3 <= bArr.length - 4; i3++) {
            if (bArr[i3] == bArr2[0] && bArr[i3 + 1] == bArr2[1] && bArr[i3 + 2] == bArr2[2] && bArr[i3 + 3] == bArr2[3]) {
                long j2 = ((long) i3) * 8;
                if (verifySequence(bArr, j2, j, i, i2)) return j2;
            }
        }
        for (int i4 = 1; i4 < 8; i4++) {
            for (int i5 = 0; i5 < bArr.length - 4; i5++) {
                if (shiftedByte(bArr, i5, i4) == (bArr2[0] & 255) && shiftedByte(bArr, i5 + 1, i4) == (bArr2[1] & 255) && shiftedByte(bArr, i5 + 2, i4) == (bArr2[2] & 255) && shiftedByte(bArr, i5 + 3, i4) == (bArr2[3] & 255)) {
                    long j3 = (((long) i5) * 8) + ((long) i4);
                    if (verifySequence(bArr, j3, j, i, i2)) return j3;
                }
            }
        }
        return -1L;
    }

    private static boolean verifySequence(byte[] bArr, long j, long j2, int i, int i2) {
        long length = ((long) bArr.length) * 8;
        for (int i3 = 0; i3 < i2; i3++) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) return false;
            if (readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) return false;
        }
        return true;
    }

    private static int shiftedByte(byte[] bArr, int i, int i2) {
        return (((bArr[i] & 255) << i2) & 255) | ((bArr[i + 1] & 255) >>> (8 - i2));
    }

    // --- LOCAL BIT READER ---
    private static long readBits(byte[] buf, long bitPos, int width) {
        long result = 0;
        for (int i = 0; i < width; i++) {
            long p = bitPos + i;
            int b = buf[(int)(p >>> 3)] & 255;
            result = (result << 1) | ((b >>> (7 - (int)(p & 7))) & 1);
        }
        return result & 0xFFFFFFFFL;
    }

    RosterCollegeMap() {}
}