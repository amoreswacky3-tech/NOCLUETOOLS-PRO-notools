package com.nocluetools.pro;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;

/** Bounded neutral OBJ subset. Keeps file coordinates/UVs; never centers source data. */
public final class ObjGeometryReader {
    private ObjGeometryReader() {}
    public static ObjEngine.ObjModel parse(byte[] bytes)throws IOException {
        if(bytes==null||bytes.length>MeshInterchange.MAX_BYTES)throw new IOException("OBJ byte limit/null input");
        String text;
        try{text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();}
        catch(CharacterCodingException e){throw new IOException("OBJ must be UTF-8 text",e);}
        if(text.startsWith("\ufeff"))text=text.substring(1);
        ObjEngine.ObjModel m=new ObjEngine.ObjModel();m.rawInterchangeCoordinates=true;m.flipTextureV=false;m.provenance=MeshInterchange.NOTICE;
        BufferedReader reader=new BufferedReader(new StringReader(text));String line,label=null;int number=0;long corners=0;
        while((line=reader.readLine())!=null){number++;if(line.length()>16384)throw new IOException("OBJ line too long at "+number);
            int comment=line.indexOf('#');if(comment>=0)line=line.substring(0,comment);line=line.trim();if(line.isEmpty())continue;
            String[] words=line.split("\\s+");
            try{
                switch(words[0]){
                    case "v":
                        if(words.length!=4&&words.length!=5)throw new IOException("Only XYZ vertices (optional w=1) supported");
                        if(words.length==5&&finite(words[4])!=1f)throw new IOException("Non-unit homogeneous vertex unsupported");
                        m.vertices.add(new float[]{finite(words[1]),finite(words[2]),finite(words[3])});break;
                    case "vt":
                        if(words.length!=3&&words.length!=4)throw new IOException("Two-component UVs required");
                        if(words.length==4&&finite(words[3])!=0f)throw new IOException("Nonzero third texture coordinate unsupported");
                        m.texcoords.add(new float[]{finite(words[1]),finite(words[2])});break;
                    case "vn":
                        if(words.length!=4)throw new IOException("XYZ normal required");m.normals.add(new float[]{finite(words[1]),finite(words[2]),finite(words[3])});break;
                    case "f":
                        int n=words.length-1;if(n<3||n>1024)throw new IOException("Face corner count unsupported");corners+=n;
                        if(corners>MeshInterchange.MAX_CORNERS)throw new IOException("OBJ corner limit");
                        int[] v=new int[n],uv=new int[n],normal=new int[n];Arrays.fill(uv,-1);Arrays.fill(normal,-1);
                        for(int i=0;i<n;i++){String[] ref=words[i+1].split("/",-1);if(ref.length>3)throw new IOException("Face reference has too many fields");
                            v[i]=index(ref[0],m.vertices.size());
                            if(ref.length>1&&!ref[1].isEmpty())uv[i]=index(ref[1],m.texcoords.size());
                            if(ref.length>2&&!ref[2].isEmpty())normal[i]=index(ref[2],m.normals.size());}
                        m.faces.add(new ObjEngine.ObjModel.Face(v,uv,normal,label));break;
                    case "g": case "o": label=line;break;
                    case "mtllib": case "usemtl": case "s": break; // Geometry only; no external files followed.
                    default: throw new IOException("Unsupported OBJ record: "+words[0]);
                }
                if(m.vertices.size()>MeshInterchange.MAX_VERTICES||m.texcoords.size()>MeshInterchange.MAX_CORNERS||m.normals.size()>MeshInterchange.MAX_CORNERS||m.faces.size()>MeshInterchange.MAX_FACES)throw new IOException("OBJ count limit");
            }catch(NumberFormatException e){throw new IOException("OBJ number error at line "+number,e);}
            catch(IOException e){throw new IOException("OBJ line "+number+": "+e.getMessage(),e);}
        }
        MeshInterchange.validate(m);return m;
    }
    private static float finite(String s)throws IOException {float f=Float.parseFloat(s);if(Float.isNaN(f)||Float.isInfinite(f))throw new IOException("Nonfinite value");return f;}
    private static int index(String s,int size)throws IOException {
        int n=Integer.parseInt(s);if(n==0)throw new IOException("OBJ index zero is invalid");
        if(n<0){long v=(long)size+n;if(v<0||v>=size)throw new IOException("Relative index outside declared data");return(int)v;}
        return n-1; // Positive forward references checked against complete arrays at EOF.
    }
}
