package com.nocluetools.pro;

public class IffRewriter {
    public static class Patch {
        public long offset;
        public byte[] data;
        public Patch(long offset, byte[] data) {
            this.offset = offset;
            this.data = data;
        }
    }
}