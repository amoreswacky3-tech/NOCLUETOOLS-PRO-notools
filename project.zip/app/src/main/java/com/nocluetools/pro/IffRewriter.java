package com.nocluetools.pro;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class IffRewriter {
    
    public static class Patch {
        public long offset;
        public byte[] data;
        public Patch(long offset, byte[] data) {
            this.offset = offset;
            this.data = data;
        }
    }

    public static void saveIff(byte[] originalData, List<Patch> patches, File outputFile) throws IOException {
        // 1. Apply all patches directly into the byte array
        for (Patch p : patches) {
            if (p.offset >= 0 && p.offset + p.data.length <= originalData.length) {
                System.arraycopy(p.data, 0, originalData, (int) p.offset, p.data.length);
            }
        }

        // 2. Fix the IFF FORM header size (Bytes 4 to 7 must be Big-Endian)
        if (originalData.length >= 8 && new String(originalData, 0, 4).equals("FORM")) {
            int newFormSize = originalData.length - 8;
            originalData[4] = (byte) ((newFormSize >> 24) & 0xFF);
            originalData[5] = (byte) ((newFormSize >> 16) & 0xFF);
            originalData[6] = (byte) ((newFormSize >> 8) & 0xFF);
            originalData[7] = (byte) (newFormSize & 0xFF);
        }

        // 3. Write the fixed IFF back to the file
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            fos.write(originalData);
            fos.flush();
        }
    }
}