package com.nocluetools.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class HeadHairDialog {

    private final Activity activity;
    private final File obbFile;

    private AlertDialog dialog;
    private ListView listView;
    private TextView statusView;

    private final List<String> allNames = new ArrayList<>();
    private final List<String> allPaths = new ArrayList<>();
    private final List<Integer> allIndices = new ArrayList<>();

    private final List<String> visibleNames = new ArrayList<>();
    private final List<Integer> visibleRealIdx = new ArrayList<>();

    public HeadHairDialog(Activity activity, File obbFile) {
        this.activity = activity;
        this.obbFile = obbFile;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_head_hair, null);
        b.setView(v);

        TextView title = v.findViewById(R.id.headTitle);
        statusView = v.findViewById(R.id.headStatus);
        listView = v.findViewById(R.id.headList);
        EditText search = v.findViewById(R.id.headSearch);
        TextView close = v.findViewById(R.id.headClose);
        TextView openIff = v.findViewById(R.id.btnOpenIffStandalone);
if (openIff != null) {
    openIff.setOnClickListener(x -> {
        android.content.Intent i = new android.content.Intent(
                android.content.Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        activity.startActivityForResult(i, 9001);
    });
}

TextView openObb = v.findViewById(R.id.btnOpenIffInObb);
if (openObb != null) {
    openObb.setOnClickListener(x -> {
        // The list IS the OBB browser — scroll down to it
        statusView.setText("Select a file from the list below");
    });
}

        title.setText("HEAD / HAIR  ·  " + obbFile.getName());
        statusView.setText("Loading…");

        close.setOnClickListener(x -> dialog.dismiss());

        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                applyFilter(s.toString().toLowerCase().trim());
            }
        });

        dialog = b.create();
        dialog.show();

        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF0E1117));
        }

        loadFileList();
    }

    private void loadFileList() {
        new Thread(() -> {
            try {
    Python py = Python.getInstance();
    PyObject bridge = py.getModule("noclue2k_bridge");
    
    // Get the file list from the already open OBB session
    PyObject result = bridge.callAttr("obb_rows_bridge", currentObbSessionId);
    String json = result.toString();

    activity.runOnUiThread(() -> {
        try {
            org.json.JSONObject root = new org.json.JSONObject(json);
            if (!root.getBoolean("ok")) {
                statusView.setText("Error: " + root.optString("error"));
                return;
            }

            // The engine returns the files inside the "rows" array
            JSONArray arr = root.getJSONArray("rows");
            allNames.clear();
            allPaths.clear();
            allIndices.clear();

            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String name = o.optString("name", "");
                String lower = name.toLowerCase();
                
                // Show only IFFs and CFDs
                if (lower.endsWith(".iff") || lower.endsWith(".cfd")) {
                    // Assuming you have these lists ready to populate
                    // allNames.add(name);
                    // allIndices.add(o.getInt("index"));
                }
            }
            
            // adapter.notifyDataSetChanged(); // Don't forget to refresh your adapter!
            
        } catch (Exception e) {
            statusView.setText("Parse error: " + e.getMessage());
        }
    });
} catch (Exception e) {
    statusView.setText("Error: " + e.getMessage());
}

                activity.runOnUiThread(() -> {
                    if (json == null || json.startsWith("ERROR")) {
                        statusView.setText("Error: " + json);
                        return;
                    }
                    try {
                        JSONArray arr = new JSONArray(json);
                        allNames.clear();
                        allPaths.clear();
                        allIndices.clear();
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject o = arr.getJSONObject(i);
                            String name = o.optString("name", "");
                            String lower = name.toLowerCase();
                            // Show only IFFs and CFDs (candidates for heads)
                            if (lower.endsWith(".iff") || lower.endsWith(".iff2")
                                    || lower.endsWith(".cdf")) {
                                allNames.add(name);
                                allPaths.add(name);
                                allIndices.add(o.optInt("index", i));
                            }
                        }
                        applyFilter("");
                        statusView.setText("Found " + allNames.size() + " IFF/CFD files");
                    } catch (Exception e) {
                        statusView.setText("Parse error: " + e.getMessage());
                    }
                });
            } catch (Exception e) {
                final String err = e.getMessage();
                activity.runOnUiThread(() -> statusView.setText("Load failed: " + err));
            }
        }).start();
    }

    private void applyFilter(String q) {
        visibleNames.clear();
        visibleRealIdx.clear();
        for (int i = 0; i < allNames.size(); i++) {
            if (q.isEmpty() || allNames.get(i).toLowerCase().contains(q)) {
                visibleNames.add(allNames.get(i));
                visibleRealIdx.add(allIndices.get(i));
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                activity, android.R.layout.simple_list_item_1, visibleNames) {
           @Override
public View getView(int position, View cv, android.view.ViewGroup parent) {
    View v = super.getView(position, cv, parent);
    TextView t = v.findViewById(android.R.id.text1);
    t.setTextColor(0xFFDDDDDD);
    t.setTextSize(12f);
    t.setPadding(20, 20, 20, 20);
    return v;
}
        };
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String pickedName = visibleNames.get(position);
            openInObjEditor(pickedName);
        });
    }

    private void openInObjEditor(String entryName) {
        statusView.setText("Extracting " + entryName + "…");
        new Thread(() -> {
            try {
                // Extract IFF from OBB to cache
                File cacheIff = new File(activity.getCacheDir(), "head_temp.iff");
                // 1. Get the file index (Assuming you have a list of indices matching the names)
// If your method takes an index instead of name, use that directly!
int entryIndex = -1;
for (int i = 0; i < allNames.size(); i++) {
    if (allNames.get(i).equals(entryName)) {
        entryIndex = allIndices.get(i); // Make sure you have this list!
        break;
    }
}

if (entryIndex == -1) {
    activity.runOnUiThread(() -> statusView.setText("Error: File index not found"));
    return;
}

Python py = Python.getInstance();
PyObject bridge = py.getModule("noclue2k_bridge");

// 2. Extract using the new engine
PyObject result = bridge.callAttr("extract_iff_bridge", currentObbSessionId, entryIndex, cacheIff.getParent());
org.json.JSONObject json = new org.json.JSONObject(result.toString());

final String status;
final File extractedFile;

if (json.getBoolean("ok")) {
    status = "Success";
    extractedFile = new File(json.getString("path"));
} else {
    status = "Error: " + json.getString("error");
    extractedFile = null;
}

                final String status = result.toString();
                activity.runOnUiThread(() -> {
                    if (status.startsWith("Success") && cacheIff.exists()) {
                        dialog.dismiss();
                        ObjEditorDialog obj = new ObjEditorDialog(activity);
                        // Pass the IFF file to it
                        obj.show();
                        Toast.makeText(activity,
                                "Mesh: " + entryName, Toast.LENGTH_SHORT).show();
                    } else {
                        statusView.setText("Extract failed: " + status);
                    }
                });
            } catch (Exception e) {
                final String err = e.getMessage();
                activity.runOnUiThread(() -> statusView.setText("Error: " + err));
            }
        }).start();
    }
}