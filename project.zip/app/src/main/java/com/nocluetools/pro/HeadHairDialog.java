package com.nocluetools.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HeadHairDialog {

    private final Activity activity;
    private final File obbFile;

    private AlertDialog dialog;
    private ListView listView;
    private TextView statusView;

    private final List<String> allNames = new ArrayList<>();
    private final List<String> allPaths = new ArrayList<>();
    private final List<Integer> allIndices = new ArrayList<>();

    private final List<String> visibleNames = new ArrayList<>();
    private final List<Integer> visibleRealIdx = new ArrayList<>();

    public HeadHairDialog(Activity activity, File obbFile) {
        this.activity = activity;
        this.obbFile = obbFile;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity).inflate(R.layout.dialog_head_hair, null);
        b.setView(v);

        TextView title = v.findViewById(R.id.headTitle);
        statusView = v.findViewById(R.id.headStatus);
        listView = v.findViewById(R.id.headList);
        EditText search = v.findViewById(R.id.headSearch);
        TextView close = v.findViewById(R.id.headClose);

        TextView openIff = v.findViewById(R.id.btnOpenIffStandalone);
        if (openIff != null) {
            openIff.setOnClickListener(x -> {
                android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                activity.startActivityForResult(i, 9001); // Sends request to MainActivity
                dialog.dismiss();
            });
        }

        TextView openObb = v.findViewById(R.id.btnOpenIffInObb);
        if (openObb != null) {
            openObb.setOnClickListener(x -> {
                if (obbFile == null) {
                    Toast.makeText(activity, "No OBB opened", Toast.LENGTH_SHORT).show();
                } else {
                    statusView.setText("Select a file from the list below");
                }
            });
        }

        // 👇 SAFE NULL CHECK HERE 👇
        if (obbFile != null) {
            title.setText("HEAD / HAIR  ·  " + obbFile.getName());
        } else {
            title.setText("HEAD / HAIR  ·  Standalone");
        }
        
        statusView.setText("Loading…");

        close.setOnClickListener(x -> dialog.dismiss());

        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                applyFilter(s.toString().toLowerCase().trim());
            }
        });

        dialog = b.create();
        dialog.show();

        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF0E1117));
        }

        // 👇 SAFE NULL CHECK HERE 👇
        if (obbFile != null) {
            loadFileList();
        } else {
            statusView.setText("No OBB loaded. Tap 'OPEN IFF' to select a file.");
        }
    }

    private void loadFileList() {
        if (obbFile == null) return; // Safety check

        new Thread(() -> {
            try {
                Python py = Python.getInstance();
                PyObject mod = py.getModule("iff_viewer");
                final String json = mod.callAttr("get_file_list_from_java", obbFile.getAbsolutePath()).toString();

                activity.runOnUiThread(() -> {
                    if (json == null || json.startsWith("ERROR")) {
                        statusView.setText("Error: " + json);
                        return;
                    }
                    try {
                        JSONArray arr = new JSONArray(json);
                        allNames.clear();
                        allPaths.clear();
                        allIndices.clear();
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject o = arr.getJSONObject(i);
                            String name = o.optString("name", "");
                            String lower = name.toLowerCase();
                            if (lower.endsWith(".iff") || lower.endsWith(".iff2") || lower.endsWith(".cdf")) {
                                allNames.add(name);
                                allPaths.add(name);
                                allIndices.add(o.optInt("index", i));
                            }
                        }
                        applyFilter("");
                        statusView.setText("Found " + allNames.size() + " IFF/CFD files");
                    } catch (Exception e) {
                        statusView.setText("Parse error: " + e.getMessage());
                    }
                });
            } catch (Exception e) {
                final String err = e.getMessage();
                activity.runOnUiThread(() -> statusView.setText("Load failed: " + err));
            }
        }).start();
    }

    private void applyFilter(String q) {
        visibleNames.clear();
        visibleRealIdx.clear();
        for (int i = 0; i < allNames.size(); i++) {
            if (q.isEmpty() || allNames.get(i).toLowerCase().contains(q)) {
                visibleNames.add(allNames.get(i));
                visibleRealIdx.add(allIndices.get(i));
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(activity, android.R.layout.simple_list_item_1, visibleNames) {
            @Override
            public View getView(int position, View cv, android.view.ViewGroup parent) {
                View v = super.getView(position, cv, parent);
                TextView t = v.findViewById(android.R.id.text1);
                t.setTextColor(0xFFDDDDDD);
                t.setTextSize(12f);
                t.setPadding(20, 20, 20, 20);
                return v;
            }
        };
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String pickedName = visibleNames.get(position);
            openInObjEditor(pickedName);
        });
    }

    private void openInObjEditor(String entryName) {
        if (obbFile == null) return; // Safety check
        
        statusView.setText("Extracting " + entryName + "…");
        new Thread(() -> {
            try {
                File cacheIff = new File(activity.getCacheDir(), "head_temp.iff");
                Python py = Python.getInstance();
                PyObject mod = py.getModule("iff_viewer");
                PyObject result = mod.callAttr("extract_iff_from_obb_by_name",
                        obbFile.getAbsolutePath(),
                        entryName,
                        cacheIff.getAbsolutePath());

                final String status = result.toString();
                activity.runOnUiThread(() -> {
                    if (status.startsWith("Success") && cacheIff.exists()) {
                        dialog.dismiss();
                        ObjEditorDialog obj = new ObjEditorDialog(activity);
                        obj.show();
                        Toast.makeText(activity, "Mesh: " + entryName, Toast.LENGTH_SHORT).show();
                    } else {
                        statusView.setText("Extract failed: " + status);
                    }
                });
            } catch (Exception e) {
                final String err = e.getMessage();
                activity.runOnUiThread(() -> statusView.setText("Error: " + err));
            }
        }).start();
    }
}