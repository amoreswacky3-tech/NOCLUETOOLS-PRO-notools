package com.nocluetools.pro;

import android.text.InputType;
import java.util.ArrayList;
import java.util.List;
import android.widget.EditText; 
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Map;

public class PlayerEditorProDialog {

    private static final String[] TABS = {
            "BIO", "APPEAR", "RATINGS", "ACCESS",
            "ANIM", "TEND", "HOT", "CONTRACT",
            "DRAFT", "PLAYTYPES", "BADGES", "SIG"
    };
    private static final String[] SHOE_BRAND = {"Generic", "Nike", "Adidas", "Jordan", "Converse", "Reebok", "Under Armour", "Spalding"};
    private static final String[] UNDERSHIRT = {"None", "Body Shirt", "Short-Sleeve", "Long-Sleeve"};
    private static final String[] ARM = {"None", "Arm Sleeve", "Arm Sleeve w/ Pad", "Short Sleeve", "Shoulder Sleeve", "Full Arm Sleeve", "Adidas Arm Sleeve"};
    private static final String[] KNEE = {"None", "Knee Pad", "Hex Knee Pad", "Knee Brace", "Knee Sleeve", "Knee Strap"};
    private static final String[] ANKLE = {"None", "Ankle Brace", "Ankle Wrap"};
    
    private final Activity activity;
    private final RosterLoader.Player player;
    private final Map<Integer, String> teamNames;
    private final Map<Integer, String> teamAbbrs;

    private AlertDialog dialog;
    private LinearLayout tabRow;
    private LinearLayout content;
    private TextView title, subtitle;
    private int currentTab = 0;

    // Edit fields (only Bio is editable for now)
    private EditText etJersey;
    private EditText etDraftYear;
    private EditText etDraftRound;
    private EditText etDraftPick;
    private EditText etCfId;
    private EditText etPortrait;
    private List<EditText> ratingInputs = new ArrayList<>();
    private List<EditText> tendencyInputs = new ArrayList<>();
    private List<EditText> badgeInputs = new ArrayList<>();
    private List<int[]> accessoryValues = new ArrayList<>();
    private List<int[]> animValues = new ArrayList<>();

    public PlayerEditorProDialog(Activity activity,
                                 RosterLoader.Player player,
                                 Map<Integer, String> teamNames,
                                 Map<Integer, String> teamAbbrs) {
        this.activity = activity;
        this.player = player;
        this.teamNames = teamNames;
        this.teamAbbrs = teamAbbrs;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_player_editor_pro, null);
        b.setView(v);

        title    = v.findViewById(R.id.pepTitle);
        subtitle = v.findViewById(R.id.pepSubtitle);
        tabRow   = v.findViewById(R.id.pepTabRow);
        content  = v.findViewById(R.id.pepContent);

        TextView close = v.findViewById(R.id.pepClose);
        TextView save  = v.findViewById(R.id.pepSave);
        TextView done  = v.findViewById(R.id.pepDone);

        title.setText("EDIT: " + player.displayName);

        String abbr = player.activeTeamSlot >= 0
                ? teamAbbrs.getOrDefault(player.activeTeamSlot, "")
                : "FA";
        subtitle.setText(String.format(Locale.US,
                "S%04d  ·  #%d  ·  CF=%d  ·  %s",
                player.slot, player.jerseyNumber, player.cyberfaceId, abbr));

        close.setOnClickListener(x -> dialog.dismiss());
        done.setOnClickListener(x -> dialog.dismiss());
        save.setOnClickListener(x -> onSaveClicked());

        buildTabButtons();
        selectTab(0);

        dialog = b.create();
        dialog.show();

        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF0E1117));
        }
    }

    // ------------------------------------------------------------------
    // Tab bar
    // ------------------------------------------------------------------
    private void buildTabButtons() {
        tabRow.removeAllViews();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = new TextView(activity);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(36));
            lp.setMargins(0, 0, dp(6), 0);
            t.setLayoutParams(lp);
            t.setText(TABS[i]);
            t.setTextSize(11);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(dp(16), 0, dp(16), 0);
            t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
            t.setLetterSpacing(0.1f);
            t.setOnClickListener(x -> selectTab(idx));
            tabRow.addView(t);
        }
    }

    private void selectTab(int idx) {
        currentTab = idx;

        // Highlight active tab
        for (int i = 0; i < tabRow.getChildCount(); i++) {
            TextView t = (TextView) tabRow.getChildAt(i);
            if (i == idx) {
                t.setBackgroundResource(R.drawable.bg_btn_primary);
                t.setTextColor(0xFFFFFFFF);
            } else {
                t.setBackgroundResource(R.drawable.bg_btn_secondary);
                t.setTextColor(0xFF6B7280);
            }
        }

        content.removeAllViews();
        etJersey = etCfId = etPortrait = null;

        switch (TABS[idx]) {
            case "BIO":       buildBio(); break;
            case "APPEAR":    buildAppearance(); break;
            case "RATINGS":   buildComingSoon("Ratings"); break;
            case "ACCESS": buildAccessories(); break;
            case "ANIM":      buildAnimations(); break;
            case "TEND":      buildComingSoon("Tendencies"); break;
            case "HOT":       buildComingSoon("Hot Zones"); break;
            case "CONTRACT":  buildComingSoon("Contract"); break;
            case "DRAFT":     buildComingSoon("Draft Info"); break;
            case "PLAYTYPES": buildComingSoon("Play Types"); break;
            case "BADGES":    buildComingSoon("Badges"); break;
            case "SIG":       buildComingSoon("Signature Skills"); break;
        }
    }

    // ------------------------------------------------------------------
    // Section: BIO (editable)
    // ------------------------------------------------------------------
    private void buildBio() {
        addHeader("EDITABLE FIELDS");

        etJersey   = addEdit("Jersey number", String.valueOf(player.jerseyNumber));
        etCfId     = addEdit("Cyberface ID",  String.valueOf(player.cyberfaceId));
        etPortrait = addEdit("Portrait ID",   String.valueOf(player.portraitId));

        addHeader("READ-ONLY");
        addInfo("Slot",       "S" + String.format(Locale.US, "%04d", player.slot));
        addInfo("First name", player.firstName);
        addInfo("Last name",  player.lastName);

        String teamFull = "Free Agent";
        if (player.activeTeamSlot >= 0) {
            teamFull = teamNames.getOrDefault(player.activeTeamSlot,
                    "Team " + player.activeTeamSlot);
        }
        addInfo("Team", teamFull);

        addHeader("NOTE");
        TextView hint = new TextView(activity);
        hint.setText("Save button is wired to RosterLoader write methods — "
                + "coming next build. Values shown are read-only for now.");
        hint.setTextColor(0xFF6B7280);
        hint.setTextSize(11);
        hint.setPadding(0, dp(8), 0, dp(8));
        content.addView(hint);
    }

    // ------------------------------------------------------------------
    // Section: APPEARANCE (read-only)
    // ------------------------------------------------------------------
    private void buildAppearance() {
        addHeader("BODY");
        addInfo("Body type",   String.valueOf(player.bodyType));
        addInfo("Muscle type", String.valueOf(player.muscleType));
        addInfo("Skin tone",   String.valueOf(player.skinTone));

        addHeader("FACE");
        addInfo("Eye color",   String.valueOf(player.eyeColor));
        addInfo("Cyberface ID", String.valueOf(player.cyberfaceId));
        addInfo("Portrait ID",  String.valueOf(player.portraitId));
    }

    // ------------------------------------------------------------------
    // Coming soon section
    // ------------------------------------------------------------------
    private void buildComingSoon(String label) {
        addHeader(label.toUpperCase(Locale.US));

        TextView tv = new TextView(activity);
        tv.setText("Coming next build\n\nThis tab will edit " + label.toLowerCase(Locale.US)
                + " once the extended RosterLoader offsets are ported.");
        tv.setTextColor(0xFFCCCCCC);
        tv.setTextSize(12);
        tv.setPadding(0, dp(12), 0, dp(12));
        tv.setLineSpacing(0, 1.3f);
        content.addView(tv);
    }

    // ------------------------------------------------------------------
    // Save
    // ------------------------------------------------------------------
    private void onSaveClicked() {
    try {
        // 1. Save Bio
        if (etJersey != null && etCfId != null && etPortrait != null) {
            int newJersey   = Integer.parseInt(etJersey.getText().toString().trim());
            int newCfId     = Integer.parseInt(etCfId.getText().toString().trim());
            int newPortrait = Integer.parseInt(etPortrait.getText().toString().trim());

            RosterLoader.setJersey(player.slot, newJersey);
            RosterLoader.setCyberface(player.slot, newCfId);
            RosterLoader.setPortrait(player.slot, newPortrait);

            player.jerseyNumber = newJersey;
            player.cyberfaceId  = newCfId;
            player.portraitId   = newPortrait;
        }

        // 2. Save Ratings
        for (int i = 0; i < ratingInputs.size(); i++) {
            int val = Integer.parseInt(ratingInputs.get(i).getText().toString().trim());
            RosterLoader.setRating(player.slot, i, val);
        }

        // 3. Save Tendencies
        for (int i = 0; i < tendencyInputs.size(); i++) {
            int val = Integer.parseInt(tendencyInputs.get(i).getText().toString().trim());
            RosterLoader.setTendency(player.slot, i, val);
        }

        // 4. Save Badges
        for (int i = 0; i < badgeInputs.size(); i++) {
            int val = Integer.parseInt(badgeInputs.get(i).getText().toString().trim());
            RosterLoader.setBadgeLevel(player.slot, i, val);
        }

        // 5. Save Accessories
        for (int i = 0; i < accessoryValues.size(); i++) {
            RosterLoader.setAccessory(player.slot, i, accessoryValues.get(i)[0]);
        }
        
        // 6. Save Animations
        for (int i = 0; i < animValues.size(); i++) {
            RosterLoader.setAnimation(player.slot, i, animValues.get(i)[0]);
        }

        // 7. Save Draft Info
        if (etDraftYear != null && etDraftRound != null && etDraftPick != null) {
            int year = Integer.parseInt(etDraftYear.getText().toString().trim());
            int round = Integer.parseInt(etDraftRound.getText().toString().trim());
            int pick = Integer.parseInt(etDraftPick.getText().toString().trim());
            RosterLoader.setDraftInfo(player.slot, year, round, pick);
        }

        // 8. Save to File
        java.io.File outFile = new java.io.File(activity.getCacheDir(), "edited_roster.ros");
        RosterLoader.save(outFile);

        subtitle.setText(String.format(Locale.US, "S%04d · #%d · CF=%d", player.slot, player.jerseyNumber, player.cyberfaceId));
        toast("All changes saved and re-encrypted!");

    } catch (Exception e) {
        toast("Save error: " + e.getMessage());
    }
}

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    private void addHeader(String label) {
        TextView h = new TextView(activity);
        h.setText(label);
        h.setTextColor(0xFF4FC3F7);
        h.setTextSize(10);
        h.setLetterSpacing(0.25f);
        h.setTypeface(h.getTypeface(), android.graphics.Typeface.BOLD);
        h.setPadding(0, dp(12), 0, dp(6));
        content.addView(h);
    }

    private void addInfo(String label, String value) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView l = new TextView(activity);
        l.setText(label);
        l.setTextColor(0xFF8892A0);
        l.setTextSize(12);
        l.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView v = new TextView(activity);
        v.setText(value == null ? "—" : value);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(12);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);

        row.addView(l);
        row.addView(v);
        content.addView(row);
    }

    private EditText addEdit(String hint, String initial) {
        TextView l = new TextView(activity);
        l.setText(hint);
        l.setTextColor(0xFF8892A0);
        l.setTextSize(11);
        l.setPadding(0, dp(8), 0, dp(4));
        content.addView(l);

        EditText e = new EditText(activity);
        e.setText(initial);
        e.setTextColor(0xFFFFFFFF);
        e.setTextSize(13);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        content.addView(e);
        return e;
    }

    private int dp(int v) {
        float d = activity.getResources().getDisplayMetrics().density;
        return (int)(v * d);
    }

    private void toast(String s) {
        Toast.makeText(activity, s, Toast.LENGTH_SHORT).show();
    }
    private void buildAccessories() {
    addHeader("ACCESSORIES");
    
    if (accessoryValues == null) accessoryValues = new ArrayList<>();
    accessoryValues.clear();
    
    for (int i = 0; i < RosterLoader.ACCESSORY_FIELDS.length; i++) {
        RosterLoader.AccessoryField field = RosterLoader.ACCESSORY_FIELDS[i];
        
        // Get the current value from the roster
        int currentVal = RosterLoader.getAccessory(player.slot, i);
        
        // Calculate the max value based on the bit width (e.g., 4 bits = max 15)
        int maxVal = (1 << field.width) - 1;
        
        // This calls the new AccessoryCatalog we created!
        String[] options = AccessoryCatalog.optionsFor(field.label, maxVal);
        
        // Add the label
        TextView l = new TextView(activity);
        l.setText(field.label); l.setTextColor(0xFF8892A0); l.setTextSize(11);
        l.setPadding(0, dp(8), 0, dp(4)); content.addView(l);
        
        // Add the clickable dropdown (EditText)
        EditText e = new EditText(activity);
        e.setFocusable(false); 
        e.setClickable(true);
        e.setText(options[currentVal < options.length ? currentVal : 0]);
        e.setTextColor(0xFFFFFFFF); e.setTextSize(13);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        
        final int[] selectedValue = {currentVal};
        accessoryValues.add(selectedValue); 
        
        e.setOnClickListener(v -> {
            new AlertDialog.Builder(activity)
                .setTitle("Select " + field.label)
                .setItems(options, (dialog, which) -> {
                    selectedValue[0] = which;
                    e.setText(options[which]);
                })
                .show();
        });
        
        content.addView(e);
    }
}

private void buildDraft() {
    addHeader("DRAFT INFO");
    // Draft year is stored as an offset from 2000 (max 5 bits = 31, so up to 2031)
    etDraftYear  = addEdit("Draft Year (e.g. 2019)", "2019", InputType.TYPE_CLASS_NUMBER);
    // Draft round is 2 bits (0-3)
    etDraftRound = addEdit("Draft Round (1-7)", "1", InputType.TYPE_CLASS_NUMBER);
    // Draft pick is 5 bits (0-31)
    etDraftPick  = addEdit("Draft Pick (1-60)", "1", InputType.TYPE_CLASS_NUMBER);
}

private void buildAnimations() {
    addHeader("ANIMATIONS");
    
    if (animValues == null) animValues = new ArrayList<>();
    animValues.clear();
    
    for (int i = 0; i < RosterLoader.ANIMATION_FIELDS.length; i++) {
        RosterLoader.AnimationField field = RosterLoader.ANIMATION_FIELDS[i];
        
        int currentVal = RosterLoader.getAnimation(player.slot, i);
        int maxVal = (1 << field.width) - 1;
        
        String[] options = AnimationCatalog.getOptionsForBitOffset(field.serializedBit, maxVal);
        
        TextView l = new TextView(activity);
        l.setText(field.label); l.setTextColor(0xFF8892A0); l.setTextSize(11);
        l.setPadding(0, dp(8), 0, dp(4)); content.addView(l);
        
        EditText e = new EditText(activity);
        e.setFocusable(false); 
        e.setClickable(true);
        e.setText(options[currentVal < options.length ? currentVal : 0]);
        e.setTextColor(0xFFFFFFFF); e.setTextSize(13);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        
        final int[] selectedValue = {currentVal};
        animValues.add(selectedValue); 
        
        e.setOnClickListener(v -> {
            new AlertDialog.Builder(activity)
                .setTitle("Select " + field.label)
                .setItems(options, (dialog, which) -> {
                    selectedValue[0] = which;
                    e.setText(options[which]);
                })
                .show();
        });
        content.addView(e);
    }
}

}