package com.nocluetools.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Map;

public class PlayerEditorProDialog {

    private static final String[] TABS = {
            "BIO", "APPEAR", "RATINGS", "ACCESS",
            "ANIM", "TEND", "HOT", "CONTRACT",
            "DRAFT", "PLAYTYPES", "BADGES", "SIG"
    };

    private final Activity activity;
    private final RosterLoader.Player player;
    private final Map<Integer, String> teamNames;
    private final Map<Integer, String> teamAbbrs;

    private AlertDialog dialog;
    private LinearLayout tabRow;
    private LinearLayout content;
    private TextView title, subtitle;
    private int currentTab = 0;

    // Edit fields (only Bio is editable for now)
    private EditText etJersey;
    private EditText etCfId;
    private EditText etPortrait;

    public PlayerEditorProDialog(Activity activity,
                                 RosterLoader.Player player,
                                 Map<Integer, String> teamNames,
                                 Map<Integer, String> teamAbbrs) {
        this.activity = activity;
        this.player = player;
        this.teamNames = teamNames;
        this.teamAbbrs = teamAbbrs;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_player_editor_pro, null);
        b.setView(v);

        title    = v.findViewById(R.id.pepTitle);
        subtitle = v.findViewById(R.id.pepSubtitle);
        tabRow   = v.findViewById(R.id.pepTabRow);
        content  = v.findViewById(R.id.pepContent);

        TextView close = v.findViewById(R.id.pepClose);
        TextView save  = v.findViewById(R.id.pepSave);
        TextView done  = v.findViewById(R.id.pepDone);

        title.setText("EDIT: " + player.displayName);

        String abbr = player.activeTeamSlot >= 0
                ? teamAbbrs.getOrDefault(player.activeTeamSlot, "")
                : "FA";
        subtitle.setText(String.format(Locale.US,
                "S%04d  ·  #%d  ·  CF=%d  ·  %s",
                player.slot, player.jerseyNumber, player.cyberfaceId, abbr));

        close.setOnClickListener(x -> dialog.dismiss());
        done.setOnClickListener(x -> dialog.dismiss());
        save.setOnClickListener(x -> onSaveClicked());

        buildTabButtons();
        selectTab(0);

        dialog = b.create();
        dialog.show();

        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF0E1117));
        }
    }

    // ------------------------------------------------------------------
    // Tab bar
    // ------------------------------------------------------------------
    private void buildTabButtons() {
        tabRow.removeAllViews();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = new TextView(activity);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(36));
            lp.setMargins(0, 0, dp(6), 0);
            t.setLayoutParams(lp);
            t.setText(TABS[i]);
            t.setTextSize(11);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(dp(16), 0, dp(16), 0);
            t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
            t.setLetterSpacing(0.1f);
            t.setOnClickListener(x -> selectTab(idx));
            tabRow.addView(t);
        }
    }

    private void selectTab(int idx) {
        currentTab = idx;

        // Highlight active tab
        for (int i = 0; i < tabRow.getChildCount(); i++) {
            TextView t = (TextView) tabRow.getChildAt(i);
            if (i == idx) {
                t.setBackgroundResource(R.drawable.bg_btn_primary);
                t.setTextColor(0xFFFFFFFF);
            } else {
                t.setBackgroundResource(R.drawable.bg_btn_secondary);
                t.setTextColor(0xFF6B7280);
            }
        }

        content.removeAllViews();
        etJersey = etCfId = etPortrait = null;

        switch (TABS[idx]) {
            case "BIO":       buildBio(); break;
            case "APPEAR":    buildAppearance(); break;
            case "RATINGS":   buildComingSoon("Ratings"); break;
            case "ACCESS":    buildComingSoon("Accessories"); break;
            case "ANIM":      buildComingSoon("Animations"); break;
            case "TEND":      buildComingSoon("Tendencies"); break;
            case "HOT":       buildComingSoon("Hot Zones"); break;
            case "CONTRACT":  buildComingSoon("Contract"); break;
            case "DRAFT":     buildComingSoon("Draft Info"); break;
            case "PLAYTYPES": buildComingSoon("Play Types"); break;
            case "BADGES":    buildComingSoon("Badges"); break;
            case "SIG":       buildComingSoon("Signature Skills"); break;
        }
    }

    // ------------------------------------------------------------------
    // Section: BIO (editable)
    // ------------------------------------------------------------------
    private void buildBio() {
        addHeader("EDITABLE FIELDS");

        etJersey   = addEdit("Jersey number", String.valueOf(player.jerseyNumber));
        etCfId     = addEdit("Cyberface ID",  String.valueOf(player.cyberfaceId));
        etPortrait = addEdit("Portrait ID",   String.valueOf(player.portraitId));

        addHeader("READ-ONLY");
        addInfo("Slot",       "S" + String.format(Locale.US, "%04d", player.slot));
        addInfo("First name", player.firstName);
        addInfo("Last name",  player.lastName);

        String teamFull = "Free Agent";
        if (player.activeTeamSlot >= 0) {
            teamFull = teamNames.getOrDefault(player.activeTeamSlot,
                    "Team " + player.activeTeamSlot);
        }
        addInfo("Team", teamFull);

        addHeader("NOTE");
        TextView hint = new TextView(activity);
        hint.setText("Save button is wired to RosterLoader write methods — "
                + "coming next build. Values shown are read-only for now.");
        hint.setTextColor(0xFF6B7280);
        hint.setTextSize(11);
        hint.setPadding(0, dp(8), 0, dp(8));
        content.addView(hint);
    }

    // ------------------------------------------------------------------
    // Section: APPEARANCE (read-only)
    // ------------------------------------------------------------------
    private void buildAppearance() {
        addHeader("BODY");
        addInfo("Body type",   String.valueOf(player.bodyType));
        addInfo("Muscle type", String.valueOf(player.muscleType));
        addInfo("Skin tone",   String.valueOf(player.skinTone));

        addHeader("FACE");
        addInfo("Eye color",   String.valueOf(player.eyeColor));
        addInfo("Cyberface ID", String.valueOf(player.cyberfaceId));
        addInfo("Portrait ID",  String.valueOf(player.portraitId));
    }

    // ------------------------------------------------------------------
    // Coming soon section
    // ------------------------------------------------------------------
    private void buildComingSoon(String label) {
        addHeader(label.toUpperCase(Locale.US));

        TextView tv = new TextView(activity);
        tv.setText("Coming next build\n\nThis tab will edit " + label.toLowerCase(Locale.US)
                + " once the extended RosterLoader offsets are ported.");
        tv.setTextColor(0xFFCCCCCC);
        tv.setTextSize(12);
        tv.setPadding(0, dp(12), 0, dp(12));
        tv.setLineSpacing(0, 1.3f);
        content.addView(tv);
    }

    // ------------------------------------------------------------------
    // Save
    // ------------------------------------------------------------------
    private void onSaveClicked() {
        if (currentTab != 0) {
            toast("Save only works on the BIO tab for now");
            return;
        }
        try {
            int newJersey   = Integer.parseInt(etJersey.getText().toString().trim());
            int newCfId     = Integer.parseInt(etCfId.getText().toString().trim());
            int newPortrait = Integer.parseInt(etPortrait.getText().toString().trim());

            // Update in-memory object so UI reflects change immediately
            player.jerseyNumber = newJersey;
            player.cyberfaceId  = newCfId;
            player.portraitId   = newPortrait;

            subtitle.setText(String.format(Locale.US,
                    "S%04d  ·  #%d  ·  CF=%d",
                    player.slot, newJersey, newCfId));

            toast("Values updated in memory — write-back in next build");
        } catch (NumberFormatException e) {
            toast("Enter valid numbers");
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    private void addHeader(String label) {
        TextView h = new TextView(activity);
        h.setText(label);
        h.setTextColor(0xFF4FC3F7);
        h.setTextSize(10);
        h.setLetterSpacing(0.25f);
        h.setTypeface(h.getTypeface(), android.graphics.Typeface.BOLD);
        h.setPadding(0, dp(12), 0, dp(6));
        content.addView(h);
    }

    private void addInfo(String label, String value) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView l = new TextView(activity);
        l.setText(label);
        l.setTextColor(0xFF8892A0);
        l.setTextSize(12);
        l.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView v = new TextView(activity);
        v.setText(value == null ? "—" : value);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(12);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);

        row.addView(l);
        row.addView(v);
        content.addView(row);
    }

    private EditText addEdit(String hint, String initial) {
        TextView l = new TextView(activity);
        l.setText(hint);
        l.setTextColor(0xFF8892A0);
        l.setTextSize(11);
        l.setPadding(0, dp(8), 0, dp(4));
        content.addView(l);

        EditText e = new EditText(activity);
        e.setText(initial);
        e.setTextColor(0xFFFFFFFF);
        e.setTextSize(13);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        content.addView(e);
        return e;
    }

    private int dp(int v) {
        float d = activity.getResources().getDisplayMetrics().density;
        return (int)(v * d);
    }

    private void toast(String s) {
        Toast.makeText(activity, s, Toast.LENGTH_SHORT).show();
    }
}