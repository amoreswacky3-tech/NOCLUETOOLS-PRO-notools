package com.nocluetools.pro;

import android.util.Log;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ObjEditorDialog {

    public static final int PICK_OBJ_REQUEST     = 40;
    public static final int PICK_TEXTURE_REQUEST = 41;
    public static final int SAVE_OBJ_REQUEST     = 42;
    public static final int SAVE_TEX_REQUEST     = 43;

    private final Activity activity;

    private AlertDialog dialog;
    private ImageView imageView;
    private TextView  infoView;
    private TextView  statusView;
    private android.opengl.GLSurfaceView glView;
    private ObjEngine objEngine;

    private File objFile;
    private File textureFile;
    private ImageView textureView;
    private TextView  texInfoView;
    
    private int selectedUvIndex = -1;
    private int yaw = 28;
    private int pitch = 12;
    private int uvGridDiv = 0;

    public ObjEditorDialog(Activity activity) {
        this.activity = activity;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity).inflate(R.layout.dialog_obj_viewer, null);
        b.setView(v);

        // 1. Setup 3D OpenGL
        glView = v.findViewById(R.id.objGlView);
        if (glView != null) {
            try {
                objEngine = new ObjEngine();
                glView.setEGLContextClientVersion(2);
                glView.setEGLContextClientVersion(2);
glView.setRenderer(new android.opengl.GLSurfaceView.Renderer() {
    @Override
    public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl, javax.microedition.khronos.egl.EGLConfig config) {
        if (objEngine != null) objEngine.renderer.onSurfaceCreated(gl, config); 
    }

    @Override
    public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int width, int height) {
        if (objEngine != null) objEngine.renderer.onSurfaceChanged(gl, width, height);
    }

    @Override
    public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
        if (objEngine != null) objEngine.renderer.onDrawFrame(gl);
    }
});
                glView.setRenderMode(android.opengl.GLSurfaceView.RENDERMODE_WHEN_DIRTY);
            } catch (Exception e) {
                Log.e("ObjEditor", "OpenGL Init Failed", e);
            }
        }

        // 2. Init Views
        infoView   = v.findViewById(R.id.objInfo);
        statusView = v.findViewById(R.id.objStatus);
        textureView = v.findViewById(R.id.objTextureView);
        texInfoView = v.findViewById(R.id.objTexInfo);

        TextView pickObj = v.findViewById(R.id.objPrev);
        TextView pickTex = v.findViewById(R.id.objNext);
        TextView rotL = v.findViewById(R.id.objRotL);
        TextView rotR = v.findViewById(R.id.objRotR);
        TextView export = v.findViewById(R.id.objExport);
        TextView close = v.findViewById(R.id.objClose);
        TextView saveTex = v.findViewById(R.id.objSaveTex);

        pickObj.setText("PICK OBJ");
        pickTex.setText("PICK TEXTURE");

        // 3. Listeners
        pickObj.setOnClickListener(x -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            activity.startActivityForResult(i, PICK_OBJ_REQUEST);
        });
        pickTex.setOnClickListener(x -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            activity.startActivityForResult(i, PICK_TEXTURE_REQUEST);
        });
        
        rotL.setOnClickListener(x -> { yaw -= 15; update3D(); });
        rotR.setOnClickListener(x -> { yaw += 15; update3D(); });
        
        export.setOnClickListener(x -> askSave());
        saveTex.setOnClickListener(x -> askSaveTexture());
        
        close.setOnClickListener(x -> {
           dialog.dismiss();
           activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        });

        // 4. UV Grid Buttons
        TextView uvGrid4   = v.findViewById(R.id.uvGrid4);
        TextView uvGrid8   = v.findViewById(R.id.uvGrid8);
        TextView uvGrid16  = v.findViewById(R.id.uvGrid16);
        TextView uvGrid32  = v.findViewById(R.id.uvGrid32);
        TextView uvGridOff = v.findViewById(R.id.uvGridOff);

        View.OnClickListener gridClick = x -> {
            String tag = ((TextView) x).getText().toString();
            uvGridDiv = tag.equals("OFF") ? 0 : Integer.parseInt(tag);
            renderTexture();
        };
        uvGrid4.setOnClickListener(gridClick);
        uvGrid8.setOnClickListener(gridClick);
        uvGrid16.setOnClickListener(gridClick);
        uvGrid32.setOnClickListener(gridClick);
        uvGridOff.setOnClickListener(gridClick);

        // 5. Touch Listener (Dapat nasa LOOB ng show method)
        textureView.setOnTouchListener(new View.OnTouchListener() {
            private float startX, startY;
            private boolean dragging = false;
            private long downTime;

            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (textureFile == null || objFile == null) return false;

                android.graphics.RectF rect = getContentRect();
                float u = pixelToU(e.getX(), rect);
                float vv = pixelToV(e.getY(), rect);

                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = e.getX();
                        startY = e.getY();
                        downTime = System.currentTimeMillis();
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = Math.abs(e.getX() - startX);
                        float dy = Math.abs(e.getY() - startY);
                        if ((dx > 5 || dy > 5) && selectedUvIndex >= 0) {
                            dragging = true;
                            moveSelectedUv(u, vv);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        long dur = System.currentTimeMillis() - downTime;
                        if (!dragging && dur < 400) {
                            selectUvAt(u, vv);
                        }
                        return true;
                }
                return false;
            }
        });

        infoView.setText("Pick an OBJ file + optional texture");

        // 6. Dialog & Window
        dialog = b.create();
        dialog.show();
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF1A1A1A));
        }
    }

    // --- HELPERS (Nasa labas na ng show method) ---
    private android.graphics.RectF getContentRect() {
        float density = activity.getResources().getDisplayMetrics().density;
        float margin = 30f * density;
        float w = textureView.getWidth();
        float h = textureView.getHeight();
        float side = Math.min(w - 2 * margin, h - 2 * margin);
        if (side < 10) side = Math.min(w, h);
        float left = (w - side) / 2f;
        float top = (h - side) / 2f;
        return new android.graphics.RectF(left, top, left + side, top + side);
    }

    private float pixelToU(float px, android.graphics.RectF rect) {
        return (px - rect.left) / rect.width();
    }

    private float pixelToV(float py, android.graphics.RectF rect) {
        return (rect.bottom - py) / rect.height();
    }

    private void update3D() {
        if (glView != null) glView.requestRender();
        infoView.setText("yaw=" + yaw + "°  pitch=" + pitch + "°");
    }

    public void handlePickObj(Uri uri) {
    objFile = copyToCache(uri, "editor.obj");
    if (objFile != null && objEngine != null) {
        try {
            byte[] fileData = java.nio.file.Files.readAllBytes(objFile.toPath());
            ObjEngine.ObjModel model = ObjGeometryReader.parse(fileData);
            objEngine.setModel(model);
            glView.requestRender();
            statusView.setText("✓ 3D Model Loaded");
            statusView.setTextColor(0xFF00FF00);
        } catch (Exception e) {
            statusView.setText("Error: " + e.getMessage());
            statusView.setTextColor(0xFFFF0000);
        }
    }
}

    private void renderTexture() {
        if (textureFile == null || !textureFile.exists() || objFile == null) return;
        new Thread(() -> {
            try {
                File png = new File(activity.getCacheDir(), "uv_overlay.png");
                Python py = Python.getInstance();
                PyObject mod = py.getModule("iff_viewer");
                String result = mod.callAttr("render_uv_overlay_highlighted", 
                    textureFile.getAbsolutePath(), objFile.getAbsolutePath(), 
                    png.getAbsolutePath(), uvGridDiv, selectedUvIndex).toString();
         
                if (result.startsWith("Success")) {
                    final Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
                    activity.runOnUiThread(() -> {
                        if (textureView != null) textureView.setImageBitmap(bmp);
                        if (texInfoView != null) texInfoView.setText(uvGridDiv > 0 ? "grid " + uvGridDiv : "uv off");
                    });
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void selectUvAt(final float clickU, final float clickV) {
        new Thread(() -> {
            try {
                Python pyInst = Python.getInstance();
                PyObject mod = pyInst.getModule("iff_viewer");
                String json = mod.callAttr("find_uv_at_uv", objFile.getAbsolutePath(), (double) clickU, (double) clickV).toString();
                org.json.JSONObject obj = new org.json.JSONObject(json);
                final int idx = obj.optInt("index", -1);
                activity.runOnUiThread(() -> {
                    selectedUvIndex = idx;
                    if (texInfoView != null) texInfoView.setText(idx < 0 ? "No UV nearby" : "UV #" + idx);
                    renderTexture();
                });
            } catch (Exception ignored) {}
        }).start();
    }

    private void moveSelectedUv(float newU, float newV) {
        if (selectedUvIndex < 0) return;
        final float fu = Math.max(0f, Math.min(1f, newU));
        final float fv = Math.max(0f, Math.min(1f, newV));
        new Thread(() -> {
            try {
                File tempObj = new File(activity.getCacheDir(), "uv_edited.obj");
                Python pyInst = Python.getInstance();
                PyObject mod = pyInst.getModule("iff_viewer");
                mod.callAttr("move_uv_in_obj", objFile.getAbsolutePath(), tempObj.getAbsolutePath(), selectedUvIndex, fu, fv).toString();
                objFile = tempObj;
                activity.runOnUiThread(() -> {
                    if (texInfoView != null) texInfoView.setText("UV #" + selectedUvIndex + " U=" + String.format("%.3f", fu) + " V=" + String.format("%.3f", fv));
                    renderTexture();
                });
            } catch (Exception ignored) {}
        }).start();
    }

    private void askSave() {
        if (objFile == null) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "edited.obj");
        activity.startActivityForResult(i, SAVE_OBJ_REQUEST);
    }

    private void askSaveTexture() {
        if (textureFile == null) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/png");
        i.putExtra(Intent.EXTRA_TITLE, "edited_texture.png");
        activity.startActivityForResult(i, SAVE_TEX_REQUEST);
    }

    public void handleSave(Uri uri) {
        if (objFile == null) return;
        try (InputStream in = new FileInputStream(objFile); java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
            if (out == null) return;
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            Toast.makeText(activity, "Saved OBJ ✓", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Save failed", Toast.LENGTH_SHORT).show();
        }
    }

    public void handleSaveTexture(Uri uri) {
        if (textureFile == null) return;
        try (InputStream in = new FileInputStream(textureFile); java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
            if (out == null) return;
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            Toast.makeText(activity, "Texture saved ✓", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Save failed", Toast.LENGTH_SHORT).show();
        }
    }
   
    private File copyToCache(Uri uri, String name) {
        try {
            File dst = new File(activity.getCacheDir(), name);
            try (InputStream in = activity.getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) return null;
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return dst;
        } catch (Exception e) { return null; }
    }

public void handlePickTexture(Uri uri) {
    textureFile = copyToCache(uri, "editor_tex.png");
    if (textureFile != null && textureFile.exists()) {
        Bitmap bmp = BitmapFactory.decodeFile(textureFile.getAbsolutePath());
        if (bmp != null && textureView != null) {
            textureView.setImageBitmap(bmp);
            texInfoView.setText(bmp.getWidth() + "x" + bmp.getHeight());
        }
        renderTexture();
    }
}

}