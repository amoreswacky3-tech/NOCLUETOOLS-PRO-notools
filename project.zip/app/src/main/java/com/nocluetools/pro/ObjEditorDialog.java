package com.nocluetools.pro;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ObjEditorDialog {

    public static final int PICK_OBJ_REQUEST     = 40;
    public static final int PICK_TEXTURE_REQUEST = 41;
    public static final int SAVE_OBJ_REQUEST     = 42;
    public static final int SAVE_TEX_REQUEST = 43;

    private final Activity activity;

    private AlertDialog dialog;
    private ImageView imageView;
    private TextView  infoView;
    private TextView  statusView;

    private File objFile;      // user-picked OBJ
    private File textureFile;  // user-picked PNG (optional)
    private ImageView textureView;
    private TextView  texInfoView;
    
    private int selectedUvIndex = -1;
    private float selectedUvU = 0f;
    private float selectedUvV = 0f;
    private File lastRenderedPng;
    private int lastRenderW = 0;
    private int lastRenderH = 0;

    private int yaw = 28;
    private int pitch = 12;
    private int uvGridDiv = 0;

    public ObjEditorDialog(Activity activity) {
        this.activity = activity;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_obj_viewer, null);
        b.setView(v);

        imageView  = v.findViewById(R.id.objImage);
        infoView   = v.findViewById(R.id.objInfo);
        statusView = v.findViewById(R.id.objStatus);

        TextView pickObj = v.findViewById(R.id.objPrev);
        TextView pickTex = v.findViewById(R.id.objNext);
        textureView = v.findViewById(R.id.objTextureView);
        texInfoView = v.findViewById(R.id.objTexInfo);
        TextView rotL = v.findViewById(R.id.objRotL);
        TextView rotR = v.findViewById(R.id.objRotR);
        TextView export = v.findViewById(R.id.objExport);
        TextView close = v.findViewById(R.id.objClose);

        pickObj.setText("PICK OBJ");
        pickTex.setText("PICK TEXTURE");

        pickObj.setOnClickListener(x -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            activity.startActivityForResult(i, PICK_OBJ_REQUEST);
        });
        pickTex.setOnClickListener(x -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            activity.startActivityForResult(i, PICK_TEXTURE_REQUEST);
        });
        rotL.setOnClickListener(x -> { yaw -= 15; render(); });
        rotR.setOnClickListener(x -> { yaw += 15; render(); });
        export.setOnClickListener(x -> askSave());
        close.setOnClickListener(x -> {
           dialog.dismiss();
           activity.setRequestedOrientation(
                 android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
});

TextView saveTex = v.findViewById(R.id.objSaveTex);
saveTex.setOnClickListener(x -> askSaveTexture());

TextView uvGrid4   = v.findViewById(R.id.uvGrid4);
TextView uvGrid8   = v.findViewById(R.id.uvGrid8);
TextView uvGrid16  = v.findViewById(R.id.uvGrid16);
TextView uvGrid32  = v.findViewById(R.id.uvGrid32);
TextView uvGridOff = v.findViewById(R.id.uvGridOff);

View.OnClickListener gridClick = x -> {
    String tag = ((TextView) x).getText().toString();
    uvGridDiv = tag.equals("OFF") ? 0 : Integer.parseInt(tag);
    renderTexture();
};
uvGrid4.setOnClickListener(gridClick);
uvGrid8.setOnClickListener(gridClick);
uvGrid16.setOnClickListener(gridClick);
uvGrid32.setOnClickListener(gridClick);
uvGridOff.setOnClickListener(gridClick);

How about this one

// Texture touch listener for UV selection
textureView.setOnTouchListener(new View.OnTouchListener() {
    private float startX, startY;
    private boolean dragging = false;
    private long downTime;

    @Override
    public boolean onTouch(View v, MotionEvent e) {
        if (textureFile == null || objFile == null) return false;
        if (lastRenderedPng == null) return false;

        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = e.getX();
                startY = e.getY();
                downTime = System.currentTimeMillis();
                dragging = false;
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = Math.abs(e.getX() - startX);
                float dy = Math.abs(e.getY() - startY);
                if (dx > 15 || dy > 15) {
                    dragging = true;
                    if (selectedUvIndex >= 0) {
                        // Convert pixel → UV
                        float uvX = e.getX() / lastRenderW;
                        float uvY = e.getY() / lastRenderH;
                        moveSelectedUv(uvX, uvY);
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
                long duration = System.currentTimeMillis() - downTime;
                if (!dragging && duration < 300) {
                    // Tap → select nearest UV
                    selectUvAt(e.getX(), e.getY());
                }
                return true;
        }
        return false;
    }
});

        infoView.setText("Pick an OBJ file + optional texture");

        dialog = b.create();
        dialog.show();

// Lock to landscape
activity.setRequestedOrientation(
        android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF1A1A1A));
        }
    }

    public void handlePickObj(Uri uri) {
        objFile = copyToCache(uri, "editor.obj");
        if (objFile != null) render();
    }

public void handlePickTexture(Uri uri) {
    textureFile = copyToCache(uri, "editor_tex.png");
    if (textureFile != null && textureFile.exists()) {
        Bitmap bmp = BitmapFactory.decodeFile(textureFile.getAbsolutePath());
        if (bmp != null) {
    // Immediate placeholder — show plain texture first
    if (textureView != null) {
        textureView.setImageBitmap(bmp);
    }
    if (texInfoView != null) {
        texInfoView.setText(bmp.getWidth() + "x" + bmp.getHeight());
    }
    Toast.makeText(activity,
            "Texture loaded: " + bmp.getWidth() + "x" + bmp.getHeight(),
            Toast.LENGTH_SHORT).show();
}
    if (objFile != null) {
    render();          // Updates LEFT panel (mesh with texture)
    renderTexture();   // Updates RIGHT panel (texture with UV overlay)
        }
    }
}

    public void handleSave(Uri uri) {
        if (objFile == null) {
            Toast.makeText(activity, "No OBJ loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        try (InputStream in = new FileInputStream(objFile);
             java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
            if (out == null) return;
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            Toast.makeText(activity, "Saved OBJ ✓", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Save failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void render() {
    if (objFile == null || !objFile.exists()) {
        statusView.setText("No OBJ loaded");
        statusView.setTextColor(0xFFFF9800);
        return;
    }
    infoView.setText("yaw=" + yaw + "°  pitch=" + pitch + "°");
    statusView.setText("Rendering...");
    statusView.setTextColor(0xFFFF9800);

    final int y = yaw, p = pitch;
    final String texPath = (textureFile != null && textureFile.exists())
            ? textureFile.getAbsolutePath() : null;

    new Thread(() -> {
        try {
            File png = new File(activity.getCacheDir(), "obj_preview.png");
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");

            final String result;
            if (texPath != null) {
                // Try textured first
                result = mod.callAttr("render_obj_with_texture",
                        objFile.getAbsolutePath(),
                        texPath,
                        png.getAbsolutePath(),
                        y, p).toString();
                if (result.startsWith("Error") && result.contains("UV")) {
                    // Fall back to wireframe
                    final String r2 = mod.callAttr("render_obj_wireframe",
                            objFile.getAbsolutePath(),
                            png.getAbsolutePath(),
                            y, p).toString();
                    activity.runOnUiThread(() -> {
                        Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
                        imageView.setImageBitmap(bmp);
                        statusView.setText("No UVs — wireframe only");
                        statusView.setTextColor(0xFFFF9800);
                    });
                    return;
                }
            } else {
                result = mod.callAttr("render_obj_wireframe",
                        objFile.getAbsolutePath(),
                        png.getAbsolutePath(),
                        y, p).toString();
            }

            if (!result.startsWith("Success")) {
                activity.runOnUiThread(() -> {
                    statusView.setText(result);
                    statusView.setTextColor(0xFFFF0000);
                });
                return;
            }

            final Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
            final String r = result;
            activity.runOnUiThread(() -> {
                imageView.setImageBitmap(bmp);
                statusView.setText("✓ " + r);
                statusView.setTextColor(0xFF00FF00);
            });
        } catch (Exception e) {
            final String err = e.getMessage();
            activity.runOnUiThread(() -> {
                statusView.setText("Error: " + err);
                statusView.setTextColor(0xFFFF0000);
            });
        }
    }).start();
}

    private void renderTexture() {
    if (textureFile == null || !textureFile.exists()) return;

    // If no OBJ loaded, just show the texture
    if (objFile == null) {
        Bitmap bmp = BitmapFactory.decodeFile(textureFile.getAbsolutePath());
        if (textureView != null) textureView.setImageBitmap(bmp);
        return;
    }

    // Has OBJ — render with UV overlay
    new Thread(() -> {
        try {
            File png = new File(activity.getCacheDir(), "uv_overlay.png");
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");
            final String result = mod.callAttr("render_uv_overlay_highlighted",
                    textureFile.getAbsolutePath(),
                    objFile.getAbsolutePath(),
                    png.getAbsolutePath(),
                    uvGridDiv,
                    selectedUvIndex).toString();
     
            if (result.startsWith("Success")) {
                final Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
                final int rw = bmp.getWidth();
                final int rh = bmp.getHeight();
                final File fp = png;
    activity.runOnUiThread(() -> {
            if (textureView != null) textureView.setImageBitmap(bmp);
        lastRenderedPng = fp;
        lastRenderW = rw;
        lastRenderH = rh;
            if (texInfoView != null) {
            texInfoView.setText(uvGridDiv > 0 ? "grid " + uvGridDiv : "uv off");
        }
    });
}
            }
        } catch (Exception e) {
            // fail silently
        }
    }).start();
}

    private void askSave() {
        if (objFile == null) {
            Toast.makeText(activity, "No OBJ loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "edited.obj");
        activity.startActivityForResult(i, SAVE_OBJ_REQUEST);
    }

   private void askSaveTexture() {
    if (textureFile == null || !textureFile.exists()) {
        Toast.makeText(activity, "No texture loaded", Toast.LENGTH_SHORT).show();
        return;
    }
    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("image/png");
    i.putExtra(Intent.EXTRA_TITLE, "edited_texture.png");
    activity.startActivityForResult(i, SAVE_TEX_REQUEST);
}

public void handleSaveTexture(Uri uri) {
    if (textureFile == null || !textureFile.exists()) {
        Toast.makeText(activity, "No texture loaded", Toast.LENGTH_SHORT).show();
        return;
    }
    try (InputStream in = new FileInputStream(textureFile);
         java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
        if (out == null) return;
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        Toast.makeText(activity, "Texture saved ✓", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
        Toast.makeText(activity, "Save failed: " + e.getMessage(),
                Toast.LENGTH_LONG).show();
    }
}
   
    private File copyToCache(Uri uri, String name) {
        try {
            File dst = new File(activity.getCacheDir(), name);
            try (InputStream in = activity.getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) return null;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return dst;
        } catch (Exception e) {
            Toast.makeText(activity, "Copy failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            return null;
        }
    }
    
    private void selectUvAt(float px, float py) {
    new Thread(() -> {
        try {
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");
            final String json = mod.callAttr("find_uv_at_pixel",
                    objFile.getAbsolutePath(),
                    textureFile.getAbsolutePath(),
                    (int) px, (int) py).toString();

            org.json.JSONObject obj = new org.json.JSONObject(json);
            int idx = obj.optInt("index", -1);

            activity.runOnUiThread(() -> {
                if (idx < 0) {
                    selectedUvIndex = -1;
                    if (texInfoView != null) texInfoView.setText("no UV nearby");
                } else {
                    selectedUvIndex = idx;
                    selectedUvU = (float) obj.optDouble("u", 0);
                    selectedUvV = (float) obj.optDouble("v", 0);
                    if (texInfoView != null) {
                        texInfoView.setText(String.format("UV #%d  U=%.3f V=%.3f",
                                idx, selectedUvU, selectedUvV));
                    }
                }
                renderTexture();
            });
        } catch (Exception e) {
            // ignore
        }
    }).start();
}

private void moveSelectedUv(float newU, float newV) {
    if (selectedUvIndex < 0) return;
    newU = Math.max(0f, Math.min(1f, newU));
    newV = Math.max(0f, Math.min(1f, newV));

    final float fu = newU;
    final float fv = newV;

    new Thread(() -> {
        try {
            File tempObj = new File(activity.getCacheDir(), "uv_edited.obj");
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");
            mod.callAttr("move_uv_in_obj",
                    objFile.getAbsolutePath(),
                    tempObj.getAbsolutePath(),
                    selectedUvIndex,
                    fu, fv).toString();

            objFile = tempObj;
            selectedUvU = fu;
            selectedUvV = fv;

            activity.runOnUiThread(() -> {
                if (texInfoView != null) {
                    texInfoView.setText(String.format("UV #%d  U=%.3f V=%.3f",
                            selectedUvIndex, fu, fv));
                }
                renderTexture();
            });
        } catch (Exception e) {
            // ignore
        }
    }).start();
}

