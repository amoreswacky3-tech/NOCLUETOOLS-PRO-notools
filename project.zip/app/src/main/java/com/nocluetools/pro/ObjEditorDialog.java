package com.nocluetools.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ObjEditorDialog {

    public static final int PICK_OBJ_REQUEST     = 40;
    public static final int PICK_TEXTURE_REQUEST = 41;
    public static final int SAVE_OBJ_REQUEST     = 42;

    private final Activity activity;

    private AlertDialog dialog;
    private ImageView imageView;
    private TextView  infoView;
    private TextView  statusView;

    private File objFile;      // user-picked OBJ
    private File textureFile;  // user-picked PNG (optional)
    private ImageView textureView;
    private TextView  texInfoView;

    private int yaw = 28;
    private int pitch = 12;

    public ObjEditorDialog(Activity activity) {
        this.activity = activity;
    }

    public void show() {
        AlertDialog.Builder b = new AlertDialog.Builder(activity);
        View v = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_obj_viewer, null);
        b.setView(v);

        imageView  = v.findViewById(R.id.objImage);
        infoView   = v.findViewById(R.id.objInfo);
        statusView = v.findViewById(R.id.objStatus);

        TextView pickObj = v.findViewById(R.id.objPrev);
        TextView pickTex = v.findViewById(R.id.objNext);
        textureView = v.findViewById(R.id.objTextureView);
        texInfoView = v.findViewById(R.id.objTexInfo);
        TextView rotL = v.findViewById(R.id.objRotL);
        TextView rotR = v.findViewById(R.id.objRotR);
        TextView export = v.findViewById(R.id.objExport);
        TextView close = v.findViewById(R.id.objClose);

        pickObj.setText("PICK OBJ");
        pickTex.setText("PICK TEXTURE");

        pickObj.setOnClickListener(x -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            activity.startActivityForResult(i, PICK_OBJ_REQUEST);
        });
        pickTex.setOnClickListener(x -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            activity.startActivityForResult(i, PICK_TEXTURE_REQUEST);
        });
        rotL.setOnClickListener(x -> { yaw -= 15; render(); });
        rotR.setOnClickListener(x -> { yaw += 15; render(); });
        export.setOnClickListener(x -> askSave());
        close.setOnClickListener(x -> {
           dialog.dismiss();
           activity.setRequestedOrientation(
                 android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
});

        infoView.setText("Pick an OBJ file + optional texture");

        dialog = b.create();
        dialog.show();

        // Lock to landscape while dialog is open
        activity.setRequestedOrientation(
              android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF1A1A1A));
        }
    }

    public void handlePickObj(Uri uri) {
        objFile = copyToCache(uri, "editor.obj");
        if (objFile != null) render();
    }

public void handlePickTexture(Uri uri) {
    textureFile = copyToCache(uri, "editor_tex.png");
    if (textureFile != null && textureFile.exists()) {
        Bitmap bmp = BitmapFactory.decodeFile(textureFile.getAbsolutePath());
        if (bmp != null) {
            if (textureView != null) {
                textureView.setImageBitmap(bmp);
            }
            if (texInfoView != null) {
                texInfoView.setText(bmp.getWidth() + "×" + bmp.getHeight());
            }
            Toast.makeText(activity,
                    "Texture loaded: " + bmp.getWidth() + "x" + bmp.getHeight(),
                    Toast.LENGTH_SHORT).show();
        }
        if (objFile != null) {
            render();
        }
    }
}

    public void handleSave(Uri uri) {
        if (objFile == null) {
            Toast.makeText(activity, "No OBJ loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        try (InputStream in = new FileInputStream(objFile);
             java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
            if (out == null) return;
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            Toast.makeText(activity, "Saved OBJ ✓", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Save failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void render() {
    if (objFile == null || !objFile.exists()) {
        statusView.setText("No OBJ loaded");
        statusView.setTextColor(0xFFFF9800);
        return;
    }
    infoView.setText("yaw=" + yaw + "°  pitch=" + pitch + "°");
    statusView.setText("Rendering...");
    statusView.setTextColor(0xFFFF9800);

    final int y = yaw, p = pitch;
    final String texPath = (textureFile != null && textureFile.exists())
            ? textureFile.getAbsolutePath() : null;

    new Thread(() -> {
        try {
            File png = new File(activity.getCacheDir(), "obj_preview.png");
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");

            final String result;
            if (texPath != null) {
                // Try textured first
                result = mod.callAttr("render_obj_with_texture",
                        objFile.getAbsolutePath(),
                        texPath,
                        png.getAbsolutePath(),
                        y, p).toString();
                if (result.startsWith("Error") && result.contains("UV")) {
                    // Fall back to wireframe
                    final String r2 = mod.callAttr("render_obj_wireframe",
                            objFile.getAbsolutePath(),
                            png.getAbsolutePath(),
                            y, p).toString();
                    activity.runOnUiThread(() -> {
                        Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
                        imageView.setImageBitmap(bmp);
                        statusView.setText("No UVs — wireframe only");
                        statusView.setTextColor(0xFFFF9800);
                    });
                    return;
                }
            } else {
                result = mod.callAttr("render_obj_wireframe",
                        objFile.getAbsolutePath(),
                        png.getAbsolutePath(),
                        y, p).toString();
            }

            if (!result.startsWith("Success")) {
                activity.runOnUiThread(() -> {
                    statusView.setText(result);
                    statusView.setTextColor(0xFFFF0000);
                });
                return;
            }

            final Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
            final String r = result;
            activity.runOnUiThread(() -> {
                imageView.setImageBitmap(bmp);
                statusView.setText("✓ " + r);
                statusView.setTextColor(0xFF00FF00);
            });
        } catch (Exception e) {
            final String err = e.getMessage();
            activity.runOnUiThread(() -> {
                statusView.setText("Error: " + err);
                statusView.setTextColor(0xFFFF0000);
            });
        }
    }).start();
}

    private void askSave() {
        if (objFile == null) {
            Toast.makeText(activity, "No OBJ loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "edited.obj");
        activity.startActivityForResult(i, SAVE_OBJ_REQUEST);
    }

    private File copyToCache(Uri uri, String name) {
        try {
            File dst = new File(activity.getCacheDir(), name);
            try (InputStream in = activity.getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) return null;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return dst;
        } catch (Exception e) {
            Toast.makeText(activity, "Copy failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            return null;
        }
    }
}