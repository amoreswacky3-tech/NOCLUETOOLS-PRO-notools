package com.nocluetools.pro;

import android.util.Log;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ObjEditorDialog {

    public static final int PICK_OBJ_REQUEST     = 40;
    public static final int PICK_TEXTURE_REQUEST = 41;
    public static final int SAVE_OBJ_REQUEST     = 42;
    public static final int SAVE_TEX_REQUEST = 43;

    private final Activity activity;

    private AlertDialog dialog;
    private ImageView imageView;
    private ImageView imageView;
    private TextView infoView;
    private TextView statusView;

// 👇 IDAGDAG ITO 👇
   private android.opengl.GLSurfaceView glView;
   private ObjEngine objEngine;
// 👆 ----------------- 👆

    private File objFile;      // user-picked OBJ
    private File textureFile;  // user-picked PNG (optional)
    private ImageView textureView;
    private TextView  texInfoView;
    
    private int selectedUvIndex = -1;
    private float selectedUvU = 0f;
    private float selectedUvV = 0f;
    private File lastRenderedPng;
    private int lastRenderW = 0;
    private int lastRenderH = 0;

    private int yaw = 28;
    private int pitch = 12;
    private int uvGridDiv = 0;

    public ObjEditorDialog(Activity activity) {
        this.activity = activity;
    }

    public void show() {
    AlertDialog.Builder b = new AlertDialog.Builder(activity);
    View v = LayoutInflater.from(activity).inflate(R.layout.dialog_obj_viewer, null);
    b.setView(v);

    // 👇 1. OPENGL 3D SETUP 👇
    glView = v.findViewById(R.id.objGlView);
    
    // ⚠️ BABALA: Kung private ang constructor ng ObjEngine, palitan mo muna sa ObjEngine.java
    objEngine = new ObjEngine(); 
    
    if (glView != null && objEngine != null) {
        glView.setEGLContextClientVersion(2);
        glView.setRenderer(objEngine);
        glView.setRenderMode(android.opengl.GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    }

    // 👇 2. INITIALIZE VIEWS 👇
    infoView   = v.findViewById(R.id.objInfo);
    statusView = v.findViewById(R.id.objStatus);

    TextView pickObj = v.findViewById(R.id.objPrev);
    TextView pickTex = v.findViewById(R.id.objNext);
    textureView = v.findViewById(R.id.objTextureView);
    texInfoView = v.findViewById(R.id.objTexInfo);
    TextView rotL = v.findViewById(R.id.objRotL);
    TextView rotR = v.findViewById(R.id.objRotR);
    TextView export = v.findViewById(R.id.objExport);
    TextView close = v.findViewById(R.id.objClose);

    pickObj.setText("PICK OBJ");
    pickTex.setText("PICK TEXTURE");

    // 👇 3. SETUP LISTENERS 👇
    pickObj.setOnClickListener(x -> {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        activity.startActivityForResult(i, PICK_OBJ_REQUEST);
    });
    
    pickTex.setOnClickListener(x -> {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        activity.startActivityForResult(i, PICK_TEXTURE_REQUEST);
    });
    
    rotL.setOnClickListener(x -> { 
        yaw -= 15; 
        // TODO: I-update ang rotation sa 3D Engine kapag may method na
    });
    
    rotR.setOnClickListener(x -> { 
        yaw += 15; 
        // TODO: I-update ang rotation sa 3D Engine kapag may method na
    });
    
    export.setOnClickListener(x -> askSave());
    
    close.setOnClickListener(x -> {
       dialog.dismiss();
       activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    });

    TextView saveTex = v.findViewById(R.id.objSaveTex);
    saveTex.setOnClickListener(x -> askSaveTexture());

    // 👇 4. UV GRID BUTTONS 👇
    TextView uvGrid4   = v.findViewById(R.id.uvGrid4);
    TextView uvGrid8   = v.findViewById(R.id.uvGrid8);
    TextView uvGrid16  = v.findViewById(R.id.uvGrid16);
    TextView uvGrid32  = v.findViewById(R.id.uvGrid32);
    TextView uvGridOff = v.findViewById(R.id.uvGridOff);

    View.OnClickListener gridClick = x -> {
        String tag = ((TextView) x).getText().toString();
        uvGridDiv = tag.equals("OFF") ? 0 : Integer.parseInt(tag);
        renderTexture();
    };
    uvGrid4.setOnClickListener(gridClick);
    uvGrid8.setOnClickListener(gridClick);
    uvGrid16.setOnClickListener(gridClick);
    uvGrid32.setOnClickListener(gridClick);
    uvGridOff.setOnClickListener(gridClick);

    // 👇 5. TEXTURE TOUCH LISTENER (PARA SA UV DRAG) 👇
    textureView.setOnTouchListener(new View.OnTouchListener() {
        private float startX, startY;
        private boolean dragging = false;
        private long downTime;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            if (textureFile == null || objFile == null) return false;

            android.graphics.RectF rect = getContentRect(); // Gagamitin yung tamang math
            float u = pixelToU(e.getX(), rect);
            float vv = pixelToV(e.getY(), rect);

            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = e.getX();
                    startY = e.getY();
                    downTime = System.currentTimeMillis();
                    dragging = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = Math.abs(e.getX() - startX);
                    float dy = Math.abs(e.getY() - startY);
                    if ((dx > 5 || dy > 5) && selectedUvIndex >= 0) {
                        dragging = true;
                        moveSelectedUv(u, vv);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    long dur = System.currentTimeMillis() - downTime;
                    if (!dragging && dur < 400) {
                        selectUvAt(u, vv);
                    }
                    return true;
            }
            return false;
        }
    });

    infoView.setText("Pick an OBJ file + optional texture");

    // 👇 6. DIALOG SHOW & WINDOW SETUP 👇
    dialog = b.create();
    dialog.show();

    // Lock to landscape
    activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

    android.view.Window w = dialog.getWindow();
    if (w != null) {
        w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        w.setBackgroundDrawable(new ColorDrawable(0xFF1A1A1A));
    }
}

// 👇 7. MGA HELPER METHODS PARA SA TOUCH MATH (IDAGDAG SA PINAKABABA) 👇
private android.graphics.RectF getContentRect() {
    float density = activity.getResources().getDisplayMetrics().density;
    float margin = 30f * density;
    float w = textureView.getWidth();
    float h = textureView.getHeight();
    float side = Math.min(w - 2 * margin, h - 2 * margin);
    if (side < 10) side = Math.min(w, h);
    float left = (w - side) / 2f;
    float top = (h - side) / 2f;
    return new android.graphics.RectF(left, top, left + side, top + side);
}

private float pixelToU(float px, android.graphics.RectF rect) {
    return (px - rect.left) / rect.width();
}

private float pixelToV(float py, android.graphics.RectF rect) {
    return (rect.bottom - py) / rect.height();
}

// Texture touch listener for UV selection
textureView.setOnTouchListener(new View.OnTouchListener() {
    private float startX, startY;
    private boolean dragging = false;
    private long downTime;

    @Override
    public boolean onTouch(View v, MotionEvent e) {
        if (textureFile == null || objFile == null) return false;

        float vw = textureView.getWidth();
        float vh = textureView.getHeight();
        if (vw <= 0 || vh <= 0) return false;

        // Convert touch pixel → UV (fitXY, so simple ratio)
        float u = e.getX() / vw;
        float vv = 1.0f - (e.getY() / vh);   // flip Y

        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = e.getX();
                startY = e.getY();
                downTime = System.currentTimeMillis();
                dragging = false;
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = Math.abs(e.getX() - startX);
                float dy = Math.abs(e.getY() - startY);
                if ((dx > 10 || dy > 10) && selectedUvIndex >= 0) {
                    dragging = true;
                    moveSelectedUv(u, vv);
                }
                return true;

            case MotionEvent.ACTION_UP:
                long dur = System.currentTimeMillis() - downTime;
                if (!dragging && dur < 400) {
                    selectUvAt(u, vv);
                }
                return true;
        }
        return false;
    }
});

        infoView.setText("Pick an OBJ file + optional texture");

        dialog = b.create();
        dialog.show();

// Lock to landscape
activity.setRequestedOrientation(
        android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(0xFF1A1A1A));
        }
    }

    public void handlePickObj(Uri uri) {
        objFile = copyToCache(uri, "editor.obj");
        if (objFile != null) render();
    }

public void handlePickObj(Uri uri) {
    objFile = copyToCache(uri, "editor.obj");
    if (objFile != null && objEngine != null) {
        try {
            // 👇 I-load yung OBJ sa 3D engine 👇
            objEngine.loadObj(objFile.getAbsolutePath()); // ⚠️ Palitan kung iba ang method name
            glView.requestRender();
            statusView.setText("✓ 3D Model Loaded");
            statusView.setTextColor(0xFF00FF00);
        } catch (Exception e) {
            statusView.setText("3D Error: " + e.getMessage());
            statusView.setTextColor(0xFFFF0000);
        }
    }
}

    public void handleSave(Uri uri) {
        if (objFile == null) {
            Toast.makeText(activity, "No OBJ loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        try (InputStream in = new FileInputStream(objFile);
             java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
            if (out == null) return;
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            Toast.makeText(activity, "Saved OBJ ✓", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Save failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void render() {
    if (objFile == null || !objFile.exists()) {
        statusView.setText("No OBJ loaded");
        statusView.setTextColor(0xFFFF9800);
        return;
    }
    infoView.setText("yaw=" + yaw + "°  pitch=" + pitch + "°");
    statusView.setText("Rendering...");
    statusView.setTextColor(0xFFFF9800);

    final int y = yaw, p = pitch;
    final String texPath = (textureFile != null && textureFile.exists())
            ? textureFile.getAbsolutePath() : null;

    new Thread(() -> {
        try {
            File png = new File(activity.getCacheDir(), "obj_preview.png");
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");

            final String result;
            if (texPath != null) {
                // Try textured first
                result = mod.callAttr("render_obj_with_texture",
                        objFile.getAbsolutePath(),
                        texPath,
                        png.getAbsolutePath(),
                        y, p).toString();
                if (result.startsWith("Error") && result.contains("UV")) {
                    // Fall back to wireframe
                    final String r2 = mod.callAttr("render_obj_wireframe",
                            objFile.getAbsolutePath(),
                            png.getAbsolutePath(),
                            y, p).toString();
                    activity.runOnUiThread(() -> {
                        Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
                        imageView.setImageBitmap(bmp);
                        statusView.setText("No UVs — wireframe only");
                        statusView.setTextColor(0xFFFF9800);
                    });
                    return;
                }
            } else {
                result = mod.callAttr("render_obj_wireframe",
                        objFile.getAbsolutePath(),
                        png.getAbsolutePath(),
                        y, p).toString();
            }

            if (!result.startsWith("Success")) {
                activity.runOnUiThread(() -> {
                    statusView.setText(result);
                    statusView.setTextColor(0xFFFF0000);
                });
                return;
            }

            final Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
            final String r = result;
            activity.runOnUiThread(() -> {
                imageView.setImageBitmap(bmp);
                statusView.setText("✓ " + r);
                statusView.setTextColor(0xFF00FF00);
            });
        } catch (Exception e) {
            final String err = e.getMessage();
            activity.runOnUiThread(() -> {
                statusView.setText("Error: " + err);
                statusView.setTextColor(0xFFFF0000);
            });
        }
    }).start();
}

    private void renderTexture() {
    if (textureFile == null || !textureFile.exists()) return;

    // If no OBJ loaded, just show the texture
    if (objFile == null) {
        Bitmap bmp = BitmapFactory.decodeFile(textureFile.getAbsolutePath());
        if (textureView != null) textureView.setImageBitmap(bmp);
        return;
    }

    // Has OBJ — render with UV overlay
    new Thread(() -> {
        try {
            File png = new File(activity.getCacheDir(), "uv_overlay.png");
            Python py = Python.getInstance();
            PyObject mod = py.getModule("iff_viewer");
            final String result = mod.callAttr("render_uv_overlay_highlighted",
                    textureFile.getAbsolutePath(),
                    objFile.getAbsolutePath(),
                    png.getAbsolutePath(),
                    uvGridDiv,
                    selectedUvIndex).toString();
     
            if (result.startsWith("Success")) {
                final Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath());
                final int rw = bmp.getWidth();
                final int rh = bmp.getHeight();
                final File fp = png;
    activity.runOnUiThread(() -> {
            if (textureView != null) textureView.setImageBitmap(bmp);
        lastRenderedPng = fp;
        lastRenderW = rw;
        lastRenderH = rh;
            if (texInfoView != null) {
            texInfoView.setText(uvGridDiv > 0 ? "grid " + uvGridDiv : "uv off");
        }
    });
}
        } catch (Exception e) {
            // fail silently
        }
    }).start();
}

    private void askSave() {
        if (objFile == null) {
            Toast.makeText(activity, "No OBJ loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "edited.obj");
        activity.startActivityForResult(i, SAVE_OBJ_REQUEST);
    }

   private void askSaveTexture() {
    if (textureFile == null || !textureFile.exists()) {
        Toast.makeText(activity, "No texture loaded", Toast.LENGTH_SHORT).show();
        return;
    }
    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("image/png");
    i.putExtra(Intent.EXTRA_TITLE, "edited_texture.png");
    activity.startActivityForResult(i, SAVE_TEX_REQUEST);
}

public void handleSaveTexture(Uri uri) {
    if (textureFile == null || !textureFile.exists()) {
        Toast.makeText(activity, "No texture loaded", Toast.LENGTH_SHORT).show();
        return;
    }
    try (InputStream in = new FileInputStream(textureFile);
         java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
        if (out == null) return;
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        Toast.makeText(activity, "Texture saved ✓", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
        Toast.makeText(activity, "Save failed: " + e.getMessage(),
                Toast.LENGTH_LONG).show();
    }
}
   
    private File copyToCache(Uri uri, String name) {
        try {
            File dst = new File(activity.getCacheDir(), name);
            try (InputStream in = activity.getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) return null;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return dst;
        } catch (Exception e) {
            Toast.makeText(activity, "Copy failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            return null;
        }
    }
    
    private void selectUvAt(final float clickU, final float clickV) {
    if (textureView == null || objFile == null) return;

    new Thread(() -> {
        try {
            Python pyInst = Python.getInstance();
            PyObject mod = pyInst.getModule("iff_viewer");
            final String json = mod.callAttr("find_uv_at_uv",
                    objFile.getAbsolutePath(),
                    (double) clickU,
                    (double) clickV).toString();

            org.json.JSONObject obj = new org.json.JSONObject(json);
            final int idx = obj.optInt("index", -1);
            final float u = (float) obj.optDouble("u", 0);
            final float v = (float) obj.optDouble("v", 0);
            final float dist = (float) obj.optDouble("distance", 1);

            activity.runOnUiThread(() -> {
                if (idx < 0) {
                    selectedUvIndex = -1;
                    if (texInfoView != null)
                        texInfoView.setText("no UV nearby (click " + String.format("%.2f,%.2f", clickU, clickV) + ")");
                } else {
                    selectedUvIndex = idx;
                    selectedUvU = u;
                    selectedUvV = v;
                    if (texInfoView != null)
                        texInfoView.setText("UV #" + idx + "  U=" + String.format("%.3f", u) + " V=" + String.format("%.3f", v));
                }
                renderTexture();
            });
        } catch (Exception e) {
            Log.e("ObjEditor", "selectUvAt failed", e);
        }
    }).start();
}

private void moveSelectedUv(float newU, float newV) {
    if (selectedUvIndex < 0) return;

    newU = Math.max(0f, Math.min(1f, newU));
    newV = Math.max(0f, Math.min(1f, newV));

    final float fu = newU;
    final float fv = newV;

    // Update local state immediately for instant visual feedback
    selectedUvU = fu;
    selectedUvV = fv;

    new Thread(() -> {
        try {
            File tempObj = new File(activity.getCacheDir(), "uv_edited.obj");
            Python pyInst = Python.getInstance();
            PyObject mod = pyInst.getModule("iff_viewer");
            mod.callAttr("move_uv_in_obj",
                    objFile.getAbsolutePath(),
                    tempObj.getAbsolutePath(),
                    selectedUvIndex,
                    fu, fv).toString();

            objFile = tempObj;

            activity.runOnUiThread(() -> {
                if (texInfoView != null)
                    texInfoView.setText("UV #" + selectedUvIndex
                            + "  U=" + String.format("%.3f", fu)
                            + " V=" + String.format("%.3f", fv));
                renderTexture();
            });
        } catch (Exception e) {
            Log.e("ObjEditor", "moveSelectedUv failed", e);
        }
    }).start();
}

/** Compute the centered square where the texture is drawn (from working editor). */
private android.graphics.RectF getContentRect() {
    float density = activity.getResources().getDisplayMetrics().density;
    float margin = 30f * density;

    float w = textureView.getWidth();
    float h = textureView.getHeight();
    float side = Math.min(w - 2 * margin, h - 2 * margin);
    if (side < 10) side = Math.min(w, h);

    float left = (w - side) / 2f;
    float top = (h - side) / 2f;
    return new android.graphics.RectF(left, top, left + side, top + side);
}

/** UV → screen pixel X (matches decompiled uvToScreenX). */
private float uvToScreenX(float u, android.graphics.RectF rect) {
    return rect.left + (u * rect.width());
}

/** UV → screen pixel Y (matches decompiled uvToScreenY — Y flipped). */
private float uvToScreenY(float v, android.graphics.RectF rect) {
    return rect.bottom - (v * rect.height());
}

/** Screen pixel → UV X. */
private float pixelToU(float px, android.graphics.RectF rect) {
    return (px - rect.left) / rect.width();
}

/** Screen pixel → UV Y (flipped). */
private float pixelToV(float py, android.graphics.RectF rect) {
    return (rect.bottom - py) / rect.height();
}

}