package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RosterEditorActivity extends AppCompatActivity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    // ── UI ──────────────────────────────────────────
    private TextView tvSectionName, tvStatusBar, tvHint, tvCurrentFile;
    private TextView navHome, navRoster, navTeams, navPlayers, navTools;
    private View panelHome, panelRoster, panelTeams, panelPlayers, panelTools;
    private ListView listViewRecords;
    private EditText etSearchPlayer;

    // ── Data ────────────────────────────────────────
    private File currentRosFile;
    private final List<String> playerDisplayList = new ArrayList<>();
    private final List<Integer> playerIdList = new ArrayList<>();
    private final List<String> allPlayers = new ArrayList<>();
    private final List<Integer> allPlayerIds = new ArrayList<>();
    private ArrayAdapter<String> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_editor);

        // Bind main views
        tvSectionName   = findViewById(R.id.tvSectionName);
        tvStatusBar     = findViewById(R.id.tvStatusBar);
        tvHint          = findViewById(R.id.tvHint);
        tvCurrentFile   = findViewById(R.id.tvCurrentFile);
        listViewRecords = findViewById(R.id.listViewRecords);
        etSearchPlayer  = findViewById(R.id.etSearchPlayer);

        // Panels
        panelHome    = findViewById(R.id.panelHome);
        panelRoster  = findViewById(R.id.panelRoster);
        panelTeams   = findViewById(R.id.panelTeams);
        panelPlayers = findViewById(R.id.panelPlayers);
        panelTools   = findViewById(R.id.panelTools);

        // Bottom nav
        navHome    = findViewById(R.id.navHome);
        navRoster  = findViewById(R.id.navRoster);
        navTeams   = findViewById(R.id.navTeams);
        navPlayers = findViewById(R.id.navPlayers);
        navTools   = findViewById(R.id.navTools);

        navHome.setOnClickListener(v    -> selectTab(0));
        navRoster.setOnClickListener(v  -> selectTab(1));
        navTeams.setOnClickListener(v   -> selectTab(2));
        navPlayers.setOnClickListener(v -> selectTab(3));
        navTools.setOnClickListener(v   -> selectTab(4));

        // Home shortcuts
        View btnHomeOpenRoster = findViewById(R.id.btnHomeOpenRoster);
        if (btnHomeOpenRoster != null) btnHomeOpenRoster.setOnClickListener(v -> selectTab(1));
        View btnHomePlayerLab = findViewById(R.id.btnHomePlayerLab);
        if (btnHomePlayerLab != null) btnHomePlayerLab.setOnClickListener(v -> selectTab(3));
        View btnHomeTeamControl = findViewById(R.id.btnHomeTeamControl);
        if (btnHomeTeamControl != null) btnHomeTeamControl.setOnClickListener(v -> selectTab(2));
        View btnHomeTools = findViewById(R.id.btnHomeTools);
        if (btnHomeTools != null) btnHomeTools.setOnClickListener(v -> selectTab(4));

        // Roster buttons
        Button btnOpen = findViewById(R.id.btnOpen);
        if (btnOpen != null) btnOpen.setOnClickListener(v -> pickRosterFile());
        Button btnSave = findViewById(R.id.btnSave);
        if (btnSave != null) btnSave.setOnClickListener(v -> saveAsNew());

        // Player list adapter
        listAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, playerDisplayList);
        listViewRecords.setAdapter(listAdapter);

        listViewRecords.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < playerIdList.size()) {
                int slot = playerIdList.get(position);
                tvStatusBar.setText("Selected slot " + slot + " — " + playerDisplayList.get(position));
            }
        });

        // Search
        etSearchPlayer.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { applyFilter(s.toString()); }
        });

        selectTab(0);
    }

    // ─────────────────────────────────────────────────
    private void selectTab(int idx) {
        panelHome.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        panelRoster.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        panelTeams.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        panelPlayers.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);
        panelTools.setVisibility(idx == 4 ? View.VISIBLE : View.GONE);

        TextView[] navs = { navHome, navRoster, navTeams, navPlayers, navTools };
        String[] names = { "HOME", "ROSTER", "TEAMS", "PLAYERS", "TOOLS" };
        for (int i = 0; i < navs.length; i++) {
            if (navs[i] == null) continue;
            if (i == idx) {
                navs[i].setBackgroundResource(R.drawable.bg_nav_active);
                navs[i].setTextColor(0xFFFFFFFF);
            } else {
                navs[i].setBackgroundResource(R.drawable.bg_nav_inactive);
                navs[i].setTextColor(0xFF6B7280);
            }
        }
        if (tvSectionName != null) tvSectionName.setText(names[idx]);
    }

    // ─────────────────────────────────────────────────
    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == Activity.RESULT_OK
                && data != null && data.getData() != null) {
            loadRosterDatabase(data.getData());
        }
    }

    // ─────────────────────────────────────────────────
    private void loadRosterDatabase(Uri uri) {
        tvStatusBar.setText("Decrypting roster…");

        new Thread(() -> {
            try {
                // 1. Copy picked file to cache
                File cacheFile = new File(getCacheDir(), "encrypted.ros");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(cacheFile)) {
                    if (in == null) throw new Exception("Cannot open picked URI");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }

                currentRosFile = cacheFile;
                long size = cacheFile.length();

                // 2. Python decrypt + parse + resolve names
                Python py = Python.getInstance();
                PyObject mod = py.getModule("roster_names");
                final String json = mod.callAttr("list_players_from_java",
                        cacheFile.getAbsolutePath()).toString();

                if (json == null || json.startsWith("ERROR")) {
                    runOnUiThread(() -> {
                        tvStatusBar.setText("Failed: " + json);
                        Toast.makeText(this, json, Toast.LENGTH_LONG).show();
                    });
                    return;
                }

                // 3. Parse JSON
                JSONArray arr = new JSONArray(json);
                allPlayers.clear();
                allPlayerIds.clear();

                for (int i = 0; i < arr.length(); i++) {
                    JSONObject p = arr.getJSONObject(i);
                    String name = p.optString("displayName", "?");
                    int slot    = p.optInt("slot", 0);
                    int jersey  = p.optInt("jerseyNumber", 0);
                    int cf      = p.optInt("cyberfaceId", 0);
                    int team    = p.optInt("activeTeamSlot", -1);

                    String line = String.format(Locale.US,
                            "S%04d   %-25s  #%-3d  CF=%-5d  %s",
                            slot, name, jersey, cf,
                            team >= 0 ? "Team " + team : "FA");

                    allPlayers.add(line);
                    allPlayerIds.add(slot);
                }

                final int count = allPlayers.size();
                final long fsize = size;
                runOnUiThread(() -> {
                    if (tvCurrentFile != null) {
                        tvCurrentFile.setText(cacheFile.getName() + "  (" + fsize + " bytes)");
                    }
                    if (tvHint != null) {
                        tvHint.setText("Loaded " + count + " player records");
                    }
                    tvStatusBar.setText("Roster loaded: " + count + " players");
                    applyFilter(etSearchPlayer.getText().toString());
                    selectTab(3);
                });

            } catch (final Exception e) {
                Log.e(TAG, "loadRosterDatabase failed", e);
                runOnUiThread(() -> {
                    tvStatusBar.setText("Error: " + e.getMessage());
                    Toast.makeText(this, "Load failed: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void applyFilter(String q) {
        String query = (q == null) ? "" : q.trim().toLowerCase(Locale.ROOT);
        playerDisplayList.clear();
        playerIdList.clear();

        if (query.isEmpty()) {
            playerDisplayList.addAll(allPlayers);
            playerIdList.addAll(allPlayerIds);
        } else {
            for (int i = 0; i < allPlayers.size(); i++) {
                if (allPlayers.get(i).toLowerCase(Locale.ROOT).contains(query)) {
                    playerDisplayList.add(allPlayers.get(i));
                    playerIdList.add(allPlayerIds.get(i));
                }
            }
        }
        if (listAdapter != null) listAdapter.notifyDataSetChanged();

        if (tvStatusBar != null) {
            tvStatusBar.setText("Showing " + playerDisplayList.size()
                    + " of " + allPlayers.size() + " players");
        }
    }

    // ─────────────────────────────────────────────────
    private void saveAsNew() {
        if (currentRosFile == null || !currentRosFile.exists()) {
            Toast.makeText(this, "Load a roster first", Toast.LENGTH_SHORT).show();
            return;
        }
        // Placeholder — real save with re-encryption comes later
        Toast.makeText(this, "Save with re-encryption — coming next build",
                Toast.LENGTH_LONG).show();
    }
}