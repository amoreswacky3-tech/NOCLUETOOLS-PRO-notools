package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RosterEditorActivity extends Activity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    private ListView listView;
    private EditText etSearch;
    private TextView tvFileInfo, tvStatusBar;

    private final List<String> allPlayers = new ArrayList<>();
    private final List<String> shownPlayers = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    private File currentRosFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_simple);

        listView = findViewById(R.id.listViewRecords);
        etSearch = findViewById(R.id.etSearch);
        tvFileInfo = findViewById(R.id.tvFileInfo);
        tvStatusBar = findViewById(R.id.tvStatusBar);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAddRoster).setOnClickListener(v -> pickRosterFile());

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, shownPlayers);
        listView.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });
    }

    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            loadRoster(data.getData());
        }
    }

    private void loadRoster(Uri uri) {
        tvStatusBar.setText("Decrypting… (may take 15-40s)");

        new Thread(() -> {
            try {
                File cacheFile = new File(getCacheDir(), "roster.ros");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(cacheFile)) {
                    if (in == null) throw new Exception("Cannot open URI");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }

                currentRosFile = cacheFile;
                long size = cacheFile.length();

                Python py = Python.getInstance();
                PyObject mod = py.getModule("roster_names");
                final String json = mod.callAttr("list_players_from_java",
                        cacheFile.getAbsolutePath()).toString();

                if (json == null || json.startsWith("ERROR")) {
                    runOnUiThread(() -> {
                        tvStatusBar.setText("Failed");
                        Toast.makeText(this, json, Toast.LENGTH_LONG).show();
                    });
                    return;
                }

                JSONArray arr = new JSONArray(json);
                allPlayers.clear();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject p = arr.getJSONObject(i);
                    String name = p.optString("displayName", "?");
                    int slot = p.optInt("slot", 0);
                    int jersey = p.optInt("jerseyNumber", 0);
                    int cf = p.optInt("cyberfaceId", 0);
                    int team = p.optInt("activeTeamSlot", -1);

                    String line = String.format(Locale.US,
                            "S%04d  %-25s  #%d  CF=%d  %s",
                            slot, name, jersey, cf,
                            team >= 0 ? "Team " + team : "FA");
                    allPlayers.add(line);
                }

                final int count = allPlayers.size();
                runOnUiThread(() -> {
                    tvFileInfo.setText(cacheFile.getName() + " (" + size + " bytes)");
                    tvStatusBar.setText("Loaded " + count + " players");
                    filter(etSearch.getText().toString());
                });

            } catch (final Exception e) {
                Log.e(TAG, "load failed", e);
                runOnUiThread(() -> {
                    tvStatusBar.setText("Error: " + e.getMessage());
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void filter(String q) {
        String query = (q == null) ? "" : q.trim().toLowerCase(Locale.ROOT);
        shownPlayers.clear();
        if (query.isEmpty()) {
            shownPlayers.addAll(allPlayers);
        } else {
            for (String p : allPlayers) {
                if (p.toLowerCase(Locale.ROOT).contains(query)) {
                    shownPlayers.add(p);
                }
            }
        }
        adapter.notifyDataSetChanged();
        tvStatusBar.setText("Showing " + shownPlayers.size()
                + " of " + allPlayers.size());
    }
}