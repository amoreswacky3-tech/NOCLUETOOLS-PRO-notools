package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RosterEditorActivity extends Activity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    private ListView listView;
    private EditText etSearch;
    private TextView tvFileInfo, tvStatusBar;

    private final List<String> allPlayers = new ArrayList<>();
    private final List<String> shownPlayers = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    private File currentRosFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_simple);

        listView = findViewById(R.id.listViewRecords);
        etSearch = findViewById(R.id.etSearch);
        tvFileInfo = findViewById(R.id.tvFileInfo);
        tvStatusBar = findViewById(R.id.tvStatusBar);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAddRoster).setOnClickListener(v -> pickRosterFile());

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, shownPlayers);
        listView.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });
    }

    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            loadRoster(data.getData());
        }
    }

    private void loadRoster(Uri uri) {
    tvStatusBar.setText("Loading…");

    new Thread(() -> {
        try {
            File cache = new File(getCacheDir(), "roster.ros");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(cache)) {
                if (in == null) throw new Exception("Cannot open URI");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }

            final long t0 = System.currentTimeMillis();
            RosterLoader.Result r = RosterLoader.load(cache);
            final long ms = System.currentTimeMillis() - t0;

            allPlayers.clear();
            for (RosterLoader.Player p : r.players) {
                allPlayers.add(String.format(Locale.US,
                        "S%04d  %-25s  #%d  CF=%d  %s",
                        p.slot,
                        p.displayName,
                        p.jerseyNumber,
                        p.cyberfaceId,
                        p.activeTeamSlot >= 0 ? "Team " + p.activeTeamSlot : "FA"));
            }

            final int count = allPlayers.size();
            final String mode = r.cryptoMode;
            runOnUiThread(() -> {
                tvFileInfo.setText(cache.getName() + " (" + cache.length() + " bytes)");
                tvStatusBar.setText("Loaded " + count + " players · " + mode + " · " + ms + "ms");
                filter(etSearch.getText().toString());
            });

        } catch (final Exception e) {
            Log.e(TAG, "load failed", e);
            runOnUiThread(() -> tvStatusBar.setText("Error: " + e.getMessage()));
        }
    }).start();
}

    private void filter(String q) {
        String query = (q == null) ? "" : q.trim().toLowerCase(Locale.ROOT);
        shownPlayers.clear();
        if (query.isEmpty()) {
            shownPlayers.addAll(allPlayers);
        } else {
            for (String p : allPlayers) {
                if (p.toLowerCase(Locale.ROOT).contains(query)) {
                    shownPlayers.add(p);
                }
            }
        }
        adapter.notifyDataSetChanged();
        tvStatusBar.setText("Showing " + shownPlayers.size()
                + " of " + allPlayers.size());
    }
}