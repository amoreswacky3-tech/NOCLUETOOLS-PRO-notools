package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;

public class RosterEditorActivity extends Activity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    private TextView tvSectionName;
    private TextView tabHome, tabRoster, tabTeams, tabPlayers, tabTools;
    private View panelHome, panelRoster, panelTeams, panelPlayers, panelTools;

    private TextView tvHomeStatus, tvHomePlayerCount, tvHomeTeamCount;
    private TextView btnHomeOpenRoster, btnHomePlayerLab, btnHomeTeamControl, btnHomeTools;

    private TextView tvRosterFile, tvHint, btnOpenRoster2, btnSaveAsNew;

    private TextView btnTeamDatabase, btnFreeAgentManager, btnRotationSettings, btnRosterValidator;
    
    private EditText etSearch;
    private TextView tvFileInfo, tvStatusBar;
    private ListView listView;
    private View playerActionsDrawer;
    private TextView btnTogglePlayerActions;
    private TextView btnCreatePlayer, btnEditPlayer, btnPlayerEditorPro;
    private TextView btnCreateCyberface, btnAnimations, btnDraftInfo;

    private TextView btnSyncPlayer, btnApplyOnline, btnSyncWholeTeam, btnMoveRelease;
    private TextView btnOpenMainObb, btnOpenPatch98, btnScanPatchCfid, btnScanMainRealnames;
    private TextView btnExportCyberfaceIff, btnExportSelectedPlayerCf;

    private final List<String> allPlayers = new ArrayList<>();
    private final List<String> shownPlayers = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private File currentRosFile;
    private int selectedPlayerSlot = -1;  
    private View dropdownTeamSection;
    private TextView tvTeamSectionValue;
    private int activeTeamSlot = -1;

    private final Map<Integer, String> teamNames = new HashMap<>();
    private final Map<Integer, String> teamAbbrs = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_editor);

        tvSectionName = findViewById(R.id.tvSectionName);

        tabHome    = findViewById(R.id.tabHome);
        tabRoster  = findViewById(R.id.tabRoster);
        tabTeams   = findViewById(R.id.tabTeams);
        tabPlayers = findViewById(R.id.tabPlayers);
        tabTools   = findViewById(R.id.tabTools);

        panelHome    = findViewById(R.id.panelHome);
        panelRoster  = findViewById(R.id.panelRoster);
        panelTeams   = findViewById(R.id.panelTeams);
        panelPlayers = findViewById(R.id.panelPlayers);
        panelTools   = findViewById(R.id.panelTools);

        tvHomeStatus       = findViewById(R.id.tvHomeStatus);
        tvHomePlayerCount  = findViewById(R.id.tvHomePlayerCount);
        tvHomeTeamCount    = findViewById(R.id.tvHomeTeamCount);
        btnHomeOpenRoster  = findViewById(R.id.btnHomeOpenRoster);
        btnHomePlayerLab   = findViewById(R.id.btnHomePlayerLab);
        btnHomeTeamControl = findViewById(R.id.btnHomeTeamControl);
        btnHomeTools       = findViewById(R.id.btnHomeTools);

        tvRosterFile   = findViewById(R.id.tvRosterFile);
        tvHint         = findViewById(R.id.tvHint);
        btnOpenRoster2 = findViewById(R.id.btnOpenRoster2);
        btnSaveAsNew   = findViewById(R.id.btnSaveAsNew);

        btnTeamDatabase     = findViewById(R.id.btnTeamDatabase);
        btnFreeAgentManager = findViewById(R.id.btnFreeAgentManager);
        btnRotationSettings = findViewById(R.id.btnRotationSettings);
        btnRosterValidator  = findViewById(R.id.btnRosterValidator);
        
        dropdownTeamSection = findViewById(R.id.dropdownTeamSection);
         tvTeamSectionValue  = findViewById(R.id.tvTeamSectionValue);

if (dropdownTeamSection != null) {
    dropdownTeamSection.setOnClickListener(v -> showTeamPickerDialog());
}

        etSearch              = findViewById(R.id.etSearch);
        tvFileInfo            = findViewById(R.id.tvFileInfo);
        tvStatusBar           = findViewById(R.id.tvStatusBar);
        listView              = findViewById(R.id.listViewRecords);
        playerActionsDrawer   = findViewById(R.id.playerActionsDrawer);
        btnTogglePlayerActions= findViewById(R.id.btnTogglePlayerActions);
        btnCreatePlayer       = findViewById(R.id.btnCreatePlayer);
        btnEditPlayer         = findViewById(R.id.btnEditPlayer);
        btnPlayerEditorPro    = findViewById(R.id.btnPlayerEditorPro);
        btnCreateCyberface    = findViewById(R.id.btnCreateCyberface);
        btnAnimations         = findViewById(R.id.btnAnimations);
        btnDraftInfo          = findViewById(R.id.btnDraftInfo);

        btnSyncPlayer              = findViewById(R.id.btnSyncPlayer);
        btnApplyOnline             = findViewById(R.id.btnApplyOnline);
        btnSyncWholeTeam           = findViewById(R.id.btnSyncWholeTeam);
        btnMoveRelease             = findViewById(R.id.btnMoveRelease);
        btnOpenMainObb             = findViewById(R.id.btnOpenMainObb);
        btnOpenPatch98             = findViewById(R.id.btnOpenPatch98);
        btnScanPatchCfid           = findViewById(R.id.btnScanPatchCfid);
        btnScanMainRealnames       = findViewById(R.id.btnScanMainRealnames);
        btnExportCyberfaceIff      = findViewById(R.id.btnExportCyberfaceIff);
        btnExportSelectedPlayerCf  = findViewById(R.id.btnExportSelectedPlayerCf);

        // Bottom nav
        if (tabHome != null)    tabHome.setOnClickListener(v -> selectTab(0));
        if (tabRoster != null)  tabRoster.setOnClickListener(v -> selectTab(1));
        if (tabTeams != null)   tabTeams.setOnClickListener(v -> selectTab(2));
        if (tabPlayers != null) tabPlayers.setOnClickListener(v -> selectTab(3));
        if (tabTools != null)   tabTools.setOnClickListener(v -> selectTab(4));

        // Home shortcuts
        if (btnHomeOpenRoster != null)  btnHomeOpenRoster.setOnClickListener(v -> selectTab(1));
        if (btnHomePlayerLab != null)   btnHomePlayerLab.setOnClickListener(v -> selectTab(3));
        if (btnHomeTeamControl != null) btnHomeTeamControl.setOnClickListener(v -> selectTab(2));
        if (btnHomeTools != null)       btnHomeTools.setOnClickListener(v -> selectTab(4));

        // Roster panel
        if (btnOpenRoster2 != null) btnOpenRoster2.setOnClickListener(v -> pickRosterFile());
        if (btnSaveAsNew != null)   btnSaveAsNew.setOnClickListener(v ->
                toast("Save with re-encryption — coming next build"));

        View.OnClickListener soon = v -> toast("Coming soon");

        // Teams panel
        if (btnTeamDatabase != null)     btnTeamDatabase.setOnClickListener(v -> showTeamListDialog());
        if (btnFreeAgentManager != null) btnFreeAgentManager.setOnClickListener(v -> {
            selectTab(3);
            if (etSearch != null) etSearch.setText("FA");
        });
        if (btnRotationSettings != null) btnRotationSettings.setOnClickListener(soon);
        if (btnRosterValidator != null)  btnRosterValidator.setOnClickListener(v -> validateRoster());

        // Players panel
        if (btnCreatePlayer != null)    btnCreatePlayer.setOnClickListener(soon);
        if (btnEditPlayer != null) btnEditPlayer.setOnClickListener(v -> {
    if (selectedPlayerSlot < 0) { toast("Tap a player first"); return; }
    openPlayerEditorPro(selectedPlayerSlot);
});
            if (selectedPlayerSlot < 0) { toast("Tap a player first"); return; }
            showPlayerInfoDialog(selectedPlayerSlot);
        });
        if (btnPlayerEditorPro != null) btnPlayerEditorPro.setOnClickListener(soon);
        if (btnCreateCyberface != null) btnCreateCyberface.setOnClickListener(soon);
        if (btnAnimations != null)      btnAnimations.setOnClickListener(soon);
        if (btnDraftInfo != null)       btnDraftInfo.setOnClickListener(soon);

        // Tools panel
        if (btnSyncPlayer != null)             btnSyncPlayer.setOnClickListener(soon);
        if (btnApplyOnline != null)            btnApplyOnline.setOnClickListener(soon);
        if (btnSyncWholeTeam != null)          btnSyncWholeTeam.setOnClickListener(soon);
        if (btnMoveRelease != null)            btnMoveRelease.setOnClickListener(soon);
        if (btnOpenMainObb != null)            btnOpenMainObb.setOnClickListener(soon);
        if (btnOpenPatch98 != null)            btnOpenPatch98.setOnClickListener(soon);
        if (btnScanPatchCfid != null)          btnScanPatchCfid.setOnClickListener(soon);
        if (btnScanMainRealnames != null)      btnScanMainRealnames.setOnClickListener(soon);
        if (btnExportCyberfaceIff != null)     btnExportCyberfaceIff.setOnClickListener(soon);
        if (btnExportSelectedPlayerCf != null) btnExportSelectedPlayerCf.setOnClickListener(soon);

        // Drawer toggle
        if (btnTogglePlayerActions != null && playerActionsDrawer != null) {
            btnTogglePlayerActions.setOnClickListener(v -> {
                if (playerActionsDrawer.getVisibility() == View.VISIBLE) {
                    playerActionsDrawer.setVisibility(View.GONE);
                    btnTogglePlayerActions.setText("▲  PLAYER TOOLS");
                } else {
                    playerActionsDrawer.setVisibility(View.VISIBLE);
                    btnTogglePlayerActions.setText("▼  HIDE TOOLS");
                }
            });
        }

        // List adapter
        if (listView != null) {
            adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, shownPlayers);
            listView.setAdapter(adapter);

            listView.setOnItemClickListener((parent, view, position, id) -> {
    if (position >= 0 && position < shownPlayers.size()) {
        String line = shownPlayers.get(position);
        try {
            selectedPlayerSlot = Integer.parseInt(line.substring(1, 5));
        } catch (Exception ignored) {}
        if (tvStatusBar != null) tvStatusBar.setText("Selected: " + line);
    }
});

listView.setOnItemLongClickListener((parent, view, position, id) -> {
    if (position >= 0 && position < shownPlayers.size()) {
        String line = shownPlayers.get(position);
        try {
            int slot = Integer.parseInt(line.substring(1, 5));
            openPlayerEditorPro(slot);
        } catch (Exception ignored) {}
    }
    return true;
});

        // Search
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
            });
        }

        selectTab(0);
    }

    private void selectTab(int idx) {
        if (panelHome != null)    panelHome.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        if (panelRoster != null)  panelRoster.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        if (panelTeams != null)   panelTeams.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        if (panelPlayers != null) panelPlayers.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);
        if (panelTools != null)   panelTools.setVisibility(idx == 4 ? View.VISIBLE : View.GONE);

        TextView[] tabs = { tabHome, tabRoster, tabTeams, tabPlayers, tabTools };
        String[] names = { "HOME", "ROSTER", "TEAMS", "PLAYERS", "TOOLS" };

        for (int i = 0; i < tabs.length; i++) {
            if (tabs[i] == null) continue;
            if (i == idx) {
                tabs[i].setTextColor(0xFFFFFFFF);
                tabs[i].setBackgroundResource(R.drawable.bg_btn_primary);
            } else {
                tabs[i].setTextColor(0xFF6B7280);
                tabs[i].setBackgroundResource(R.drawable.bg_btn_secondary);
            }
        }
        if (tvSectionName != null) tvSectionName.setText(names[idx]);
    }

    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            loadRoster(data.getData());
        }
    }

    private void loadRoster(Uri uri) {
        if (tvStatusBar != null) tvStatusBar.setText("● Loading…");

        new Thread(() -> {
            try {
                File cache = new File(getCacheDir(), "roster.ros");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(cache)) {
                    if (in == null) throw new Exception("Cannot open URI");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }

                currentRosFile = cache;

                final long t0 = System.currentTimeMillis();
                RosterLoader.Result r = RosterLoader.load(cache);
                final long ms = System.currentTimeMillis() - t0;

                teamNames.clear();
                teamAbbrs.clear();
                for (RosterLoader.Team t : r.teams) {
                    teamNames.put(t.slot, t.fullName);
                    teamAbbrs.put(t.slot, t.abbreviation);
                }

                allPlayers.clear();
                for (RosterLoader.Player p : r.players) {
                    String teamLabel = "FA";
                    if (p.activeTeamSlot >= 0) {
                        String abbr = teamAbbrs.get(p.activeTeamSlot);
                        if (abbr != null && !abbr.isEmpty()) {
                            teamLabel = abbr;
                        } else {
                            teamLabel = "T" + p.activeTeamSlot;
                        }
                    }
                    allPlayers.add(String.format(Locale.US,
                            "S%04d  %-25s  #%d  CF=%d  %s",
                            p.slot,
                            p.displayName,
                            p.jerseyNumber,
                            p.cyberfaceId,
                            teamLabel));
                }

                final int count = allPlayers.size();
                final String mode = r.cryptoMode;
                final int teamCount = r.teamCount;

                runOnUiThread(() -> {
                    if (tvFileInfo != null) tvFileInfo.setText(cache.getName() + " (" + cache.length() + " bytes)");
                    if (tvRosterFile != null) tvRosterFile.setText(cache.getName() + "  ·  " + count + " players");
                    if (tvHint != null) tvHint.setText("Loaded " + count + " records · " + mode);
                    if (tvHomeStatus != null) tvHomeStatus.setText("● Loaded · " + mode + " · " + ms + "ms");
                    if (tvHomePlayerCount != null) tvHomePlayerCount.setText(String.valueOf(count));
                    if (tvHomeTeamCount != null) tvHomeTeamCount.setText(String.valueOf(teamCount));
                    if (tvStatusBar != null) tvStatusBar.setText("● Loaded " + count + " players · " + mode + " · " + ms + "ms");
                    if (etSearch != null) filter(etSearch.getText().toString());
                    selectTab(3);
                });

            } catch (final Exception e) {
                Log.e(TAG, "load failed", e);
                runOnUiThread(() -> {
                    if (tvStatusBar != null) tvStatusBar.setText("● Error: " + e.getMessage());
                    toast("Load failed: " + e.getMessage());
                });
            }
        }).start();
    }

    private void filter(String q) {
        String query = (q == null) ? "" : q.trim().toLowerCase(Locale.ROOT);
        shownPlayers.clear();
        if (query.isEmpty()) {
            shownPlayers.addAll(allPlayers);
        } else {
            for (String p : allPlayers) {
                if (p.toLowerCase(Locale.ROOT).contains(query)) {
                    shownPlayers.add(p);
                }
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        if (tvStatusBar != null) {
            tvStatusBar.setText("● Showing " + shownPlayers.size()
                    + " of " + allPlayers.size());
        }
    }

    private void showPlayerInfoDialog(int slot) {
        String line = null;
        for (String p : allPlayers) {
            if (p.startsWith("S" + String.format(Locale.US, "%04d", slot))) {
                line = p;
                break;
            }
        }
        if (line == null) { toast("Player not found"); return; }

        new android.app.AlertDialog.Builder(this)
                .setTitle("PLAYER S" + String.format(Locale.US, "%04d", slot))
                .setMessage(line + "\n\n"
                        + "Editing features coming next build.\n"
                        + "(Jersey, CF ID, Name, Ratings)")
                .setPositiveButton("CLOSE", null)
                .show();
    }

    private void showTeamListDialog() {
        if (allPlayers.isEmpty()) { toast("Load a roster first"); return; }
        if (teamNames.isEmpty())  { toast("Team data not loaded"); return; }

        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (Map.Entry<Integer, String> e : teamNames.entrySet()) {
            int slot = e.getKey();
            String full = e.getValue();
            String abbr = teamAbbrs.getOrDefault(slot, "");
            if (full == null || full.isEmpty()) continue;
            if (count++ > 0) sb.append("\n");
            sb.append(String.format(Locale.US, "%2d  %-28s  %s", slot, full, abbr));
            if (count >= 30) break;
        }

        new android.app.AlertDialog.Builder(this)
                .setTitle("TEAM DATABASE")
                .setMessage(sb.toString())
                .setPositiveButton("CLOSE", null)
                .show();
    }

    private void validateRoster() {
        if (allPlayers.isEmpty()) { toast("Load a roster first"); return; }

        int faCount = 0, teamCount = 0;
        for (String p : allPlayers) {
            if (p.contains(" FA")) faCount++; else teamCount++;
        }

        new android.app.AlertDialog.Builder(this)
                .setTitle("ROSTER VALIDATOR")
                .setMessage("Total players: " + allPlayers.size() + "\n"
                        + "On teams: " + teamCount + "\n"
                        + "Free agents: " + faCount + "\n\n"
                        + "Basic structure: OK")
                .setPositiveButton("CLOSE", null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
    
    private void showTeamPickerDialog() {
    if (teamNames.isEmpty()) {
        toast("Load a roster first");
        return;
    }

    // Sort team slots
    final TreeSet<Integer> slots = new TreeSet<>(teamNames.keySet());
    final String[] labels = new String[slots.size()];
    final int[] slotArr = new int[slots.size()];

    int i = 0;
    for (int slot : slots) {
        String full = teamNames.get(slot);
        String abbr = teamAbbrs.getOrDefault(slot, "");
        labels[i] = (full != null && !full.isEmpty() ? full : "Team " + slot) + "  ·  " + abbr;
        slotArr[i] = slot;
        i++;
    }

    new android.app.AlertDialog.Builder(this)
            .setTitle("SELECT ACTIVE TEAM")
            .setItems(labels, (dialog, which) -> {
    activeTeamSlot = slotArr[which];
    if (tvTeamSectionValue != null) {
        tvTeamSectionValue.setText(labels[which]);
    }
    // Auto-filter players to this team
    String abbr = teamAbbrs.getOrDefault(activeTeamSlot, "");
    if (etSearch != null && !abbr.isEmpty()) {
        selectTab(3);
        etSearch.setText(abbr);
    }
    toast("Active: " + labels[which]);
})
            .setNegativeButton("CANCEL", null)
            .show();
}

private void openPlayerEditorPro(int slot) {
    RosterLoader.Player target = null;
    // We don't cache Player objects after load. Re-read from file.
    if (currentRosFile == null || !currentRosFile.exists()) {
        toast("Load a roster first");
        return;
    }
    try {
        RosterLoader.Result r = RosterLoader.load(currentRosFile);
        if (slot >= 0 && slot < r.players.size()) {
            target = r.players.get(slot);
        }
    } catch (Exception e) {
        toast("Could not reload roster: " + e.getMessage());
        return;
    }
    if (target == null) { toast("Player not found"); return; }

    PlayerEditorProDialog dlg = new PlayerEditorProDialog(
            this, target, teamNames, teamAbbrs);
    dlg.show();
}

}