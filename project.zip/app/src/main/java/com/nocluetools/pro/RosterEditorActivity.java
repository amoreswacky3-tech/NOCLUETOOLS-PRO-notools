package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RosterEditorActivity extends Activity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    // Top bar
    private TextView tvSectionName;

    // Tabs
    private TextView tabHome, tabRoster, tabTeams, tabPlayers, tabTools;

    // Panels
    private View panelHome, panelRoster, panelTeams, panelPlayers, panelTools;

    // Home stats
    private TextView tvHomeStatus, tvHomePlayerCount, tvHomeTeamCount;

    // Roster panel
    private TextView tvRosterFile, btnOpenRoster2, btnSaveAsNew;

    // Players panel
    private EditText etSearch;
    private TextView tvFileInfo, tvStatusBar;
    private ListView listView;

    // Data
    private final List<String> allPlayers = new ArrayList<>();
    private final List<String> shownPlayers = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private File currentRosFile;
    private int currentTab = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_editor);

        // Top bar
        tvSectionName = findViewById(R.id.tvSectionName);

        // Tabs
        tabHome    = findViewById(R.id.tabHome);
        tabRoster  = findViewById(R.id.tabRoster);
        tabTeams   = findViewById(R.id.tabTeams);
        tabPlayers = findViewById(R.id.tabPlayers);
        tabTools   = findViewById(R.id.tabTools);

        // Panels
        panelHome    = findViewById(R.id.panelHome);
        panelRoster  = findViewById(R.id.panelRoster);
        panelTeams   = findViewById(R.id.panelTeams);
        panelPlayers = findViewById(R.id.panelPlayers);
        panelTools   = findViewById(R.id.panelTools);

        // Home stats
        tvHomeStatus      = findViewById(R.id.tvHomeStatus);
        tvHomePlayerCount = findViewById(R.id.tvHomePlayerCount);
        tvHomeTeamCount   = findViewById(R.id.tvHomeTeamCount);

        // Roster panel
        tvRosterFile    = findViewById(R.id.tvRosterFile);
        btnOpenRoster2  = findViewById(R.id.btnOpenRoster2);
        btnSaveAsNew    = findViewById(R.id.btnSaveAsNew);

        // Players panel
        etSearch    = findViewById(R.id.etSearch);
        tvFileInfo  = findViewById(R.id.tvFileInfo);
        tvStatusBar = findViewById(R.id.tvStatusBar);
        listView    = findViewById(R.id.listViewRecords);

        // Wire top bar
        if (btnOpenRoster2 != null) btnOpenRoster2.setOnClickListener(v -> pickRosterFile());
        if (btnSaveAsNew != null) btnSaveAsNew.setOnClickListener(v -> {
            Toast.makeText(this, "Save with re-encryption — coming next build",
                    Toast.LENGTH_LONG).show();
        });

        // Wire tabs
        if (tabHome != null)    tabHome.setOnClickListener(v -> selectTab(0));
        if (tabRoster != null)  tabRoster.setOnClickListener(v -> selectTab(1));
        if (tabTeams != null)   tabTeams.setOnClickListener(v -> selectTab(2));
        if (tabPlayers != null) tabPlayers.setOnClickListener(v -> selectTab(3));
        if (tabTools != null)   tabTools.setOnClickListener(v -> selectTab(4));

        // Player list adapter
        if (listView != null) {
            adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, shownPlayers);
            listView.setAdapter(adapter);
        }

        // Search
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
            });
        }

        selectTab(0);
    }

    // ─────────────────────────────────────────────────
    private void selectTab(int idx) {
        currentTab = idx;

        if (panelHome != null)    panelHome.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        if (panelRoster != null)  panelRoster.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        if (panelTeams != null)   panelTeams.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        if (panelPlayers != null) panelPlayers.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);
        if (panelTools != null)   panelTools.setVisibility(idx == 4 ? View.VISIBLE : View.GONE);

        TextView[] tabs = { tabHome, tabRoster, tabTeams, tabPlayers, tabTools };
        String[] names = { "HOME", "ROSTER", "TEAMS", "PLAYERS", "TOOLS" };

        for (int i = 0; i < tabs.length; i++) {
            if (tabs[i] == null) continue;
            if (i == idx) {
                tabs[i].setTextColor(0xFFFFFFFF);
                tabs[i].setBackgroundResource(R.drawable.bg_btn_primary);
            } else {
                tabs[i].setTextColor(0xFF6B7280);
                tabs[i].setBackgroundResource(R.drawable.bg_btn_secondary);
            }
        }

        if (tvSectionName != null) tvSectionName.setText(names[idx]);
    }

    // ─────────────────────────────────────────────────
    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            loadRoster(data.getData());
        }
    }

    // ─────────────────────────────────────────────────
    private void loadRoster(Uri uri) {
        if (tvStatusBar != null) tvStatusBar.setText("Loading…");

        new Thread(() -> {
            try {
                File cache = new File(getCacheDir(), "roster.ros");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(cache)) {
                    if (in == null) throw new Exception("Cannot open URI");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }

                currentRosFile = cache;

                final long t0 = System.currentTimeMillis();
                RosterLoader.Result r = RosterLoader.load(cache);
                final long ms = System.currentTimeMillis() - t0;

                allPlayers.clear();
                for (RosterLoader.Player p : r.players) {
                    allPlayers.add(String.format(Locale.US,
                            "S%04d  %-25s  #%d  CF=%d  %s",
                            p.slot,
                            p.displayName,
                            p.jerseyNumber,
                            p.cyberfaceId,
                            p.activeTeamSlot >= 0 ? "Team " + p.activeTeamSlot : "FA"));
                }

                final int count = allPlayers.size();
                final String mode = r.cryptoMode;
                final int teamCount = r.teamCount;

                runOnUiThread(() -> {
                    if (tvFileInfo != null) tvFileInfo.setText(cache.getName() + " (" + cache.length() + " bytes)");
                    if (tvRosterFile != null) tvRosterFile.setText(cache.getName() + "  ·  " + count + " players");
                    if (tvHomeStatus != null) tvHomeStatus.setText("Loaded · " + mode + " · " + ms + "ms");
                    if (tvHomePlayerCount != null) tvHomePlayerCount.setText(String.valueOf(count));
                    if (tvHomeTeamCount != null) tvHomeTeamCount.setText(String.valueOf(teamCount));
                    if (tvStatusBar != null) tvStatusBar.setText("Loaded " + count + " players · " + mode + " · " + ms + "ms");
                    if (etSearch != null) filter(etSearch.getText().toString());
                    selectTab(3);   // auto-jump to PLAYERS tab
                });

            } catch (final Exception e) {
                Log.e(TAG, "load failed", e);
                runOnUiThread(() -> {
                    if (tvStatusBar != null) tvStatusBar.setText("Error: " + e.getMessage());
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void filter(String q) {
        String query = (q == null) ? "" : q.trim().toLowerCase(Locale.ROOT);
        shownPlayers.clear();
        if (query.isEmpty()) {
            shownPlayers.addAll(allPlayers);
        } else {
            for (String p : allPlayers) {
                if (p.toLowerCase(Locale.ROOT).contains(query)) {
                    shownPlayers.add(p);
                }
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        if (tvStatusBar != null) {
            tvStatusBar.setText("Showing " + shownPlayers.size()
                    + " of " + allPlayers.size());
        }
    }
}