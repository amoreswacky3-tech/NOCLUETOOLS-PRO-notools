package com.nocluetools.pro;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.Inflater;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


public final class ObjEngine {

    public ObjEngine() {} // Palitan mo yung private

    // ==========================================
    // 0. ENUMS
    // ==========================================
    public enum RenderMode { SOLID, WIREFRAME, POINTS }
    public enum EditorMode { OBJECT, EDIT_VERTEX }

    // ==========================================
    // 1. OBJ MODEL DATA STRUCTURE
    // ==========================================
    public static final class ObjModel {
        public final List<float[]> vertices = new ArrayList<float[]>();
        public final List<float[]> texcoords = new ArrayList<float[]>();
        public final List<float[]> normals = new ArrayList<float[]>();
        public final List<Face> faces = new ArrayList<Face>();
        public final HashSet<Integer> selectedVertices = new HashSet<Integer>();
        public final HashSet<Integer> selectedUVs = new HashSet<Integer>();
        public final java.util.LinkedHashMap<String, HashSet<Integer>> uvGroups = new java.util.LinkedHashMap<String, HashSet<Integer>>();
        public String visibleGroup = "All";
        public boolean staticIffPreview;
        /** Separate interchange viewer policy; never marks N2KM as verified IFF geometry. */
        public boolean readOnlyPreview;
        public boolean rawInterchangeCoordinates;
        public boolean preservePartTopology;
        public boolean flipTextureV = true;
        public String provenance = "";
        public void setUVGroup(String name, HashSet<Integer> indices) { if (name == null) return; HashSet<Integer> c = new HashSet<Integer>(); if (indices != null) c.addAll(indices); uvGroups.put(name, c); }
        public String[] getUVGroupNames() { return uvGroups.keySet().toArray(new String[uvGroups.size()]); }
        public void selectUVGroup(String name) { selectedUVs.clear(); if ("All".equalsIgnoreCase(name)) { selectAllUVs(); return; } HashSet<Integer> g = uvGroups.get(name); if (g != null) selectedUVs.addAll(g); }

        public static final class Face {
            public final int[] v;
            public final int[] vn;
            public final int[] vt;
            public final String sourceLabel;
            public String groupLabel;
            public Face(int[] v, int[] vt, int[] vn) {
                this(v,vt,vn,null);
            }
            public Face(int[] v, int[] vt, int[] vn, String sourceLabel) {
                this.v = v; this.vt = vt; this.vn = vn;this.sourceLabel=sourceLabel;
            }
        }

        public ObjModel deepCopy() {
            ObjModel out = new ObjModel();
            out.staticIffPreview=staticIffPreview; out.flipTextureV=flipTextureV; out.provenance=provenance;
            out.readOnlyPreview=readOnlyPreview;
            out.rawInterchangeCoordinates=rawInterchangeCoordinates;
            out.preservePartTopology=preservePartTopology;
            for (float[] p : this.vertices) out.vertices.add(p.clone());
            for (float[] p2 : this.texcoords) out.texcoords.add(p2.clone());
            for (float[] p3 : this.normals) out.normals.add(p3.clone());
            for (Face f : this.faces) {
                Face copy=new Face(f.v.clone(), f.vt.clone(), f.vn.clone(),f.sourceLabel);copy.groupLabel=f.groupLabel;out.faces.add(copy);
            }
            for (java.util.Map.Entry<String, HashSet<Integer>> e : this.uvGroups.entrySet()) out.uvGroups.put(e.getKey(), new HashSet<Integer>(e.getValue()));
            return out;
        }

        public int triangleCount() {
            int n = 0;
            for (Face f : this.faces) if (f.v.length >= 3) n += f.v.length - 2;
            return n;
        }

        // ============================================================
        // UV EDITOR
        // ============================================================
        public boolean hasUVs() { return !texcoords.isEmpty(); }
        public void clearUVSelection() { selectedUVs.clear(); }
        public void selectUV(int index) { if (index >= 0 && index < texcoords.size()) selectedUVs.add(Integer.valueOf(index)); }
        public void selectAllUVs() { selectedUVs.clear(); for (int i = 0; i < texcoords.size(); i++) selectedUVs.add(Integer.valueOf(i)); }
        public void translateSelectedUV(float du, float dv) {
            if (readOnlyPreview) return;
            for (Integer idx : selectedUVs) {
                if (idx == null || idx.intValue() < 0 || idx.intValue() >= texcoords.size()) continue;
                float[] uv = texcoords.get(idx.intValue()); uv[0] += du; uv[1] += dv;
            }
        }

        public void flipU() {
            if (readOnlyPreview) return;
            for (float[] uv : texcoords) uv[0] = 1.0f - uv[0];
        }

        public void flipV() {
            if (readOnlyPreview) return;
            for (float[] uv : texcoords) uv[1] = 1.0f - uv[1];
        }

        public void rotateUV90() {
            if (readOnlyPreview) return;
            for (float[] uv : texcoords) {
                float u = uv[0];
                float v = uv[1];
                uv[0] = 1.0f - v;
                uv[1] = u;
            }
        }

        public void translateUV(float du, float dv) {
            if (readOnlyPreview) return;
            for (float[] uv : texcoords) {
                uv[0] += du;
                uv[1] += dv;
            }
        }

        public void scaleUV(float factor) {
            if (readOnlyPreview) return;
            if (factor <= 0f) return;
            for (float[] uv : texcoords) {
                uv[0] = 0.5f + (uv[0] - 0.5f) * factor;
                uv[1] = 0.5f + (uv[1] - 0.5f) * factor;
            }
        }

        public void rotateUV(float degrees) {
            if (readOnlyPreview) return;
            double rad = Math.toRadians(degrees);
            float cos = (float)Math.cos(rad);
            float sin = (float)Math.sin(rad);
            for (float[] uv : texcoords) {
                float x = uv[0] - 0.5f;
                float y = uv[1] - 0.5f;
                float nx = x * cos - y * sin;
                float ny = x * sin + y * cos;
                uv[0] = nx + 0.5f;
                uv[1] = ny + 0.5f;
            }
        }

        public void center() {
            if (readOnlyPreview) return;
            if (this.vertices.isEmpty()) return;
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
            for (float[] p : this.vertices) {
                minX = Math.min(minX, p[0]); minY = Math.min(minY, p[1]); minZ = Math.min(minZ, p[2]);
                maxX = Math.max(maxX, p[0]); maxY = Math.max(maxY, p[1]); maxZ = Math.max(maxZ, p[2]);
            }
            float cx = (minX + maxX) / 2f, cy = (minY + maxY) / 2f, cz = (minZ + maxZ) / 2f;
            float maxDim = Math.max(maxX - minX, Math.max(maxY - minY, maxZ - minZ));
            float scale = maxDim > 0 ? (2f / maxDim) : 1f;
            for (float[] p : this.vertices) {
                p[0] = (p[0] - cx) * scale;
                p[1] = (p[1] - cy) * scale;
                p[2] = (p[2] - cz) * scale;
            }
        }

        public void deleteSelectedVertices() {
            if (staticIffPreview || readOnlyPreview || preservePartTopology || selectedVertices.isEmpty()) return;
            int[] remap = new int[vertices.size()];
            int newIdx = 0;
            for (int i = 0; i < vertices.size(); i++) {
                if (selectedVertices.contains(Integer.valueOf(i))) remap[i] = -1;
                else remap[i] = newIdx++;
            }
            List<float[]> newVerts = new ArrayList<float[]>();
            for (int i = 0; i < vertices.size(); i++) {
                if (remap[i] != -1) newVerts.add(vertices.get(i));
            }
            List<Face> newFaces = new ArrayList<Face>();
            for (Face f : faces) {
                List<Integer> vList = new ArrayList<Integer>();
                List<Integer> tList = new ArrayList<Integer>();
                List<Integer> nList = new ArrayList<Integer>();
                for (int i = 0; i < f.v.length; i++) {
                    if (remap[f.v[i]] != -1) {
                        vList.add(remap[f.v[i]]);
                        tList.add(f.vt != null && i < f.vt.length ? f.vt[i] : -1);
                        nList.add(f.vn != null && i < f.vn.length ? f.vn[i] : -1);
                    }
                }
                if (vList.size() >= 3) {
                    int[] newV = new int[vList.size()];
                    int[] newT = new int[vList.size()];
                    int[] newN = new int[vList.size()];
                    for (int i = 0; i < vList.size(); i++) {
                        newV[i] = vList.get(i).intValue();
                        newT[i] = tList.get(i).intValue();
                        newN[i] = nList.get(i).intValue();
                    }
                    newFaces.add(new Face(newV, newT, newN));
                }
            }
            vertices.clear();
            vertices.addAll(newVerts);
            faces.clear();
            faces.addAll(newFaces);
            selectedVertices.clear();
        }
    }

    // ==========================================
    // Legacy heuristic IFF geometry scanners removed. NBA2K15Mesh is authoritative.
    // 2. GL VIEW
    // ==========================================
    public static final class ObjGLView extends GLSurfaceView {
        private final ObjRenderer renderer;
        private final ScaleGestureDetector scaleDetector;

        private float lastX, lastY;
        private int activePointerId = -1;

        private float rotX = -10f, rotY = 180f, scale = 1f, panX = 0f, panY = 0f;

        private EditorMode editorMode = EditorMode.OBJECT;

        public interface SelectionListener {
            void onSelectionChanged(int count);
            void onModelChanged();
        }
        private SelectionListener selectionListener;

        public ObjGLView(Context context) {
            super(context);
            setEGLContextClientVersion(2);
            renderer = new ObjRenderer();
            setRenderer(renderer);
            setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

            scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        scale *= d.getScaleFactor();
                        if (scale < 0.3f) scale = 0.3f;
                        if (scale > 8f) scale = 8f;
                        syncTransform();
                        requestRender();
                        return true;
                    }
                });
        }

        public void setSelectionListener(SelectionListener l) { this.selectionListener = l; }

        public void setModel(ObjModel model) {
            renderer.setModel(model);
            resetView();
        }

        public void setTexture(Bitmap bmp) { renderer.setTexture(bmp); requestRender(); }

        public void setVisibleGroup(String name) { renderer.setVisibleGroup(name); requestRender(); }
        public String getVisibleGroup() { return renderer.getVisibleGroup(); }

        public boolean hasUVs() { return renderer.hasUVs(); }
        public void beginUVEdit() { renderer.beginUVEdit(); }
        public void uvFlipU() { renderer.uvFlipU(); requestRender(); }
        public void uvFlipV() { renderer.uvFlipV(); requestRender(); }
        public void uvRotate90() { renderer.uvRotate90(); requestRender(); }
        public void uvScale(float factor) { renderer.uvScale(factor); requestRender(); }
        public void uvRotate(float degrees) { renderer.uvRotate(degrees); requestRender(); }
        public void uvTranslate(float du, float dv) { renderer.uvTranslate(du, dv); requestRender(); }
        public void clearUVSelection() { renderer.clearUVSelection(); requestRender(); }
        public void selectUV(int index) { renderer.selectUV(index); requestRender(); }
        public void selectAllUVs() { renderer.selectAllUVs(); requestRender(); }
        public void selectUVGroup(String name) { renderer.selectUVGroup(name); requestRender(); }
        public String[] getUVGroupNames() { return renderer.getUVGroupNames(); }
        public void translateSelectedUV(float du, float dv) { renderer.translateSelectedUV(du, dv); requestRender(); }
        public void uvReset() { renderer.uvReset(); requestRender(); }

        public void setRenderMode(RenderMode mode) {
            renderer.setRenderMode(mode);
            requestRender();
        }

        public RenderMode getCurrentRenderMode() { return renderer.getRenderMode(); }

        public void setEditorMode(EditorMode mode) {
            this.editorMode = mode;
            if (mode == EditorMode.EDIT_VERTEX) {
                renderer.setRenderMode(RenderMode.WIREFRAME);
            } else {
                renderer.setRenderMode(RenderMode.SOLID);
            }
            requestRender();
        }

        public EditorMode getEditorMode() { return editorMode; }

        public int getSelectionCountForDelete() {
            return renderer.getSelectionCount();
        }

        public void resetView() {
            rotX = -10f;
            // Verified static coordinates face +Z in the representative preview.
            rotY = renderer.getCurrentModel()!=null && (renderer.getCurrentModel().staticIffPreview || renderer.getCurrentModel().readOnlyPreview || renderer.getCurrentModel().rawInterchangeCoordinates) ? 0f : 180f;
            scale = 1f;
            panX = 0f;
            panY = 0f;
            syncTransform();
            requestRender();
        }

        private void syncTransform() {
            renderer.setTransform(rotX, rotY, scale, panX, panY);
        }

        public void clearSelection() {
            renderer.clearSelection();
            notifySelectionChanged();
            requestRender();
        }

        public void deleteSelected() {
            renderer.deleteSelected();
            notifySelectionChanged();
            requestRender();
            if (selectionListener != null) selectionListener.onModelChanged();
        }

        public void addVertexAtCenter() {
            renderer.addVertexAtCenter();
            notifySelectionChanged();
            requestRender();
            if (selectionListener != null) selectionListener.onModelChanged();
        }

        private void notifySelectionChanged() {
            if (selectionListener != null) {
                selectionListener.onSelectionChanged(renderer.getSelectionCount());
            }
        }

        @SuppressLint("ClickableViewAccessibility")
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    activePointerId = event.getPointerId(0);
                    return true;

                case MotionEvent.ACTION_POINTER_DOWN:
                    if (event.getPointerCount() == 2) {
                        lastX = (event.getX(0) + event.getX(1)) / 2f;
                        lastY = (event.getY(0) + event.getY(1)) / 2f;
                    }
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (event.getPointerCount() == 1 && !scaleDetector.isInProgress()) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        lastX = event.getX();
                        lastY = event.getY();

                        if (editorMode == EditorMode.OBJECT) {
                            rotY += dx * 0.4f;
                            rotX += dy * 0.4f;
                            if (rotX > 89f) rotX = 89f;
                            if (rotX < -89f) rotX = -89f;
                            syncTransform();
                            requestRender();
                        } else {
                            if (renderer.getSelectionCount() > 0) {
                                float worldScale = 0.01f / scale;
                                renderer.moveSelectedVertices(
                                    dx * worldScale, -dy * worldScale);
                                requestRender();
                                if (selectionListener != null) selectionListener.onModelChanged();
                            } else {
                                rotY += dx * 0.4f;
                                rotX += dy * 0.4f;
                                if (rotX > 89f) rotX = 89f;
                                if (rotX < -89f) rotX = -89f;
                                syncTransform();
                                requestRender();
                            }
                        }
                    } else if (event.getPointerCount() >= 2 && !scaleDetector.isInProgress()) {
                        float x = (event.getX(0) + event.getX(1)) / 2f;
                        float y = (event.getY(0) + event.getY(1)) / 2f;
                        float dx = x - lastX;
                        float dy = y - lastY;
                        panX += dx * 0.01f;
                        panY -= dy * 0.01f;
                        lastX = x;
                        lastY = y;
                        syncTransform();
                        requestRender();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
						if (editorMode == EditorMode.EDIT_VERTEX) {
							renderer.pickVertexAtScreen(event.getX(), event.getY(),
														getWidth(), getHeight());
							notifySelectionChanged();
							requestRender();
						}
						activePointerId = -1;
						return true;
					}
            }
            return super.onTouchEvent(event);
        }
    }

    // ==========================================
    // 3. RENDERER
    // ==========================================
    private static class ObjRenderer implements GLSurfaceView.Renderer {
        private FloatBuffer vertexBuffer;
        private FloatBuffer edgeBuffer;
        private int edgeVertexCount;
        private float fitScale=1f, centerX,centerY,centerZ;
        private FloatBuffer texBuffer;
        private FloatBuffer normalBuffer;
        private FloatBuffer pointPositionsBuffer;
        private FloatBuffer selectedPointPositionsBuffer;

        private int vertexCount = 0;
        private int pointCount = 0;
        private int selectedPointCount = 0;

        private int solidProgram, lineProgram, pointProgram;

        private int s_aPosition, s_aTexCoord, s_aNormal;
        private int s_uMVPMatrix, s_uModelMatrix, s_uUseTexture, s_uTexture;

        private int l_aPosition, l_uMVPMatrix, l_uColor;

        private int p_aPosition, p_uMVPMatrix, p_uColor, p_uSize;

        private RenderMode renderMode = RenderMode.SOLID;
        private int textureId = -1;
        private Bitmap pendingBitmap = null;
        private boolean textureDirty = false;
        private boolean hasTexCoords = false;

        private float rotX = -10f, rotY = 180f, scale = 1f, panX = 0f, panY = 0f;

        private final float[] mvpMatrix = new float[16];
        private final float[] projMatrix = new float[16];
        private final float[] viewMatrix = new float[16];
        private final float[] modelMatrix = new float[16];
        private final float[] tempMatrix = new float[16];

        private ObjModel currentModel;
        private String visibleGroup = "All";
        private ObjModel uvBackup;
        private int viewWidth = 1, viewHeight = 1;

        private static final String SOLID_VS =
		"uniform mat4 uMVPMatrix;\n" +
		"uniform mat4 uModelMatrix;\n" +
		"attribute vec4 aPosition;\n" +
		"attribute vec2 aTexCoord;\n" +
		"attribute vec3 aNormal;\n" +
		"varying vec2 vTexCoord;\n" +
		"varying vec3 vNormal;\n" +
		"varying vec3 vPos;\n" +
		"void main() {\n" +
		"  gl_Position = uMVPMatrix * aPosition;\n" +
		"  vTexCoord = aTexCoord;\n" +
		"  vNormal = mat3(uModelMatrix) * aNormal;\n" +
		"  vPos = (uModelMatrix * aPosition).xyz;\n" +
		"}\n";

        private static final String SOLID_FS =
		"precision mediump float;\n" +
		"varying vec2 vTexCoord;\n" +
		"varying vec3 vNormal;\n" +
		"varying vec3 vPos;\n" +
		"uniform sampler2D uTexture;\n" +
		"uniform bool uUseTexture;\n" +
		"void main() {\n" +
		"  vec3 N = normalize(vNormal);\n" +
		"  vec3 L1 = normalize(vec3(0.5, 0.8, 0.6));\n" +
		"  float d1 = max(dot(N, L1), 0.0);\n" +
		"  float ambient = 0.35;\n" +
		"  vec3 base;\n" +
		"  if (uUseTexture) base = texture2D(uTexture, vTexCoord).rgb;\n" +
		"  else base = vec3(0.72, 0.72, 0.72);\n" +
		"  vec3 col = base * (ambient + d1 * 0.9);\n" +
		"  vec3 V = normalize(-vPos);\n" +
		"  float rim = pow(1.0 - max(dot(N, V), 0.0), 2.5);\n" +
		"  col += vec3(1.0, 1.0, 1.0) * rim * 0.2;\n" +
		"  gl_FragColor = vec4(col, 1.0);\n" +
		"}\n";

        private static final String LINE_VS =
		"uniform mat4 uMVPMatrix;\n" +
		"attribute vec4 aPosition;\n" +
		"void main() { gl_Position = uMVPMatrix * aPosition; }\n";

        private static final String LINE_FS =
		"precision mediump float;\n" +
		"uniform vec3 uColor;\n" +
		"void main() { gl_FragColor = vec4(uColor, 1.0); }\n";

        private static final String POINT_VS =
		"uniform mat4 uMVPMatrix;\n" +
		"uniform float uSize;\n" +
		"attribute vec4 aPosition;\n" +
		"void main() {\n" +
		"  gl_Position = uMVPMatrix * aPosition;\n" +
		"  gl_PointSize = uSize;\n" +
		"}\n";

        private static final String POINT_FS =
		"precision mediump float;\n" +
		"uniform vec3 uColor;\n" +
		"void main() {\n" +
		"  vec2 c = gl_PointCoord - vec2(0.5);\n" +
		"  float d = length(c);\n" +
		"  if (d > 0.5) discard;\n" +
		"  gl_FragColor = vec4(uColor, 1.0);\n" +
		"}\n";

		public synchronized String[] getUVGroupNames() {
            return currentModel==null?new String[0]:currentModel.getUVGroupNames();
		}

		public synchronized void selectUVGroup(String name) {
            if(currentModel!=null) currentModel.selectUVGroup(name);
		}

        public synchronized void setRenderMode(RenderMode mode) { this.renderMode = mode; }
        public synchronized RenderMode getRenderMode() { return renderMode; }
        public synchronized void setTransform(float rx, float ry, float s, float px, float py) {
            rotX = rx; rotY = ry; scale = s; panX = px; panY = py;
        }
        public synchronized void setTexture(Bitmap b) { this.pendingBitmap = b; this.textureDirty = true; }

        public synchronized int getSelectionCount() {
            return currentModel != null ? currentModel.selectedVertices.size() : 0;
        }

        public synchronized void clearSelection() {
            if (currentModel != null) currentModel.selectedVertices.clear();
            rebuildPointBuffers();
        }

        public synchronized void deleteSelected() {
            if (currentModel == null) return;
            currentModel.deleteSelectedVertices();
            rebuildBuffers();
        }

        public synchronized void addVertexAtCenter() {
            if (currentModel == null || currentModel.staticIffPreview || currentModel.readOnlyPreview || currentModel.preservePartTopology) return;
            currentModel.vertices.add(new float[]{0f, 0f, 0f});
            currentModel.selectedVertices.add(Integer.valueOf(
												  currentModel.vertices.size() - 1));
            rebuildBuffers();
        }

        public synchronized void moveSelectedVertices(float dx, float dy) {
            if (currentModel == null || currentModel.readOnlyPreview) return;
            float cosY = (float) Math.cos(Math.toRadians(-rotY));
            float sinY = (float) Math.sin(Math.toRadians(-rotY));
            float worldDx = dx * cosY;
            float worldDz = dx * sinY;
            float worldDy = dy;
            worldDx/=fitScale; worldDy/=fitScale; worldDz/=fitScale;
            for (Integer idx : currentModel.selectedVertices) {
                float[] v = currentModel.vertices.get(idx.intValue());
                v[0] += worldDx;
                v[1] += worldDy;
                v[2] += worldDz;
            }
            rebuildBuffers();
        }

        public synchronized void pickVertexAtScreen(float screenX, float screenY,
                                       int viewW, int viewH) {
            if (currentModel == null || currentModel.vertices.isEmpty()) return;
            float minDistSq = Float.MAX_VALUE;
            int nearestIdx = -1;
            float threshold = 60f * 60f;
            for (int i = 0; i < currentModel.vertices.size(); i++) {
                if (!"All".equals(visibleGroup)) { HashSet<Integer> group=currentModel.uvGroups.get(visibleGroup); if(group==null || !group.contains(i))continue; }
                float[] v = currentModel.vertices.get(i);
                float[] screen = worldToScreen(v[0], v[1], v[2], viewW, viewH);
                if (screen == null) continue;
                float ddx = screen[0] - screenX;
                float ddy = screen[1] - screenY;
                float distSq = ddx * ddx + ddy * ddy;
                if (distSq < minDistSq && distSq < threshold) {
                    minDistSq = distSq;
                    nearestIdx = i;
                }
            }
            if (nearestIdx >= 0) {
                Integer key = Integer.valueOf(nearestIdx);
                if (currentModel.selectedVertices.contains(key)) {
                    currentModel.selectedVertices.remove(key);
                } else {
                    currentModel.selectedVertices.add(key);
                }
            } else {
                currentModel.selectedVertices.clear();
            }
            rebuildPointBuffers();
        }

        private float[] worldToScreen(float x, float y, float z,
                                      int viewW, int viewH) {
            float[] world = { x, y, z, 1f };
            float[] view = new float[4];
            float[] clip = new float[4];
            Matrix.multiplyMV(clip, 0, mvpMatrix, 0, world, 0);
            if (clip[3] <= 1e-6f || clip[2] < -clip[3] || clip[2] > clip[3]) return null;
            float ndcX = clip[0] / clip[3];
            float ndcY = clip[1] / clip[3];
            float sx = (ndcX * 0.5f + 0.5f) * viewW;
            float sy = (1f - (ndcY * 0.5f + 0.5f)) * viewH;
            return new float[]{ sx, sy };
        }

        public synchronized void setModel(ObjModel model) {
            this.currentModel = model;
            visibleGroup = "All";
            uvBackup = null;
            centerX=centerY=centerZ=0f;fitScale=1f;
            if(model!=null && (model.staticIffPreview || model.readOnlyPreview || model.rawInterchangeCoordinates) && !model.vertices.isEmpty()) {
                float[] lo={Float.MAX_VALUE,Float.MAX_VALUE,Float.MAX_VALUE},hi={-Float.MAX_VALUE,-Float.MAX_VALUE,-Float.MAX_VALUE};
                for(float[] v:model.vertices)for(int k=0;k<3;k++){lo[k]=Math.min(lo[k],v[k]);hi[k]=Math.max(hi[k],v[k]);}
                centerX=(lo[0]+hi[0])/2;centerY=(lo[1]+hi[1])/2;centerZ=(lo[2]+hi[2])/2;
                float extent=Math.max(hi[0]-lo[0],Math.max(hi[1]-lo[1],hi[2]-lo[2]));fitScale=extent>0?2/extent:1;
            }
            rebuildBuffers();
        }

        public synchronized void setVisibleGroup(String name) {
            visibleGroup = (name == null || name.length() == 0) ? "All" : name;
            if (currentModel != null) currentModel.visibleGroup = visibleGroup;
            rebuildBuffers();
        }

        public synchronized String getVisibleGroup() { return visibleGroup; }

        public synchronized ObjModel getCurrentModel() { return currentModel; }
        public synchronized boolean hasUVs() { return currentModel != null && currentModel.hasUVs(); }
        public synchronized void beginUVEdit() {
            if (currentModel != null && currentModel.hasUVs()) uvBackup = currentModel.deepCopy();
        }
        public synchronized void uvFlipU() { if (hasUVs()) { currentModel.flipU(); rebuildBuffers(); } }
        public synchronized void uvFlipV() { if (hasUVs()) { currentModel.flipV(); rebuildBuffers(); } }
        public synchronized void uvRotate90() { if (hasUVs()) { currentModel.rotateUV90(); rebuildBuffers(); } }
        public synchronized void uvScale(float factor) { if (hasUVs()) { currentModel.scaleUV(factor); rebuildBuffers(); } }
        public synchronized void uvRotate(float degrees) { if (hasUVs()) { currentModel.rotateUV(degrees); rebuildBuffers(); } }
        public synchronized void uvTranslate(float du, float dv) { if (hasUVs()) { currentModel.translateUV(du, dv); rebuildBuffers(); } }
        public synchronized void clearUVSelection() { if (currentModel != null) currentModel.clearUVSelection(); }
        public synchronized void selectUV(int index) { if (currentModel != null) currentModel.selectUV(index); }
        public synchronized void selectAllUVs() { if (currentModel != null) currentModel.selectAllUVs(); }
        public synchronized void translateSelectedUV(float du, float dv) { if (hasUVs()) { currentModel.translateSelectedUV(du, dv); rebuildBuffers(); } }
        public synchronized void uvReset() {
            if (currentModel == null || uvBackup == null) return;
            currentModel.texcoords.clear();
            for (float[] uv : uvBackup.texcoords) currentModel.texcoords.add(uv.clone());
            rebuildBuffers();
        }

        private void rebuildBuffers() {
            vertexBuffer=texBuffer=normalBuffer=edgeBuffer=pointPositionsBuffer=selectedPointPositionsBuffer=null;
            vertexCount=edgeVertexCount=pointCount=selectedPointCount=0;hasTexCoords=false;
            if (currentModel == null) return;
            if(currentModel.faces.isEmpty()){rebuildPointBuffers();return;}
            ObjModel model = currentModel;

            List<Float> vList = new ArrayList<Float>();
            List<Float> tList = new ArrayList<Float>();
            List<Float> nList = new ArrayList<Float>();

            int vCount = model.vertices.size();
            float[] accumNormals = new float[vCount * 3];

            for (ObjModel.Face f : model.faces) {
                if (f.v.length < 3) continue;
                float[] v0 = model.vertices.get(f.v[0]);
                float[] v1 = model.vertices.get(f.v[1]);
                float[] v2 = model.vertices.get(f.v[2]);
                float[] e1 = { v1[0]-v0[0], v1[1]-v0[1], v1[2]-v0[2] };
                float[] e2 = { v2[0]-v0[0], v2[1]-v0[1], v2[2]-v0[2] };
                float nx = e1[1]*e2[2] - e1[2]*e2[1];
                float ny = e1[2]*e2[0] - e1[0]*e2[2];
                float nz = e1[0]*e2[1] - e1[1]*e2[0];
                for (int idx : f.v) {
                    accumNormals[idx*3] += nx;
                    accumNormals[idx*3+1] += ny;
                    accumNormals[idx*3+2] += nz;
                }
            }

            for (ObjModel.Face f : model.faces) {
                if (!faceBelongsToVisibleGroup(model, f)) continue;
                for (int i = 1; i < f.v.length - 1; i++) {
                    addSolidVertex(model, f.v[0],
								   (f.vt != null && f.vt.length > 0) ? f.vt[0] : -1,
								   accumNormals, vList, tList, nList);
                    addSolidVertex(model, f.v[i],
								   (f.vt != null && f.vt.length > i) ? f.vt[i] : -1,
								   accumNormals, vList, tList, nList);
                    addSolidVertex(model, f.v[i+1],
								   (f.vt != null && f.vt.length > i+1) ? f.vt[i+1] : -1,
								   accumNormals, vList, tList, nList);
                }
            }

            vertexCount = vList.size() / 3;
            vertexBuffer = makeFloatBuffer(toFloatArray(vList));

            if (!tList.isEmpty() && tList.size() / 2 == vertexCount) {
                texBuffer = makeFloatBuffer(toFloatArray(tList));
                hasTexCoords = true;
            } else {
                texBuffer = null;
                hasTexCoords = false;
            }

            float[] nArray = new float[vertexCount * 3];
            for (int i = 0; i < vertexCount; i++) {
                float x = nList.get(i*3), y = nList.get(i*3+1), z = nList.get(i*3+2);
                float len = (float) Math.sqrt(x*x + y*y + z*z);
                if (len < 1e-6f) { x = 0; y = 1; z = 0; }
                else { x /= len; y /= len; z /= len; }
                nArray[i*3] = x; nArray[i*3+1] = y; nArray[i*3+2] = z;
            }
            normalBuffer = makeFloatBuffer(nArray);
            float[] edges=new float[vertexCount*6];int ei=0;
            for(int j=0;j<vertexCount;j+=3)for(int k=0;k<3;k++)for(int endpoint=0;endpoint<2;endpoint++) {
                int at=(j+(k+endpoint)%3)*3;edges[ei++]=vList.get(at);edges[ei++]=vList.get(at+1);edges[ei++]=vList.get(at+2);
            }
            edgeBuffer=makeFloatBuffer(edges);edgeVertexCount=edges.length/3;
            rebuildPointBuffers();
        }

        private void rebuildPointBuffers() {
            if (currentModel == null) return;
            int total = currentModel.vertices.size();
            float[] allPos = new float[total * 3];
            for (int i = 0; i < total; i++) {
                float[] p = currentModel.vertices.get(i);
                allPos[i*3] = p[0]; allPos[i*3+1] = p[1]; allPos[i*3+2] = p[2];
            }
            pointPositionsBuffer = makeFloatBuffer(allPos);
            pointCount = total;
            int selCount = currentModel.selectedVertices.size();
            if (selCount > 0) {
                float[] selPos = new float[selCount * 3];
                int si = 0;
                for (Integer idx : currentModel.selectedVertices) {
                    float[] p = currentModel.vertices.get(idx.intValue());
                    selPos[si++] = p[0]; selPos[si++] = p[1]; selPos[si++] = p[2];
                }
                selectedPointPositionsBuffer = makeFloatBuffer(selPos);
                selectedPointCount = selCount;
            } else {
                selectedPointPositionsBuffer = null;
                selectedPointCount = 0;
            }
        }

        private boolean faceBelongsToVisibleGroup(ObjModel model, ObjModel.Face f) {
            if ("All".equalsIgnoreCase(visibleGroup)) return true;
            if(f.groupLabel!=null)return visibleGroup.equals(f.groupLabel);
            HashSet<Integer> group = model.uvGroups.get(visibleGroup);
            if (group == null || group.isEmpty()) return false;
            if (f.vt == null) return false;
            for (int i = 0; i < f.vt.length; i++) {
                if (group.contains(Integer.valueOf(f.vt[i]))) return true;
            }
            return false;
        }

        private void addSolidVertex(ObjModel model, int vIdx, int vtIdx,
                                    float[] accumNormals,
                                    List<Float> vList, List<Float> tList, List<Float> nList) {
            if (vIdx >= 0 && vIdx < model.vertices.size()) {
                float[] vp = model.vertices.get(vIdx);
                vList.add(vp[0]); vList.add(vp[1]); vList.add(vp[2]);
            } else {
                vList.add(0f); vList.add(0f); vList.add(0f);
            }
            if (vtIdx >= 0 && vtIdx < model.texcoords.size()) {
                float[] tp = model.texcoords.get(vtIdx);
                // Keep texture orientation in one place. The mesh UV convention
                // uses the opposite vertical origin from Android Bitmap uploads.
                // Flip V here so embedded IFF and manually loaded textures follow
                // exactly the same rendering path.
                tList.add(tp[0]);
                tList.add(model.flipTextureV ? 1.0f-tp[1] : tp[1]);
            } else {
                tList.add(0f); tList.add(0f);
            }
            float nx, ny, nz;
            if (vIdx >= 0 && vIdx < model.vertices.size()) {
                nx = accumNormals[vIdx*3]; ny = accumNormals[vIdx*3+1]; nz = accumNormals[vIdx*3+2];
            } else { nx = 0; ny = 1; nz = 0; }
            if(model.staticIffPreview && vIdx>=0 && vIdx<model.normals.size()) {
                float[] supplied=model.normals.get(vIdx);nx=supplied[0];ny=supplied[1];nz=supplied[2];
            }
            nList.add(nx); nList.add(ny); nList.add(nz);
        }

        private float[] toFloatArray(List<Float> list) {
            float[] arr = new float[list.size()];
            for (int i = 0; i < list.size(); i++) arr[i] = list.get(i);
            return arr;
        }

        private FloatBuffer makeFloatBuffer(float[] data) {
            if (data == null || data.length == 0) return null;
            ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
            bb.order(ByteOrder.nativeOrder());
            FloatBuffer fb = bb.asFloatBuffer();
            fb.put(data); fb.position(0);
            return fb;
        }

        @Override
        public synchronized void onSurfaceCreated(GL10 gl, EGLConfig config) {
            // GPU handles do not survive a lost context; retained bitmap may be reuploaded.
            textureId = -1;
            synchronized (this) { textureDirty = true; }
            GLES20.glClearColor(0.118f, 0.118f, 0.118f, 1.0f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);

            solidProgram = buildProgram(SOLID_VS, SOLID_FS);
            s_aPosition   = GLES20.glGetAttribLocation(solidProgram, "aPosition");
            s_aTexCoord   = GLES20.glGetAttribLocation(solidProgram, "aTexCoord");
            s_aNormal     = GLES20.glGetAttribLocation(solidProgram, "aNormal");
            s_uMVPMatrix  = GLES20.glGetUniformLocation(solidProgram, "uMVPMatrix");
            s_uModelMatrix= GLES20.glGetUniformLocation(solidProgram, "uModelMatrix");
            s_uUseTexture = GLES20.glGetUniformLocation(solidProgram, "uUseTexture");
            s_uTexture    = GLES20.glGetUniformLocation(solidProgram, "uTexture");

            lineProgram = buildProgram(LINE_VS, LINE_FS);
            l_aPosition   = GLES20.glGetAttribLocation(lineProgram, "aPosition");
            l_uMVPMatrix  = GLES20.glGetUniformLocation(lineProgram, "uMVPMatrix");
            l_uColor      = GLES20.glGetUniformLocation(lineProgram, "uColor");

            pointProgram = buildProgram(POINT_VS, POINT_FS);
            p_aPosition   = GLES20.glGetAttribLocation(pointProgram, "aPosition");
            p_uMVPMatrix  = GLES20.glGetUniformLocation(pointProgram, "uMVPMatrix");
            p_uColor      = GLES20.glGetUniformLocation(pointProgram, "uColor");
            p_uSize       = GLES20.glGetUniformLocation(pointProgram, "uSize");
        }

        @Override
        public synchronized void onSurfaceChanged(GL10 gl, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
            viewWidth = width; viewHeight = height;
            float ratio = (float) width / height;
            Matrix.frustumM(projMatrix, 0, -ratio, ratio, -1, 1, 1, 100);
        }

        @Override
        public synchronized void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

            Bitmap upload = null;
            boolean updateTexture;
            synchronized (this) {
                updateTexture = textureDirty;
                if (updateTexture) { upload = pendingBitmap; textureDirty = false; }
            }
            if (updateTexture) {
                if (textureId != -1) {
                    int[] old = { textureId };
                    GLES20.glDeleteTextures(1, old, 0);
                }
                textureId = -1;
                if (upload != null && !upload.isRecycled()) textureId = loadGLTexture(upload);
            }

            if (pointPositionsBuffer == null) return;

            Matrix.setLookAtM(viewMatrix, 0, 0f, 0f, 3.5f, 0f, 0f, 0f, 0f, 1f, 0f);

            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.translateM(modelMatrix, 0, panX, panY, 0f);
            Matrix.scaleM(modelMatrix, 0, scale, scale, scale);
            Matrix.rotateM(modelMatrix, 0, rotX, 1f, 0f, 0f);
            Matrix.rotateM(modelMatrix, 0, rotY, 0f, 1f, 0f);
            Matrix.scaleM(modelMatrix,0,fitScale,fitScale,fitScale);
            Matrix.translateM(modelMatrix,0,-centerX,-centerY,-centerZ);

            Matrix.multiplyMM(tempMatrix, 0, viewMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projMatrix, 0, tempMatrix, 0);

            switch (renderMode) {
                case SOLID:     drawSolid();     break;
                case WIREFRAME: drawWireframe(); break;
                case POINTS:    drawPoints();    break;
            }
        }

        private void drawSolid() {
            if(vertexBuffer==null || vertexCount==0)return;
            GLES20.glUseProgram(solidProgram);
            GLES20.glUniformMatrix4fv(s_uMVPMatrix, 1, false, mvpMatrix, 0);
            GLES20.glUniformMatrix4fv(s_uModelMatrix, 1, false, modelMatrix, 0);

            GLES20.glEnableVertexAttribArray(s_aPosition);
            GLES20.glVertexAttribPointer(s_aPosition, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer);

            GLES20.glEnableVertexAttribArray(s_aNormal);
            GLES20.glVertexAttribPointer(s_aNormal, 3, GLES20.GL_FLOAT, false, 12, normalBuffer);

            if (texBuffer != null && textureId != -1 && hasTexCoords) {
                GLES20.glEnableVertexAttribArray(s_aTexCoord);
                GLES20.glVertexAttribPointer(s_aTexCoord, 2, GLES20.GL_FLOAT, false, 8, texBuffer);
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
                GLES20.glUniform1i(s_uTexture, 0);
                GLES20.glUniform1i(s_uUseTexture, 1);
            } else {
                GLES20.glUniform1i(s_uUseTexture, 0);
            }

            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);

            GLES20.glDisableVertexAttribArray(s_aPosition);
            GLES20.glDisableVertexAttribArray(s_aNormal);
            if (texBuffer != null && hasTexCoords)
                GLES20.glDisableVertexAttribArray(s_aTexCoord);
        }

        private void drawWireframe() {
            if(edgeBuffer!=null){GLES20.glUseProgram(lineProgram);GLES20.glUniformMatrix4fv(l_uMVPMatrix,1,false,mvpMatrix,0);
                GLES20.glUniform3f(l_uColor,0.8f,0.8f,0.8f);GLES20.glEnableVertexAttribArray(l_aPosition);
                GLES20.glVertexAttribPointer(l_aPosition,3,GLES20.GL_FLOAT,false,12,edgeBuffer);
                GLES20.glDrawArrays(GLES20.GL_LINES,0,edgeVertexCount);GLES20.glDisableVertexAttribArray(l_aPosition);}
        }
        private void drawPoints() { drawPointsAll(); }

        private void drawPointsAll() {
            if (pointPositionsBuffer == null) return;

            GLES20.glUseProgram(pointProgram);
            GLES20.glUniformMatrix4fv(p_uMVPMatrix, 1, false, mvpMatrix, 0);

            GLES20.glUniform3f(p_uColor, 0.75f, 0.75f, 0.75f);
            GLES20.glUniform1f(p_uSize, 6f);
            GLES20.glEnableVertexAttribArray(p_aPosition);
            GLES20.glVertexAttribPointer(p_aPosition, 3, GLES20.GL_FLOAT, false, 12, pointPositionsBuffer);
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, pointCount);
            GLES20.glDisableVertexAttribArray(p_aPosition);

            if (selectedPointPositionsBuffer != null && selectedPointCount > 0) {
                GLES20.glUniform3f(p_uColor, 1.0f, 0.60f, 0.0f);
                GLES20.glUniform1f(p_uSize, 14f);
                GLES20.glEnableVertexAttribArray(p_aPosition);
                GLES20.glVertexAttribPointer(p_aPosition, 3, GLES20.GL_FLOAT, false, 12, selectedPointPositionsBuffer);
                GLES20.glDrawArrays(GLES20.GL_POINTS, 0, selectedPointCount);
                GLES20.glDisableVertexAttribArray(p_aPosition);
            }
        }

        private int buildProgram(String vs, String fs) {
            int v = loadShader(GLES20.GL_VERTEX_SHADER, vs);
            int f = loadShader(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram();
            GLES20.glAttachShader(p, v);
            GLES20.glAttachShader(p, f);
            GLES20.glLinkProgram(p);
            int[] linked=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,linked,0);
            if(linked[0]==0)throw new IllegalStateException("Preview shader link failed: "+GLES20.glGetProgramInfoLog(p));
            GLES20.glDeleteShader(v);GLES20.glDeleteShader(f);
            return p;
        }

        private int loadShader(int type, String code) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, code);
            GLES20.glCompileShader(s);
            int[] compiled=new int[1];GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,compiled,0);
            if(compiled[0]==0)throw new IllegalStateException("Preview shader compile failed: "+GLES20.glGetShaderInfoLog(s));
            return s;
        }

        private int loadGLTexture(Bitmap bitmap) {
            int[] tex = new int[1];
            GLES20.glGenTextures(1, tex, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0]);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
            return tex[0];
        }
    }

    // ==========================================
    // 4. OBJ IMPORT RESULT
    // ==========================================
    public static final class ObjImportResult {
        public final String errorMessage;
        public final ObjModel model;
        public final ObjFormatDetector.Report report;

        private ObjImportResult(ObjModel m, ObjFormatDetector.Report r, String e) {
            this.model = m; this.report = r; this.errorMessage = e;
        }
        public static ObjImportResult success(ObjModel m, ObjFormatDetector.Report r) {
            return new ObjImportResult(m, r, null);
        }
        public static ObjImportResult failure(ObjFormatDetector.Report r, String e) {
            return new ObjImportResult(null, r, e);
        }
        public synchronized boolean isSuccess() {
            return this.model != null && !this.model.vertices.isEmpty()
                && !this.model.faces.isEmpty();
        }
    }

    // ==========================================
    // 5. OBJ FORMAT DETECTOR
    // ==========================================
    public static final class ObjFormatDetector {
        public enum Kind { WAVEFRONT_TEXT, UNKNOWN_BINARY, UNKNOWN_TEXT, EMPTY }
        public static final class Report {
            public final int asciiRatio;
            public final Kind kind;
            public final String note;
            public final long size;
            Report(Kind k, long s, int a, String n) {
                this.kind = k; this.size = s; this.asciiRatio = a; this.note = n;
            }
        }
        private ObjFormatDetector() {}
        public static Report inspect(InputStream in) throws IOException {
            if(in==null)throw new IOException("Null OBJ input");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                if((long)out.size()+n>MeshInterchange.MAX_BYTES)throw new IOException("OBJ byte limit");
                out.write(buf, 0, n);
            }
            byte[] b = out.toByteArray();
            if (b.length == 0) return new Report(Kind.EMPTY, 0L, 100, "Empty file.");
            int printable = 0;
            for (byte x : b) {
                int u = x & 255;
                if (u == 9 || u == 10 || u == 13 || (u >= 32 && u <= 126)) printable++;
            }
            int ratio = (int) Math.round((printable * 100.0d) / b.length);
            String text = new String(b, StandardCharsets.UTF_8);
            BufferedReader r = new BufferedReader(new StringReader(text));
            boolean looks = false;
            String line;
            while ((line = r.readLine()) != null) {
                String s = line.trim();
                if (s.matches("^(v|vt|vn|f)\\s+.*")) {
                    looks = true; break;
                }
            }
            if (looks) return new Report(Kind.WAVEFRONT_TEXT, b.length, ratio, "Wavefront OBJ records detected.");
            if (ratio < 70) return new Report(Kind.UNKNOWN_BINARY, b.length, ratio, "Binary/non-text mesh detected.");
            return new Report(Kind.UNKNOWN_TEXT, b.length, ratio, "Text file, no standard OBJ records.");
        }
    }

    // ==========================================
    // 6. OBJ PARSER
    // ==========================================
    public static final class ObjParser {
        private ObjParser() {}
        public static ObjImportResult importAny(InputStream input) throws IOException {
            byte[] data = readAll(input);
            ObjFormatDetector.Report report = ObjFormatDetector.inspect(new ByteArrayInputStream(data));
            if (report.kind != ObjFormatDetector.Kind.WAVEFRONT_TEXT) {
                return ObjImportResult.failure(report, report.note);
            }
            try {
                ObjModel model = ObjGeometryReader.parse(data);
                if (!model.vertices.isEmpty() && !model.faces.isEmpty()) {
                    return ObjImportResult.success(model, report);
                }
                return ObjImportResult.failure(report, "No mesh produced.");
            } catch (Exception e) {
                return ObjImportResult.failure(report, "Parse error: " + e.getMessage());
            }
        }

        private static ObjModel parseWavefront(InputStream input) throws IOException {
            ObjModel model = new ObjModel();
            BufferedReader br = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split("\\s+");
                if (parts.length == 0) continue;
                switch (parts[0]) {
                    case "v":
                        if (parts.length >= 4) {
                            model.vertices.add(new float[]{
												   Float.parseFloat(parts[1]),
												   Float.parseFloat(parts[2]),
												   Float.parseFloat(parts[3])
											   });
                        }
                        break;
                    case "vt":
                        if (parts.length >= 3) {
                            model.texcoords.add(new float[]{
													Float.parseFloat(parts[1]),
													Float.parseFloat(parts[2])
												});
                        }
                        break;
                    case "vn":
                        if (parts.length >= 4) {
                            model.normals.add(new float[]{
												  Float.parseFloat(parts[1]),
												  Float.parseFloat(parts[2]),
												  Float.parseFloat(parts[3])
											  });
                        }
                        break;
                    case "f":
                        if (parts.length >= 4) {
                            int count = parts.length - 1;
                            int[] v = new int[count];
                            int[] vt = new int[count];
                            int[] vn = new int[count];
                            for (int i = 0; i < count; i++) {
                                String[] ref = parts[i + 1].split("/", -1);
                                v[i] = resolveIndex(ref[0], model.vertices.size());
                                vt[i] = (ref.length > 1 && !ref[1].isEmpty())
                                    ? resolveIndex(ref[1], model.texcoords.size()) : -1;
                                vn[i] = (ref.length > 2 && !ref[2].isEmpty())
                                    ? resolveIndex(ref[2], model.normals.size()) : -1;
                            }
                            model.faces.add(new ObjModel.Face(v, vt, vn));
                        }
                        break;
                }
            }
            return model;
        }

        private static int resolveIndex(String raw, int size) {
            if (raw == null || raw.isEmpty()) return -1;
            int n = Integer.parseInt(raw);
            return n > 0 ? n - 1 : (n < 0 ? size + n : -1);
        }

        private static byte[] readAll(InputStream in) throws IOException {
            if(in==null)throw new IOException("Null OBJ input");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                if((long)out.size()+n>MeshInterchange.MAX_BYTES)throw new IOException("OBJ byte limit");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }
}
