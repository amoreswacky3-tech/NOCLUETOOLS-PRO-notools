"""Pure-Python PNG reader and writer (stdlib only).

Reads the PNG variants the tool actually meets in the wild (8/16-bit
grayscale, RGB, palette, gray+alpha and RGBA, all filter types, no
interlacing) and writes 8-bit RGBA PNGs.  Replaces Pillow on platforms where
PIL's native ``_imaging`` module is unavailable (Android), so the engine has
no native dependencies at all.
"""
from __future__ import annotations
import os
import struct
import zlib
from pathlib import Path
SIGNATURE = b'\x89PNG\r\n\x1a\n'
COLOR_GRAY = 0
COLOR_RGB = 2
COLOR_PALETTE = 3
COLOR_GRAY_ALPHA = 4
COLOR_RGBA = 6
_SAMPLE_WIDTH = {COLOR_GRAY: 1, COLOR_RGB: 3, COLOR_PALETTE: 1, COLOR_GRAY_ALPHA: 2, COLOR_RGBA: 4}

class PngError(ValueError):
    pass

def _chunks(data: bytes):
    position = 8
    while position < len(data):
        if position + 8 > len(data):
            raise PngError('truncated PNG chunk header')
        length = struct.unpack_from('>I', data, position)[0]
        chunk_type = data[position + 4:position + 8]
        start = position + 8
        end = start + length
        if end + 4 > len(data):
            raise PngError(f"truncated PNG {chunk_type.decode('ascii', 'replace')} chunk")
        payload = data[start:end]
        stored_crc = struct.unpack_from('>I', data, end)[0]
        computed_crc = zlib.crc32(payload, zlib.crc32(chunk_type)) & 4294967295
        if stored_crc != computed_crc:
            raise PngError(f"PNG {chunk_type.decode('ascii', 'replace')} chunk CRC mismatch")
        yield (chunk_type, payload)
        position = end + 4

def _expand_bits(samples: bytes, bit_depth: int, count: int) -> list[int]:
    """Expand packed samples (1/2/4 bits) into a list of ints."""
    if bit_depth == 8:
        return list(samples)
    if bit_depth == 16:
        return [samples[i] for i in range(0, len(samples), 2)]
    values = []
    mask = (1 << bit_depth) - 1
    for byte in samples:
        for shift in range(8 - bit_depth, -1, -bit_depth):
            values.append(byte >> shift & mask)
    return values[:count]

def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c

def read_png_rgba(data: bytes) -> tuple[int, int, bytes]:
    """Decode a PNG into ``(width, height, rgba_bytes)`` with 8-bit RGBA."""
    if not data.startswith(SIGNATURE):
        raise PngError('not a PNG file (bad signature)')
    width = height = bit_depth = color_type = None
    palette = []
    transparency = None
    idat = bytearray()
    saw_ihdr = False
    saw_iend = False
    for chunk_type, payload in _chunks(data):
        if chunk_type == b'IHDR':
            if len(payload) < 13:
                raise PngError('truncated IHDR')
            saw_ihdr = True
            width, height, bit_depth, color_type = struct.unpack_from('>IIBB', payload, 0)
            compression, filter_method, interlace = (payload[10], payload[11], payload[12])
            if compression != 0:
                raise PngError(f'unsupported PNG compression method {compression}')
            if filter_method != 0:
                raise PngError(f'unsupported PNG filter method {filter_method}')
            if interlace != 0:
                raise PngError('interlaced PNGs are not supported')
            if color_type not in (COLOR_GRAY, COLOR_RGB, COLOR_PALETTE, COLOR_GRAY_ALPHA, COLOR_RGBA):
                raise PngError(f'unsupported PNG color type {color_type}')
            if bit_depth not in (1, 2, 4, 8, 16):
                raise PngError(f'unsupported PNG bit depth {bit_depth}')
            if bit_depth == 16 and color_type == COLOR_PALETTE:
                raise PngError('palette PNGs cannot use 16-bit depth')
            if width <= 0 or height <= 0:
                raise PngError('invalid PNG dimensions')
            continue
        if chunk_type == b'PLTE':
            if len(payload) % 3:
                raise PngError('invalid palette length')
            palette = [payload[i:i + 3] for i in range(0, len(payload), 3)]
            continue
        if chunk_type == b'tRNS':
            transparency = payload
            continue
        if chunk_type == b'IDAT':
            idat.extend(payload)
            continue
        if chunk_type == b'IEND':
            saw_iend = True
            break
    if not saw_ihdr:
        raise PngError('PNG has no IHDR chunk')
    if not saw_iend:
        raise PngError('PNG has no IEND chunk')
    if not idat:
        raise PngError('PNG has no image data')
    channels = _SAMPLE_WIDTH[color_type]
    row_bytes = (width * channels * bit_depth + 7) // 8
    try:
        raw = zlib.decompress(bytes(idat))
    except zlib.error as error:
        raise PngError(f'invalid PNG compressed data: {error}') from error
    expected = (row_bytes + 1) * height
    if len(raw) != expected:
        raise PngError(f'PNG decompressed data is {len(raw)} bytes, expected {expected}')
    lines = []
    position = 0
    previous = bytearray(row_bytes)
    for _row in range(height):
        filter_type = raw[position]
        position += 1
        line = bytearray(raw[position:position + row_bytes])
        position += row_bytes
        if filter_type == 0:
            pass
        elif filter_type == 1:
            for i in range(channels * bit_depth // 8, row_bytes):
                line[i] = line[i] + line[i - channels * bit_depth // 8] & 255
        elif filter_type == 2:
            for i in range(row_bytes):
                line[i] = line[i] + previous[i] & 255
        elif filter_type == 3:
            bpp = channels * bit_depth // 8
            for i in range(row_bytes):
                left = line[i - bpp] if i >= bpp else 0
                line[i] = line[i] + (left + previous[i] >> 1) & 255
        elif filter_type == 4:
            bpp = channels * bit_depth // 8
            for i in range(row_bytes):
                left = line[i - bpp] if i >= bpp else 0
                line[i] = line[i] + _paeth(left, previous[i], previous[i - bpp] if i >= bpp else 0) & 255
        else:
            raise PngError(f'invalid PNG filter type {filter_type}')
        lines.append(bytes(line))
        previous = line
    output = bytearray(width * height * 4)
    for y, line in enumerate(lines):
        row = output[y * width * 4:(y + 1) * width * 4]
        if color_type == COLOR_RGBA and bit_depth == 8:
            row[:] = line
        else:
            if color_type in (COLOR_GRAY, COLOR_GRAY_ALPHA, COLOR_RGBA) and bit_depth == 8:
                samples = list(line)
            elif bit_depth == 16:
                samples = _expand_bits(line, 16, width * channels)
            else:
                samples = _expand_bits(line, bit_depth, width * channels)
            offset = 0
            for x in range(width):
                if color_type == COLOR_GRAY:
                    value = samples[x]
                    row[offset:offset + 4] = bytes((value, value, value, 255))
                elif color_type == COLOR_GRAY_ALPHA:
                    value = samples[x * 2]
                    alpha = samples[x * 2 + 1]
                    row[offset:offset + 4] = bytes((value, value, value, alpha))
                elif color_type == COLOR_RGB:
                    r, g, b = samples[x * 3:x * 3 + 3]
                    row[offset:offset + 4] = bytes((r, g, b, 255))
                elif color_type == COLOR_PALETTE:
                    index = samples[x]
                    if index >= len(palette):
                        raise PngError(f'palette index {index} out of range')
                    r, g, b = palette[index]
                    alpha = transparency[index] if transparency is not None and index < len(transparency) else 255
                    row[offset:offset + 4] = bytes((r, g, b, alpha))
                else:
                    r, g, b, a = samples[x * 4:x * 4 + 4]
                    row[offset:offset + 4] = bytes((r, g, b, a))
                offset += 4
        output[y * width * 4:(y + 1) * width * 4] = row
    return (width, height, bytes(output))

def png_dimensions(data: bytes) -> tuple[int, int]:
    if not data.startswith(SIGNATURE):
        raise PngError('not a PNG file (bad signature)')
    if len(data) < 24:
        raise PngError('truncated PNG header')
    [width, height] = struct.unpack_from('>II', data, 16)
    return (width, height)

def _chunk(chunk_type: bytes, payload: bytes) -> bytes:
    return struct.pack('>I', len(payload)) + chunk_type + payload + struct.pack('>I', zlib.crc32(payload, zlib.crc32(chunk_type)) & 4294967295)

def write_png_rgba(width: int, height: int, rgba: bytes, *, level: int=6) -> bytes:
    """Encode RGBA8 scanline bytes as a PNG (8-bit RGBA, no filtering)."""
    if len(rgba) != width * height * 4:
        raise PngError(f'RGBA buffer is {len(rgba)} bytes, expected {width * height * 4}')
    ihdr = struct.pack('>IIBBBBB', width, height, 8, COLOR_RGBA, 0, 0, 0)
    raw = bytearray((width * 4 + 1) * height)
    position = 0
    for y in range(height):
        raw[position] = 0
        raw[position + 1:position + 1 + width * 4] = rgba[y * width * 4:(y + 1) * width * 4]
        position += width * 4 + 1
    idat = zlib.compress(bytes(raw), level)
    return SIGNATURE + _chunk(b'IHDR', ihdr) + _chunk(b'IDAT', idat) + _chunk(b'IEND', b'')

def write_png_rgba_to_file(path: Path | str, width: int, height: int, rgba: bytes, *, level: int=6) -> int:
    """Encode RGBA8 scanlines straight to ``path`` as a PNG, streaming.

    Unlike :func:`write_png_rgba` this never materialises the filtered
    scanline buffer or the final PNG bytes: each row is fed to the zlib
    compressor and the compressed output is emitted as PNG IDAT chunks as it
    is produced (the PNG spec allows the compressed stream to span several
    IDAT chunks).  The peak memory for a 4096x4096 texture stays around the
    RGBA source buffer instead of roughly tripling it, which matters on
    low-memory Android devices.  The file is written to a ``.partial``
    sibling and atomically renamed, and its byte count is returned so the
    caller can verify the output.
    """
    if len(rgba) != width * height * 4:
        raise PngError(f'RGBA buffer is {len(rgba)} bytes, expected {width * height * 4}')
    ihdr = struct.pack('>IIBBBBB', width, height, 8, COLOR_RGBA, 0, 0, 0)
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + '.partial')
    compressor = zlib.compressobj(level, zlib.DEFLATED, 15, 8, zlib.Z_DEFAULT_STRATEGY)
    try:
        with temporary.open('wb') as output:
            output.write(SIGNATURE)
            output.write(_chunk(b'IHDR', ihdr))
            position = 0
            for _y in range(height):
                row = rgba[position:position + width * 4]
                position += width * 4
                segment = compressor.compress(b'\x00' + row)
                if segment:
                    output.write(_chunk(b'IDAT', segment))
            tail = compressor.flush()
            if tail:
                output.write(_chunk(b'IDAT', tail))
            output.write(_chunk(b'IEND', b''))
        size = temporary.stat().st_size
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return size
