import re

with open('__init__.py', 'r') as f:
    content = f.read()

old_func = 'def preview_png(session_id: str, file_index: int, texture_number: int) -> bytes:\n    """Return PNG bytes for one texture (for in-app preview).\n\n    When a texture is an unresolved reference (status == "reference" and\n    payload_bytes is None), a diagnostic placeholder PNG is returned instead\n    of raising, so the UI can show meaningful information rather than crashing.\n    """\n    session = _session(session_id)\n    opened = session["opened"][file_index]\n    texture = _texture_at(opened, int(texture_number))\n    if texture.status == "reference" and texture.payload_bytes is None:\n        return _diagnostic_placeholder_png(texture)\n    return core.texture_png(opened, texture)'
new_func = 'def preview_png(session_id: str, file_index: int, texture_number: int) -> bytes:\n    """Return PNG bytes for one texture (for in-app preview).\n\n    When a texture is an unresolved reference (status == "reference" and\n    payload_bytes is None), a diagnostic placeholder PNG is returned instead\n    of raising, so the UI can show meaningful information rather than crashing.\n    """\n    session = _session(session_id)\n    opened = session["opened"][file_index]\n    texture = _texture_at(opened, int(texture_number))\n    import sys\n    print(f"DEBUG preview_png: texture #{texture.number}, status={texture.status}, payload_bytes={texture.payload_bytes is not None}, format={texture.format_id}", file=sys.stderr)\n    if texture.status == "reference" and texture.payload_bytes is None:\n        print(f"DEBUG: Returning placeholder PNG for reference texture", file=sys.stderr)\n        return _diagnostic_placeholder_png(texture)\n    print(f"DEBUG: Calling texture_png for texture", file=sys.stderr)\n    return core.texture_png(opened, texture)'
if old_func in content:
    content = content.replace(old_func, new_func)
    with open('__init__.py', 'w') as f:
        f.write(content)
    print('Patched preview_png with diagnostic logging')
else:
    print('ERROR: Could not find preview_png function')
    exit(1)
