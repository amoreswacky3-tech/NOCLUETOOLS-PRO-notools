"""Headless NBA 2K Android IFF engine (pure stdlib).

A faithful port of the byte-level IFF logic from the desktop tool
(``OBB TOOL/iff_viewer.py``) with the PIL / etcpak / texture2ddecoder native
modules replaced by the pure-Python codecs in this package.  Every texture
location, allocation, mip-chain and wrapper-rebuild rule is identical to the
desktop tool so edits behave the same on Android.

NBA 2K16 IFFs are also supported: they share the 2K compressed wrapper and
DRAM/VRAM block layout with 2K20, but store texture headers as compact
0xC0-byte records (see :func:`scan_headers_2k16`) instead of the 2K20
0xF0-byte VCTEXTURE headers.

Only texture handling is included; GPU buffer / mesh / resource browsing and
the folder catalog are desktop concerns and are not ported.
"""

from __future__ import annotations
import bisect
import dataclasses
import json
import os
import re
import struct
import zlib
from pathlib import Path
from . import etc2
from . import pngio

TYPE_COMPRESSED = b"\x94\xef;\xff"
TYPE_ZLIB = b"ZLIB"
HEADER_SIZE = 240
FORMATS = (1, 2, 4, 6, 7, 15, 16)
FORMAT_RGBA8888 = 1
FORMAT_ETC1_RGB = 6
FORMAT_RG8 = 7
FORMAT_EAC_RG11 = 7
FORMAT_RGBA8888_RAW = 17

FORMAT_NAMES = {
    FORMAT_RGBA8888: "RGBA8888",
    2: "RGB565",
    4: "RGBA4444",
    FORMAT_ETC1_RGB: "ETC1 RGB",
    FORMAT_RG8: "RG8 Normal",
    15: "ETC2 RGB",
    16: "ETC2 RGBA8/EAC",
    FORMAT_RGBA8888_RAW: "RGBA8888",
}

DIMENSIONS = (4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384)
_2K16_SIGNATURE = b"/\x81\x00\x00/\x81\x00\x00\x01&\x00\x00\x01&\x00\x00\x01&\x00\x00"
_2K16_ANCHOR = b"\x01&\x00\x00\x01&\x00\x00\x01&\x00\x00"
_2K16_HEADER_SIZE = 192
_2K16_NOISE_PILE_UP = 4
FACE_TEXTURE_HASHES = frozenset({1716930793, 2633457945, 3104755599, 34351951, 562391268})
CHARACTER_SHADER_RE = re.compile(b"characters/(?:eye|skin_2k10|hairshader|basic|scalp|brow)\\.fx", re.IGNORECASE)


def scene_descriptor_role(format_id: int, width: int, height: int) -> str:
    """Semantic role for a scene-graph texture descriptor.

    Cyberface scenes describe their textures with per-record format/dimension
    combinations that map cleanly onto the roles the reference tool shows:
    ETC2-RGBA8 records are the Face Diffuse, small (<=128) ETC-RGB records
    the Detail Mask, 512+ atlases the Shared Texture, and everything else a
    Material/Normal-style map.  Verified against PNG0393.IFF, where the four
    descriptors decode to exactly Face Diffuse / Material Map / map /
    Detail Mask under this rule.

    When multiple same-size ETC2-RGB textures appear, the caller refines
    roles via position-based assignment (see _scene_reference_records).
    """
    if width >= 512 or height >= 512:
        return "Shared Texture"

    if format_id == 16:
        return "Face Diffuse"

    if width <= 128 and height <= 128:
        return "Detail Mask"
    return "Material Map"


FACE_ROLE_LABELS = {
    34351951: "Shared Texture",
    562391268: "Face Diffuse",
    1716930793: "Face Diffuse",
    3104755599: "Face Diffuse",
    2633457945: "Face Diffuse",
}

FACE_ROLE_SEQUENCE = (
    "Shared Texture",
    "Face Diffuse",
    "Material Map",
    "Normal Map",
    "Detail Mask",
)


def is_png_scene_name(display_name: str) -> bool:
    name = (display_name or "").upper().replace(".IFF", "").strip()
    return name.startswith("PNG") and len(name) >= 4 and any((c.isdigit() for c in name[3:]))


UNIFORM_SAMPLER_RE = re.compile(b"uniform sampler2D (?:LogoColorSampler|NameColorSampler|NumberColorSampler|MaterialColorSampler|MaterialNormalSampler)", re.IGNORECASE)
UNIFORM_MIN_SAMPLERS = 3
SHADER_BANK_MIN_FX_PATHS = 40
SHADER_BANK_RE = re.compile(b"shaders/\\w+/\\w+\\.fx", re.IGNORECASE)
OGG_SIGNATURE = b"OggS"
DDS_SIGNATURES = (b"DDS ", b"DXT1", b"DXT3", b"DXT5")
UNIFORM_TEXTURE_HASHES = frozenset({1040589046, 2304541342, 4063447360})

ASSET_CATEGORY_LABELS = {
    "cyberface": "Cyberface",
    "uniform": "Jersey / Uniform",
    "logo": "Logo / Branding",
    "shader": "Shader",
    "texture_bank": "Texture Bank",
    "audio": "Audio",
    "court": "Court / Floor",
    "data": "Data",
    "mined": "Content-Mined Name",
    "unknown": "Unknown / Potential Asset",
}

@dataclasses.dataclass
class AssetClass:
    category: str
    subcategory: str
    confidence: str
    label: str
    evidence: tuple[str, ...] = ()

    def as_dict(self) -> dict:
        return {
            "category": self.category,
            "category_label": ASSET_CATEGORY_LABELS.get(self.category, self.category),
            "subcategory": self.subcategory,
            "confidence": self.confidence,
            "label": self.label,
            "evidence": list(self.evidence),
        }


def classify_asset(data: bytes, *, display_name: str="", textures: list[TextureRecord] | None=None) -> AssetClass:
    """Content-based asset detection for one decompressed IFF.

    Both NBA 2K16 and 2K20 Android OBBs hash-index every resource name, so
    detection combines readable name patterns (``PNG####``, ``UH###``,
    ``UA###``, ``LOGO###``, ``S###``) with the IFF's actual contents:
    character shaders / face texture hashes (cyberface), the uniform sampler
    set (jersey), environment shaders (shader banks), OggS (audio), texture
    headers (banks) and fall back to ``unknown`` so nothing is ever dropped.

    The two games share every signature below -- only the name sets and some
    header layouts differ (handled by the game-aware texture scanners), so a
    single detector covers both 2K16 and 2K20.
    """
    evidence = []
    name = (display_name or "").upper()
    name_category = None
    if name.startswith("PNG") and len(name) >= 7 and name[3:7].isdigit():
        name_category = ("cyberface", "face_scene", "high", "Cyberface model / scene")
    elif name.startswith("UH") and name[2:5].isdigit():
        name_category = ("uniform", "home", "high", "Jersey / Uniform (Home)")
    elif name.startswith("UA") and name[2:5].isdigit():
        name_category = ("uniform", "away", "high", "Jersey / Uniform (Away)")
    elif name.startswith("LOGO") and name[4:7].isdigit():
        name_category = ("logo", "team_logo", "high", "Logo / Branding")
    elif name.startswith("S") and name[1:4].isdigit():
        name_category = ("shader", "shader_bank", "high", "Shader bank")
    elif name.startswith("F") and len(name) >= 4 and name[1:4].isdigit():
        name_category = ("court", "floor", "high", "Court / Floor")
    elif name.startswith("TEAM") or name.startswith("FACE") or name.startswith("TATTOO"):
        name_category = ("data", "data_table", "medium", "Game data table")
    cyber = classify_cyberface(data, display_name=display_name, textures=textures)
    if cyber["kind"] != "none":
        if name_category and name_category[0] == "cyberface":
            return AssetClass(*name_category, evidence=tuple(cyber["shaders"][:4]))

        if cyber["kind"] == "face_scene":
            return AssetClass("cyberface", "face_scene", "high", "Cyberface model / scene", evidence=tuple(cyber["shaders"][:4]))

        if cyber["kind"] == "face_texture_bank":
            return AssetClass("cyberface", "face_texture_bank", "high", "Cyberface texture bank", evidence=tuple(cyber["face_texture_hashes"][:4]))
        return AssetClass("cyberface", "character_iff", "medium", "Character rendering IFF", evidence=tuple(cyber["shaders"][:4]))
    sampler_names = {match.decode("ascii", "ignore") for match in UNIFORM_SAMPLER_RE.findall(data)}
    if len(sampler_names) >= UNIFORM_MIN_SAMPLERS or (sampler_names and name_category and (name_category[0] == "uniform")):
        if name_category and name_category[0] == "uniform":
            return AssetClass(*name_category, evidence=tuple(sorted(sampler_names)))
        return AssetClass("uniform", "uniform_iff", "high", "Jersey / Uniform container", evidence=tuple(sorted(sampler_names)))

    if OGG_SIGNATURE in data[:65536]:
        return AssetClass("audio", "audio_stream", "high", "Audio stream", evidence=("OggS audio signature",))

    if name_category and name_category[0] == "shader":
        return AssetClass(*name_category, evidence=("S###.IFF name pattern",))

    if len(set(SHADER_BANK_RE.findall(data[:262144]))) >= SHADER_BANK_MIN_FX_PATHS:
        return AssetClass("shader", "shader_bank", "medium", "Shader bank", evidence=("dominated by compiled shader source",))
    resolved_textures = sum(1 for texture in textures if texture.payload_offset is not None) if textures is not None else 0
    header_count = len(textures) if textures is not None else 0
    if header_count >= 2 or resolved_textures >= 2:
        return AssetClass("texture_bank", "texture_bank", "medium", "Texture bank", evidence=(f"""{header_count} texture header(s), {resolved_textures} resolved""",))
    hashes = {t.texture_hash for t in textures} if textures is not None else set()
    if hashes & UNIFORM_TEXTURE_HASHES:
        return AssetClass("texture_bank", "uniform_texture_bank", "medium", "Uniform texture bank", evidence=("uniform atlas hashes present",))

    if any((sig in data[:262144] for sig in DDS_SIGNATURES)):
        return AssetClass("texture_bank", "texture_bank", "low", "Possible texture data", evidence=("DDS-style marker present",))

    if name_category:
        return AssetClass(*name_category)
    return AssetClass("unknown", "potential_asset", "low", "Unknown / Potential asset", evidence=("no recognizable content signature",))


UNIFORM_STREAM_BLOCK_SIZE = 873828
UNIFORM_NORMAL_STREAM_SIZE = 699052
UNIFORM_NORMAL_ENCODED_SIZE = 699050
UNIFORM_COLOR_STREAM_OFFSET = 742316
UNIFORM_COLOR_STREAM_SIZE = 131072
RAW_RGBA8888_PROBE_OFFSET = 662128
RAW_RGBA8888_PROBE_WIDTH = 256
RAW_RGBA8888_PROBE_HEIGHT = 256
RAW_RGBA8888_PROBE_SIZE = RAW_RGBA8888_PROBE_WIDTH * RAW_RGBA8888_PROBE_HEIGHT * 4
UNIFORM_IFF_NAME = re.compile("^(?:UH|UA|UX|UHX|UAX|UAY|R\\d+[HA]?)\\d*(?:[_\\-\\.][A-Za-z0-9]+)*\\.(?:IFF|iff)(?:\\..*)?$|.*(?:jersey|uniform).*\\.(?:IFF|iff)(?:\\..*)?$", re.IGNORECASE)
KNOWN_UNIFORM_HASHES = frozenset({1040589046, 2304541342, 4063447360, 550591167})

VERIFIED_END_ANCHORED_TEXTURE_BANKS = (
    frozenset({1449569225, 349929376, 3642177626}),
    frozenset({2212858739, 3980761662, 4092325077, 451730121}),
    frozenset({2904542338, 3135206897, 3453502823, 3626955223}),
    frozenset({2157658999, 2911463591, 59002628, 637887569}),
    frozenset({2135342275, 2544015930, 3014800924, 3961607141}),
    frozenset({1050295856, 2746858102, 3541799831, 59002628}),
)

LINKED_RUNTIME_TEXTURE_HASHES = {3153461252}
@dataclasses.dataclass
class TextureRecord:
    number: int
    header_offset: int
    texture_hash: int
    format_id: int
    width: int
    height: int
    tagged_offset: int
    payload_size: int
    payload_offset: int | None
    location: str
    allocation_size: int = 0
    encoded_size: int = 0
    uses_mip_chain: bool = False
    error: str | None = None
    label: str = ""
    has_header: bool = True
    status: str = "valid"
    mip_count: int = 1
    payload_bytes: bytes | None = None
    role: str = ""
    detected: str | None = None
    confidence: str | None = None
    alternative_candidates: list[str] = dataclasses.field(default_factory=list)

    def as_dict(self) -> dict:
        result = {
            "number": self.number,
            "header_offset": f"0x{self.header_offset:X}" if self.has_header else None,
            "texture_hash": f"0x{self.texture_hash:08X}",
            "format_id": self.format_id,
            "format": FORMAT_NAMES.get(self.format_id, f"Unknown ({self.format_id})"),
            "width": self.width,
            "height": self.height,
            "tagged_offset": f"0x{self.tagged_offset:X}",
            "payload_size": self.payload_size,
            "payload_offset": f"0x{self.payload_offset:X}" if self.payload_offset is not None else None,
            "location": self.location,
            "allocation_size": self.allocation_size,
            "encoded_size": self.encoded_size,
            "uses_mip_chain": self.uses_mip_chain,
            "error": self.error,
            "label": self.label,
            "has_header": self.has_header,
            "status": self.status,
            "mip_count": self.mip_count,
            "role": self.role,
            "expected_size": self.payload_size,
            "resolution_status": "resolved" if self.payload_bytes is not None else self.status,
        }
        if self.detected is not None:
            result["detected_format"] = self.detected
            result["detected_confidence"] = self.confidence
        return result
@dataclasses.dataclass
class OpenedIff:
    path: Path
    source_size: int
    wrapper: str
    source_raw: bytes
    original_data: bytes
    data: bytearray
    block_sizes: list[int]
    boundary_source: str
    textures: list[TextureRecord]
    wrapper_info: WrapperInfo | None = None


def payload_size(format_id: int, width: int, height: int) -> int:
    if format_id in (FORMAT_RGBA8888, FORMAT_RGBA8888_RAW):
        return width * height * 4

    if format_id in (2, 4, FORMAT_RG8):
        return width * height * 2
    blocks_wide = max(1, (width + 3) // 4)
    blocks_high = max(1, (height + 3) // 4)
    if format_id in (FORMAT_ETC1_RGB, 15):
        return blocks_wide * blocks_high * 8

    if format_id == 16:
        return blocks_wide * blocks_high * 16

    if format_id == 1:
        return width * height
    raise ValueError(f"""unsupported texture format {format_id}""")


def mip_chain_size(format_id: int, width: int, height: int) -> int:
    total = 0
    while True:
        total += payload_size(format_id, width, height)
        if width == 1 and height == 1:
            return total
        width = max(1, width // 2)
        height = max(1, height // 2)


def mip_level_count(width: int, height: int) -> int:
    """Number of mip levels from the base dimensions down to 1x1."""
    count = 1
    while width > 1 or height > 1:
        count += 1
        width = max(1, width // 2)
        height = max(1, height // 2)
    return count


@dataclasses.dataclass
class WrapperBlock:
    position: int
    unpacked_size: int
    stored_size: int
    declared_stored_size: int
    flags: int
    unpacked_offset: int
@dataclasses.dataclass
class WrapperInfo:
    first_offset: int
    compressed_wrapper: bool
    blocks: list[WrapperBlock]


def decompress_wrapper(raw: bytes) -> tuple[bytes, list[int], str, WrapperInfo | None]:
    if raw[:4] == TYPE_COMPRESSED:
        if len(raw) < 8:
            raise ValueError("truncated 2K compressed IFF wrapper")
        position = struct.unpack_from("<I", raw, 4)[0]
        if position < 8 or position >= len(raw):
            raise ValueError(f"""invalid compressed payload offset 0x{position:X}""")
        wrapper = "2K compressed IFF"
        compressed_wrapper = True
    elif raw[:4] == TYPE_ZLIB:
        position = 0
        wrapper = "2K ZLIB stream"
        compressed_wrapper = False
    else:
        return (raw, [len(raw)], "decompressed IFF", None)
    chunks = []
    blocks = []
    first_offset = position
    unpacked_offset = 0
    view = memoryview(raw)
    while position + 16 <= len(raw) and raw[position:position + 4] == TYPE_ZLIB:
        unpacked_size, declared_stored_size, _flags = struct.unpack_from(">III", raw, position + 4)
        if unpacked_size <= 0 or declared_stored_size <= 0:
            raise ValueError(f"""invalid ZLIB block at 0x{position:X}""")
        payload_start = position + 16
        window = view[payload_start:payload_start + declared_stored_size]
        decoder = zlib.decompressobj()
        try:
            chunk = decoder.decompress(window)
            fed = len(window)
            if not decoder.eof:
                tail = view[payload_start + declared_stored_size:]
                chunk += decoder.decompress(tail)
                fed += len(tail)
            chunk += decoder.flush()
        except zlib.error as error:
            raise ValueError(f"""invalid ZLIB stream at 0x{position:X}: {error}""") from error
        if not decoder.eof:
            raise ValueError(f"""truncated ZLIB stream at 0x{position:X}""")
        consumed_payload = fed - len(decoder.unused_data)
        if declared_stored_size >= 16 and consumed_payload <= declared_stored_size - 16:
            stored_size = declared_stored_size

        elif consumed_payload <= declared_stored_size:
            stored_size = 16 + declared_stored_size
        else:
            stored_size = 16 + consumed_payload

        if position + stored_size > len(raw):
            raise ValueError(f"""invalid ZLIB block span at 0x{position:X}""")

        if len(chunk) != unpacked_size:
            raise ValueError(f"""ZLIB block at 0x{position:X} decoded to {len(chunk)} bytes, expected {unpacked_size}""")
        chunks.append(chunk)
        blocks.append(WrapperBlock(position=position, unpacked_size=unpacked_size, stored_size=stored_size, declared_stored_size=declared_stored_size, flags=_flags, unpacked_offset=unpacked_offset))
        unpacked_offset += unpacked_size
        position += stored_size


    if not chunks:
        raise ValueError("compressed IFF contains no readable ZLIB blocks")
    return (b"".join(chunks), [len(chunk) for chunk in chunks], wrapper, WrapperInfo(first_offset, compressed_wrapper, blocks))


def _valid_vctexture_descriptor(data: bytes, offset: int) -> int | None:
    'Validate one candidate VCTEXTURE descriptor; return its format id.\n\n    Accepts the standard record (type marker 0x20 at +0x28) plus the scene-\n    graph variant whose marker is 0x28 or 0 with the format id repeated at\n    +0x2C.  Returns None when any gate fails.\n    '
    format_id = struct.unpack_from("<I", data, offset + 16)[0]
    if format_id not in FORMATS:
        return None
    if struct.unpack_from("<I", data, offset + 20)[0] != format_id:
        return None
    type_marker = struct.unpack_from("<I", data, offset + 40)[0]
    if type_marker != 32:
        if type_marker not in (40, 0):
            return None
        if struct.unpack_from("<I", data, offset + 44)[0] != format_id:
            return None
    width, height = struct.unpack_from("<HH", data, offset + 200)
    tagged = struct.unpack_from("<I", data, offset + 216)[0]
    if width in DIMENSIONS and height in DIMENSIONS and tagged >= 1:
        return format_id
    return None


def scan_headers(data: bytes) -> list[dict[str, int]]:
    descriptors = []
    accepted = {}
    walked_offsets = set()
    for marker_value in (32, 40):
        marker = struct.pack("<I", marker_value)
        search = 40
        while True:
            marker_offset = data.find(marker, search)
            if marker_offset < 0:
                break
            search = marker_offset + 1
            offset = marker_offset - 40
            if offset < 0 or offset % 4 != 0 or offset + HEADER_SIZE > len(data):
                continue
            if offset in accepted:
                continue
            format_id = _valid_vctexture_descriptor(data, offset)
            if format_id is None:
                continue
            accepted[offset] = format_id
            for direction in (-1, 1):
                walk = offset
                for _step in range(8):
                    walk += direction * HEADER_SIZE
                    if walk < 0 or walk % 4 != 0 or walk + HEADER_SIZE > len(data):
                        break
                    if walk in accepted:
                        continue
                    walked_format = _valid_vctexture_descriptor(data, walk)
                    if walked_format is None:
                        break
                    accepted[walk] = walked_format
                    walked_offsets.add(walk)
    for offset, format_id in sorted(accepted.items()):
        width, height = struct.unpack_from("<HH", data, offset + 200)
        tagged = struct.unpack_from("<I", data, offset + 216)[0]
        if width not in DIMENSIONS or height not in DIMENSIONS:
            continue
        if tagged < 1 and offset not in walked_offsets:
            continue
        descriptors.append({"header_offset": offset, "texture_hash": struct.unpack_from("<I", data, offset)[0], "format_id": format_id, "width": width, "height": height, "tagged_offset": tagged - 1})
    return descriptors


def scan_headers_2k16(data: bytes) -> list[dict[str, int]]:
    'Find NBA 2K16-style texture headers inside an IFF.\n\n    2K16 stores its texture catalog as 0xC0-byte descriptor records with a\n    distinctive 28-byte signature at +0x58 (see ``_2K16_SIGNATURE``).  The\n    payload offsets point into the block that follows the metadata block,\n    exactly like the 2K20 layout handled by :func:`scan_headers`.\n\n    Field layout (verified against the reference UI-strip texture B9073940\n    and the desktop tool\'s RGBA4444 report): the **format id lives at\n    +0x0C** and uses the same table as 2K20 (1 RGBA8888, 2 RGB565, 4\n    RGBA4444, 6/7/15 ETC2 RGB, 16 ETC2 RGBA8), while +0x6C is a constant\n    record-type marker (15 = texture descriptor).  Reading the format from\n    +0x6C instead -- as older builds did -- collapsed every 2K16 texture\n    into "ETC2 RGB" with the wrong payload size, which is exactly why\n    2K16 textures previously decoded as noise.  The +0xAC field stores\n    ``payload_offset_in_block + 1``: B9073940\'s raw_AC = 0x100001 places\n    the RGBA4444 logo payload at block+0x100000, not at ``raw_AC >> 1`` =\n    0x80000 (blue noise).\n    '
    descriptors = []
    search = 0
    while True:
        anchor_offset = data.find(_2K16_ANCHOR, search)
        if anchor_offset < 0:
            break
        offset = anchor_offset - 96
        if offset >= 0 and offset % 4 == 0 and offset + _2K16_HEADER_SIZE <= len(data):
            record_type = struct.unpack_from("<I", data, offset + 108)[0]
            if record_type != 15:
                search = anchor_offset + 1
                continue
            format_id = struct.unpack_from("<I", data, offset + 12)[0]
            if format_id not in FORMATS:
                search = anchor_offset + 1
                continue
            width, height = struct.unpack_from("<HH", data, offset + 160)
            tagged = struct.unpack_from("<I", data, offset + 172)[0]
            tagged_offset = tagged - 1
            if width not in DIMENSIONS or height not in DIMENSIONS or tagged < 1 or tagged_offset % 4 != 0:
                search = anchor_offset + 1
                continue
            descriptors.append({"header_offset": offset, "texture_hash": struct.unpack_from("<I", data, offset)[0], "format_id": format_id, "width": width, "height": height, "tagged_offset": tagged_offset, "is_2k16": True})
        search = anchor_offset + 1
    return descriptors


def classify_cyberface(data: bytes, *, display_name: str="", textures: list[TextureRecord] | None=None) -> dict:
    'Content-based cyberface detection for one decompressed IFF.\n\n    Both NBA 2K16 and 2K20 Android OBBs hash every resource name, so a\n    cyberface can never be identified by filename alone (there are no\n    ``FACE####.IFF`` / ``hihead`` / ``.model`` / ``.dds`` names in either\n    archive).  Instead this looks at what the IFF actually contains:\n\n    * **face texture hashes** - the small set of shared atlases referenced by\n      every ``PNG####.IFF`` scene graph and present as texture headers inside\n      the texture banks (see :data:`FACE_TEXTURE_HASHES`);\n    * **character shaders** - embedded ``characters/*.fx`` source paths\n      (eye / skin_2k10 / hair / basic) that only character containers carry.\n\n    Returns a dict with ``kind`` in {"face_scene", "face_texture_bank",\n    "character_iff", "none"}, the evidence that produced it (matching\n    texture hashes and shader paths), and a short human-readable ``label``.\n    '
    found_hashes = set()
    header_hash_count = 0
    search = 0
    while True:
        sig_offset = data.find(_2K16_SIGNATURE, search)
        if sig_offset < 0:
            break
        offset = sig_offset - 88
        if offset >= 0 and offset + _2K16_HEADER_SIZE <= len(data):
            thash = struct.unpack_from("<I", data, offset)[0]
            if thash in FACE_TEXTURE_HASHES:
                found_hashes.add(thash)
                header_hash_count += 1
        search = sig_offset + 1
    for descriptor in scan_headers(data):
        if descriptor["texture_hash"] in FACE_TEXTURE_HASHES:
            found_hashes.add(descriptor["texture_hash"])
            header_hash_count += 1
    if textures is not None:
        for texture in textures:
            if texture.texture_hash in FACE_TEXTURE_HASHES:
                found_hashes.add(texture.texture_hash)
                header_hash_count += 1
    shaders = sorted({match.decode("ascii", "ignore") for match in CHARACTER_SHADER_RE.findall(data)})
    matched_name = bool(display_name) and display_name.upper().startswith("PNG")
    resolved_texture_count = sum(1 for texture in textures if texture.payload_offset is not None) if textures is not None else 0
    label = ""
    kind = "none"
    if found_hashes and shaders:
        if matched_name or resolved_texture_count < 3:
            kind = "face_scene"
            label = "Cyberface model / scene"
        else:
            kind = "face_texture_bank"
            label = "Cyberface texture bank"
    elif found_hashes:
        kind = "face_texture_bank"
        label = "Cyberface texture bank"
    elif shaders:
        kind = "character_iff"
        label = "Character rendering IFF"
    return {"kind": kind, "label": label, "face_texture_hashes": sorted(f"{h:08X}" for h in found_hashes), "header_hash_count": header_hash_count, "resolved_texture_count": resolved_texture_count, "shaders": shaders[:8], "matched_name": matched_name}


def locate_textures(data: bytes, block_sizes: list[int],
    descriptors: list[dict[str, int]] | None=None, *, display_name: str | None=None, end_anchored_adjustment: bool=True, drop_payload_pile_ups: bool=False) -> list[TextureRecord]:
    name = (display_name or "").upper()
    is_court = bool((name.startswith("F") and len(name) >= 4 and name[1:4].isdigit()) or "COURT" in name or "FLOOR" in name)
    is_uniform = bool((name.startswith(("UH", "UA")) and len(name) >= 5 and name[2:5].isdigit()) or "UNIFORM" in name)
    if is_court or is_uniform:
        end_anchored_adjustment = False

    if descriptors is None:
        descriptors = scan_headers(data)
    header_offsets = {item["header_offset"] for item in descriptors}
    block_bases = []
    cursor = 0
    for size in block_sizes:
        block_bases.append(cursor)
        cursor += size

    def _block_index(offset: int) -> int:
        """Index of the block containing ``offset``, or -1 when outside all blocks."""
        index = bisect.bisect_right(block_bases, offset) - 1
        if index < 0 or offset >= block_bases[index] + block_sizes[index]:
            return -1
        return index

    analyzed = []
    for descriptor in descriptors:
        size = payload_size(descriptor["format_id"], descriptor["width"], descriptor["height"])
        is_cdf = (name.endswith(".CDF") or "PORTRAIT" in name) and len(block_sizes) > 1
        hdr_size = _2K16_HEADER_SIZE if descriptor.get("is_2k16") else HEADER_SIZE
        inline = descriptor["header_offset"] + hdr_size
        inline_end = inline + size
        overlaps_header = any((inline <= other < inline_end for other in header_offsets))
        metadata_block = max(_block_index(descriptor["header_offset"]), 0)
        inline_block = _block_index(inline)
        inline_block_end = block_bases[inline_block] + block_sizes[inline_block] if inline_block >= 0 else len(data)
        if is_cdf:
            inline_valid = not overlaps_header
        else:
            inline_valid = inline_end <= inline_block_end and (not overlaps_header)
        block_candidates = []
        for index, (base, block_size) in enumerate(zip(block_bases, block_sizes)):
            if index == metadata_block:
                continue
            local = descriptor["tagged_offset"]
            if local + size <= block_size:
                block_candidates.append((index, base + local))
        analyzed.append({"descriptor": descriptor, "size": size, "inline": inline, "inline_valid": inline_valid, "metadata_block": metadata_block, "block_candidates": block_candidates})
    split_metadata_blocks = {int(item["metadata_block"]) for item in analyzed if not item["inline_valid"] and item["block_candidates"]}
    block_payload_adjustments = {}
    candidate_map = {}
    for item in analyzed:
        if int(item["metadata_block"]) not in split_metadata_blocks:
            continue
        for block_index, _base in item["block_candidates"]:
            candidate_map.setdefault(block_index, []).append(item)

    for block_index, block_items in candidate_map.items():
        tagged_ends = [int(item["descriptor"]["tagged_offset"]) + int(item["size"]) for item in block_items]
        if tagged_ends:
            slack = block_sizes[block_index] - max(tagged_ends)
            hashes = {int(item["descriptor"]["texture_hash"]) for item in block_items}
            verified_end_anchored = any((signature.issubset(hashes) for signature in VERIFIED_END_ANCHORED_TEXTURE_BANKS))
            if end_anchored_adjustment and 0 < slack and (slack <= 65536 or verified_end_anchored):
                block_payload_adjustments[block_index] = slack

    if end_anchored_adjustment and not is_court and not is_uniform:
        for block_index, block_items in candidate_map.items():
            if block_index in block_payload_adjustments:
                continue
            slack = block_sizes[block_index] - max((int(item["descriptor"]["tagged_offset"]) + int(item["size"]) for item in block_items))
            if slack <= 65536 or slack <= 0:
                continue
            sample = [
                item for item in block_items
                if item["descriptor"]["format_id"] in (15, 16)
                and int(item["descriptor"]["width"]) >= 64
            ][:5]
            if len(sample) < 2:
                continue
            block_base = block_bases[block_index]
            good_base = None
            for base_choice in ("relative", "end"):
                adjustment = slack if base_choice == "end" else 0
                ok = 0
                for item in sample:
                    d = item["descriptor"]
                    local = int(d["tagged_offset"])
                    size = int(item["size"])
                    payload_off = block_base + local + adjustment
                    if payload_off + size > len(data):
                        continue
                    try:
                        if d["format_id"] == 16:
                            rgba = etc2.decode_etc2_rgba8(data[payload_off:payload_off + size], int(d["width"]), int(d["height"]))
                        else:
                            rgba = etc2.decode_etc2_rgb(data[payload_off:payload_off + size], int(d["width"]), int(d["height"]))
                    except Exception:
                        continue
                    if _is_spatially_coherent(rgba, int(d["width"]), int(d["height"])):
                        ok += 1
                if ok == len(sample):
                    good_base = base_choice
                    break
                elif ok > 0 and good_base is None:
                    good_base = base_choice
            if good_base == "end":
                block_payload_adjustments[block_index] = slack
    results = []
    for number, item in enumerate(analyzed, 1):
        try:
            results.append(_locate_one_texture(item, number, split_metadata_blocks, block_payload_adjustments))
        except Exception as error:
            descriptor = item["descriptor"]
            results.append(TextureRecord(number=number, header_offset=descriptor["header_offset"], texture_hash=descriptor["texture_hash"], format_id=descriptor["format_id"], width=descriptor["width"], height=descriptor["height"], tagged_offset=descriptor["tagged_offset"], payload_size=0, payload_offset=None, location="unresolved (parse error)", error=f"texture header could not be parsed: {error}", status="unsupported"))

    _split_chained_new_format_piles(results)
    if drop_payload_pile_ups:
        results = _drop_payload_pile_ups(results)
    _finalize_texture_allocations(results, data, block_bases, block_sizes)
    return results


def _split_chained_new_format_piles(textures: list[TextureRecord]) -> None:
    'Give chained fmt1/6/7 descriptors their sequential payload slots.\n\n    Several same-size new-format records can resolve to one payload address\n    because their tagged offsets are placeholders (raw tagged == 1).  When\n    their headers form an exact 0xF0 chain, though, they are a real\n    sequential texture table (verified on the 0ac75559 bank: a fmt6 + fmt7\n    pair of 512x256 slots packed back to back), not placeholder look-alikes,\n    so each member is assigned the next slot in header order instead of being\n    dropped by the pile-up heuristics.  Anything else keeps the old address.\n    '
    if len(textures) < 2:
        return
    piles = {}
    for texture in textures:
        if texture.payload_offset is None:
            continue
        if texture.format_id not in (FORMAT_RGBA8888, FORMAT_ETC1_RGB, FORMAT_EAC_RG11):
            continue
        piles.setdefault(texture.payload_offset, []).append(texture)
    for members in piles.values():
        if len(members) < 2:
            continue
        ordered = sorted(members, key=lambda texture: texture.header_offset)
        chained = all(later.header_offset - earlier.header_offset == HEADER_SIZE for earlier, later in zip(ordered, ordered[1:])) or all(later.header_offset - earlier.header_offset == _2K16_HEADER_SIZE for earlier, later in zip(ordered, ordered[1:]))
        if not chained or len({t.width for t in ordered}) > 1 or len({t.height for t in ordered}) > 1:
            continue
        cursor = ordered[0].payload_offset
        for index, texture in enumerate(ordered):
            texture.payload_offset = cursor
            texture.location = f"{texture.location} (chained slot {index})"
            cursor += texture.payload_size


def _locate_one_texture(item: dict[str, object], number: int, split_metadata_blocks: set[int], block_payload_adjustments: dict[int, int]) -> TextureRecord:
    descriptor = item["descriptor"]
    size = int(item["size"])
    inline = int(item["inline"])
    inline_valid = bool(item["inline_valid"])
    metadata_block = int(item["metadata_block"])
    block_candidates = item["block_candidates"]
    if metadata_block in split_metadata_blocks and block_candidates:
        preferred = next((candidate for candidate in block_candidates if candidate[0] == metadata_block + 1), block_candidates[0])
        adjustment = block_payload_adjustments.get(preferred[0], 0)
        payload_offset = preferred[1] + adjustment
        location = f"block {preferred[0] + 1} + 0x{adjustment:X} resource base + 0x{descriptor['tagged_offset']:X}"
        error = None

    elif inline_valid:
        payload_offset = inline
        location = "inline after VCTEXTURE header"
        error = None
    elif block_candidates:
        preferred = next((item for item in block_candidates if item[0] == metadata_block + 1), block_candidates[0])
        adjustment = block_payload_adjustments.get(preferred[0], 0)
        payload_offset = preferred[1] + adjustment
        location = f"block {preferred[0] + 1} + 0x{adjustment:X} resource base + 0x{descriptor['tagged_offset']:X}"
        error = None
    else:
        payload_offset = None
        location = "unresolved split DRAM/VRAM payload"
        error = "Texture header found, but its payload block boundary is unknown. Open the original compressed IFF entry or place the matching *.viewer.json sidecar next to this file."
    return TextureRecord(number=number, header_offset=descriptor["header_offset"], texture_hash=descriptor["texture_hash"], format_id=descriptor["format_id"], width=descriptor["width"], height=descriptor["height"], tagged_offset=descriptor["tagged_offset"], payload_size=size, payload_offset=payload_offset, location=location, error=error, status="unresolved" if payload_offset is None else "valid")


def _finalize_texture_allocations(results: list[TextureRecord], data: bytes, block_bases: list[int], block_sizes: list[int]) -> None:
    'Compute per-texture allocation bounds and mip-chain use.\n\n    Runs after pile-up dropping so only the surviving records contribute\n    bounds.  Records without a payload are left untouched (their status was\n    already set when they were located).\n    '
    for texture in results:
        if texture.payload_offset is None:
            continue
        block_start, block_end = 0, len(data)
        for base, block_size in zip(block_bases, block_sizes):
            if base <= texture.payload_offset < base + block_size:
                block_start, block_end = base, base + block_size
                break
        limits = [block_end]
        limits.extend(
            other.header_offset
            for other in results
            if texture.payload_offset < other.header_offset < block_end
            and other.header_offset >= block_start
        )
        limits.extend(
            other.payload_offset
            for other in results
            if other.payload_offset is not None
            and texture.payload_offset < other.payload_offset < block_end
        )
        allocation_end = min(limits)
        texture.allocation_size = allocation_end - texture.payload_offset
        full_chain = mip_chain_size(texture.format_id, texture.width, texture.height)
        texture.uses_mip_chain = full_chain <= texture.allocation_size
        texture.encoded_size = full_chain if texture.uses_mip_chain else texture.payload_size
        texture.mip_count = mip_level_count(texture.width, texture.height) if texture.uses_mip_chain else 1


def _drop_payload_pile_ups(textures: list[TextureRecord]) -> list[TextureRecord]:
    'NBA 2K16 scene graphs embed texture-shaped records that all keep the\n    placeholder tagged offset (0), so a pile of them resolves to one address.\n    Real banks never share a payload slot: large piles are dropped whole, and\n    small piles keep the single member whose payload fits the allocation (the\n    real bank slot) while discarding the scene-graph look-alikes.\n    '
    if len(textures) < 2:
        return textures
    pile_groups = {}
    for texture in textures:
        if texture.payload_offset is None:
            continue
        pile_groups.setdefault(texture.payload_offset, []).append(texture)
    crowded = {offset: members for offset, members in pile_groups.items() if len(members) >= 2}
    if not crowded:
        return textures
    occupied = sorted(pile_groups)
    kept = set()
    for offset, members in crowded.items():
        if len(members) >= _2K16_NOISE_PILE_UP:
            continue
        new_format_pile = all(texture.format_id in (FORMAT_RGBA8888, FORMAT_ETC1_RGB, FORMAT_EAC_RG11) for texture in members)
        if new_format_pile:
            continue
        next_offset = next((candidate for candidate in occupied if candidate > offset), None)
        allocation = next_offset - offset if next_offset is not None else 4611686018427387904
        fitting = [texture for texture in members if texture.payload_size <= allocation]
        if fitting:
            kept.add(id(max(fitting, key=lambda texture: texture.payload_size)))
    return [
        texture
        for texture in textures
        if texture.payload_offset is None
        or texture.payload_offset not in crowded
        or id(texture) in kept
    ]


def drop_piled_new_format_records(textures: list[TextureRecord]) -> list[TextureRecord]:
    'Drop fmt1/6/7 records that land on a shared payload address.\n\n    The format-1/6/7 header layout is also used by non-texture resource\n    records inside complex IFFs (GLOBAL, uniform catalogues): several of those\n    records keep a placeholder tagged offset, so they pile onto one payload\n    address.  Real texture banks give every texture its own slot.  Any\n    new-format record whose payload address is shared with at least one other\n    record is therefore a placeholder look-alike and is dropped, while\n    known-format records keep the exact pre-existing behaviour.\n    '
    if not textures:
        return textures
    pile_sizes = {}
    for texture in textures:
        if texture.payload_offset is None:
            continue
        pile_sizes[texture.payload_offset] = pile_sizes.get(texture.payload_offset, 0) + 1
    new_formats = (FORMAT_RGBA8888, FORMAT_ETC1_RGB, FORMAT_EAC_RG11)
    return [texture for texture in textures if texture.format_id not in new_formats or texture.payload_offset is None or pile_sizes[texture.payload_offset] < 2]


def reconcile_inline_texture_allocations(textures: list[TextureRecord]) -> None:
    payload_starts = sorted({texture.payload_offset for texture in textures if texture.payload_offset is not None})
    for texture in textures:
        if not texture.has_header or texture.payload_offset is None:
            continue
        later_starts = [start for start in payload_starts if start > texture.payload_offset]
        if not later_starts:
            continue
        safe_size = min(later_starts) - texture.payload_offset
        if texture.allocation_size and safe_size >= texture.allocation_size:
            continue
        texture.allocation_size = safe_size
        full_chain = mip_chain_size(texture.format_id, texture.width, texture.height)
        texture.uses_mip_chain = full_chain <= safe_size
        texture.encoded_size = full_chain if texture.uses_mip_chain else texture.payload_size


def _block_ranges(block_sizes: list[int]) -> list[tuple[int, int]]:
    ranges = []
    start = 0
    for size in block_sizes:
        ranges.append((start, start + size))
        start += size
    return ranges


def rgba8888_candidate_metrics(payload: bytes) -> dict | None:
    from collections import Counter
    expected = RAW_RGBA8888_PROBE_SIZE
    if len(payload) != expected:
        return None
    pixel_count = RAW_RGBA8888_PROBE_WIDTH * RAW_RGBA8888_PROBE_HEIGHT
    alpha = payload[3::4]
    alpha_counts = Counter(alpha)
    [dominant_alpha, dominant_count] = alpha_counts.most_common(1)[0]
    view = memoryview(payload)
    active_rgb = 0
    sampled_colors = set()
    neighbor_total = 0.0
    neighbor_count = 0
    sample_indices = range(0, pixel_count, 17)
    sample_count = len(sample_indices)
    for pixel in sample_indices:
        offset = pixel * 4
        rgb = (view[offset], view[offset + 1], view[offset + 2])
        sampled_colors.add(rgb)
        if rgb != (0, 0, 0):
            active_rgb += 1

        if pixel % RAW_RGBA8888_PROBE_WIDTH != RAW_RGBA8888_PROBE_WIDTH - 1:
            neighbor = offset + 4
            neighbor_total += (abs(view[offset] - view[neighbor]) + abs(view[offset + 1] - view[neighbor + 1]) + abs(view[offset + 2] - view[neighbor + 2])) / 3
            neighbor_count += 1
        continue
    return {"dominant_alpha": dominant_alpha, "dominant_alpha_ratio": dominant_count / pixel_count, "alpha_unique": len(alpha_counts), "active_rgb_ratio": active_rgb / sample_count, "sampled_color_count": len(sampled_colors), "mean_horizontal_difference": neighbor_total / neighbor_count}


def is_confident_rgba8888(metrics: dict | None) -> bool:
    if metrics is None:
        return False
    return metrics["dominant_alpha_ratio"] >= 0.5 and metrics["alpha_unique"] <= 64 and (metrics["active_rgb_ratio"] >= 0.1) and (metrics["sampled_color_count"] >= 64) and (metrics["mean_horizontal_difference"] <= 20.0)


def is_confident_uniform_rgba8888(metrics: dict | None) -> bool:
    if metrics is None:
        return False
    return metrics["dominant_alpha_ratio"] >= 0.5 and metrics["alpha_unique"] <= 256 and (metrics["active_rgb_ratio"] >= 0.1) and (metrics["sampled_color_count"] >= 64) and (metrics["mean_horizontal_difference"] <= 20.0)


def _uniform_layout_signature(display_name: str,
    inline_textures: list[TextureRecord] | None=None) -> bool:
    if inline_textures is None:
        inline_textures = []
    texture_signature = [(texture.texture_hash, texture.format_id, texture.width, texture.height) for texture in inline_textures[:3]]
    first_expected = (4063447360, 4, (1024, 2048), 64)
    matches = len(texture_signature) >= 3 and all((got[0] == want[0] and got[1] == want[1] and (got[2] in want[2] if isinstance(want[2], tuple) else got[2] == want[2]) and got[3] == want[3] for got, want in zip(texture_signature, (first_expected, (1040589046, 4, 1024, 128), (2304541342, 15, 512, 512)))))
    return bool(UNIFORM_IFF_NAME.match(display_name) or matches)


def locate_detected_rgba8888_texture(data: bytes, block_sizes: list[int], display_name: str, inline_textures: list[TextureRecord], start_number: int) -> list[TextureRecord]:
    offset = RAW_RGBA8888_PROBE_OFFSET
    end = offset + RAW_RGBA8888_PROBE_SIZE
    containing_block = next(((block_start, block_end) for block_start, block_end in _block_ranges(block_sizes) if block_start <= offset and end <= block_end), None)
    if containing_block is None or end > len(data):
        return []
    metrics = rgba8888_candidate_metrics(data[offset:end])
    is_uniform = _uniform_layout_signature(display_name, inline_textures)
    if not is_confident_rgba8888(metrics) and (not is_uniform or not is_confident_uniform_rgba8888(metrics)):
        return []

    assert metrics is not None
    label = "Uniform Visual / Full Jersey Atlas" if is_uniform else "Detected Raw RGBA8888 Atlas"
    evidence = f"alpha 0x{int(metrics['dominant_alpha']):02X} {float(metrics['dominant_alpha_ratio']):.1%}; {int(metrics['alpha_unique'])} alpha values; neighbor difference {float(metrics['mean_horizontal_difference']):.1f}"
    return [TextureRecord(number=start_number, header_offset=offset, texture_hash=0, format_id=FORMAT_RGBA8888_RAW, width=RAW_RGBA8888_PROBE_WIDTH, height=RAW_RGBA8888_PROBE_HEIGHT, tagged_offset=offset - containing_block[0], payload_size=RAW_RGBA8888_PROBE_SIZE, payload_offset=offset, location=f"""detected at decoded 0x{offset:X}; {evidence}""", allocation_size=RAW_RGBA8888_PROBE_SIZE, encoded_size=RAW_RGBA8888_PROBE_SIZE, uses_mip_chain=False, label=label, has_header=False)]


def locate_uniform_streamed_textures(data: bytes, block_sizes: list[int], display_name: str, inline_textures: list[TextureRecord], start_number: int) -> list[TextureRecord]:
    if not _uniform_layout_signature(display_name, inline_textures):
        return []

    if len(block_sizes) < 2:
        return []
    blocks = _block_ranges(block_sizes)
    [block_start, block_end] = blocks[-1]
    block_len = block_end - block_start
    if block_len not in (UNIFORM_STREAM_BLOCK_SIZE, UNIFORM_NORMAL_STREAM_SIZE):
        return []

    if block_end > len(data):
        return []
    normal_offset = block_start
    if block_len == UNIFORM_STREAM_BLOCK_SIZE:
        color_offset = block_start + UNIFORM_COLOR_STREAM_OFFSET
        if color_offset + UNIFORM_COLOR_STREAM_SIZE > block_end:
            return []
    else:
        color_offset = None
    normal_record = TextureRecord(number=start_number, header_offset=normal_offset, texture_hash=0, format_id=FORMAT_RG8, width=512, height=512, tagged_offset=0, payload_size=payload_size(FORMAT_RG8, 512, 512), payload_offset=normal_offset, location="streamed uniform block + 0x0", allocation_size=UNIFORM_NORMAL_STREAM_SIZE, encoded_size=UNIFORM_NORMAL_ENCODED_SIZE, uses_mip_chain=True, label="Uniform Normal / Chest Wordmark Atlas", has_header=False)
    if color_offset is None:
        return [normal_record]
    return [normal_record, TextureRecord(number=start_number + 1, header_offset=color_offset, texture_hash=0, format_id=15, width=512, height=512, tagged_offset=UNIFORM_COLOR_STREAM_OFFSET, payload_size=payload_size(15, 512, 512), payload_offset=color_offset, location=f"""streamed uniform block + 0x{UNIFORM_COLOR_STREAM_OFFSET:X}""", allocation_size=UNIFORM_COLOR_STREAM_SIZE, encoded_size=UNIFORM_COLOR_STREAM_SIZE, uses_mip_chain=False, label="Uniform Color / Team Logo Atlas", has_header=False)]


def _repair_uniform_catalog_payloads(data: bytes, textures: list[TextureRecord], block_sizes: list[int]) -> None:
    'Re-point piled uniform catalog records to their inline payloads.\n\n    Uniform IFFs (UH/UA) store their wordmark atlases and the number/letter\n    fonts inline right after their VCTEXTURE headers inside the catalog\n    block, but their tagged offsets are placeholder values (0x18) that all\n    resolve to one shared address at the start of the streamed block.  That\n    pile is distinguishable from a real bank table: several different-size\n    records claim the exact same payload start, which no real bank does.\n\n    The repair re-points every member of such a pile to its inline slot\n    (header + 0xF0) when that slot fits before the next header.  fmt1\n    256x256 fonts occupy w*h*4 bytes (RGBA8888) — proven by the next header\n    landing at (or just after) inline + w*h*4 — so their payload size is\n    widened and ``decode_texture_rgba`` returns full-color pixels instead of\n    a 1-bpp mask interpretation.\n    '
    if not textures:
        return
    catalog_headers = sorted(texture.header_offset for texture in textures if texture.has_header and texture.header_offset)
    if not catalog_headers:
        return
    first_block_end = block_sizes[0] if block_sizes else len(data)
    pile_groups = {}
    for texture in textures:
        if texture.payload_offset is not None:
            pile_groups.setdefault(texture.payload_offset, []).append(texture)
    for members in pile_groups.values():
        if len(members) < 2:
            continue
        for texture in members:
            if not texture.has_header or not texture.header_offset:
                continue
            is_16 = getattr(texture, "is_2k16", False) or (texture.header_offset + 112 <= len(data) and data[texture.header_offset + 108:texture.header_offset + 112] == b"\x0f\x00\x00\x00" and data[texture.header_offset + 96:texture.header_offset + 108] == _2K16_ANCHOR)
            hdr_size = _2K16_HEADER_SIZE if is_16 else HEADER_SIZE
            inline = texture.header_offset + hdr_size
            if inline <= texture.header_offset or inline >= first_block_end:
                continue
            next_header = next((offset for offset in catalog_headers if offset > texture.header_offset), None)
            if texture.format_id == FORMAT_RGBA8888:
                rgba_end = inline + texture.width * texture.height * 4
                bound = next_header if next_header is not None else first_block_end
                if rgba_end <= bound and bound - rgba_end < 16384:
                    texture.payload_size = texture.width * texture.height * 4
                    texture.encoded_size = texture.payload_size
            end = inline + (texture.payload_size or 0)
            if end > first_block_end:
                continue
            if next_header is not None and end > next_header:
                continue
            texture.payload_offset = inline
            texture.allocation_size = texture.payload_size
            full_chain = mip_chain_size(texture.format_id, texture.width, texture.height)
            texture.uses_mip_chain = full_chain <= texture.payload_size
            texture.encoded_size = full_chain if texture.uses_mip_chain else texture.payload_size
            texture.location = "inline after VCTEXTURE header (uniform catalog)"


def _redirect_uniform_stream_descriptors(data: bytes, textures: list[TextureRecord], block_sizes: list[int]) -> None:
    'Re-point OBB uniform catalog descriptors to their streamed atlases.\n\n    In the OBB-shipped uniform IFFs the fmt15 color-atlas descriptor (hash\n    0x895C829E) and its fmt7 normal-map companion (0x20D15ABF) keep the\n    placeholder tagged offset 0 -- the start of the streamed block -- so\n    ``_finalize_texture_allocations`` clamps their allocation to the 24 bytes\n    before the next claimant.  Importing them then failed with\n    "encoded texture needs ... bytes but its IFF allocation contains only 24\n    bytes".\n\n    The color descriptor\'s real pixel data is the mip chain that\n    :func:`locate_uniform_streamed_textures` records separately (same format\n    and dimensions).  It is re-pointed onto that chain\'s base level so the\n    record previews and imports the actual jersey art.\n\n    The fmt7 normal-map descriptor has no same-format streamed counterpart\n    (2K20 stores jersey normals in the streamed fmt4 chain), so it is marked\n    unresolved with a clear message instead of failing with a byte-count\n    error later.\n    '
    streamed = [texture for texture in textures if texture.location.startswith("streamed uniform block")]
    color_stream = next((texture for texture in streamed if texture.format_id == 15), None)
    normal_stream = next((texture for texture in streamed if texture.format_id in (4, FORMAT_RG8)), None)
    for texture in textures:
        if texture.payload_offset is None:
            continue
        if texture.location.startswith("streamed uniform block"):
            continue
        clamped = texture.allocation_size < texture.payload_size
        if color_stream is not None and texture.texture_hash == 2304541342 and clamped:
            texture.payload_offset = color_stream.payload_offset
            texture.payload_size = color_stream.payload_size
            texture.allocation_size = color_stream.payload_size
            texture.encoded_size = color_stream.payload_size
            texture.uses_mip_chain = False
            texture.mip_count = 1
            texture.status = "valid"
            texture.error = None
            texture.location = "streamed uniform color atlas (catalog descriptor re-pointed)"
            continue
        if normal_stream is not None and texture.texture_hash == 550591167 and clamped:
            texture.payload_offset = normal_stream.payload_offset
            texture.payload_size = normal_stream.payload_size
            texture.allocation_size = normal_stream.payload_size
            texture.encoded_size = normal_stream.payload_size
            texture.format_id = normal_stream.format_id
            texture.width = normal_stream.width
            texture.height = normal_stream.height
            texture.uses_mip_chain = False
            texture.mip_count = 1
            texture.status = "valid"
            texture.error = None
            texture.location = "streamed uniform normal atlas (catalog descriptor re-pointed)"
            continue
        if texture.texture_hash == 550591167 and clamped:
            texture.payload_offset = None
            texture.status = "unresolved"
            texture.error = "this jersey descriptor points at streamed atlas data that is not stored as an editable slot in this IFF; replace the 'Uniform Normal / Chest Wordmark Atlas' texture instead"


UNIFORM_TEXTURE_LABELS = {
    4063447360: "Jersey Wordmark Atlas",
    550591167: "Uniform Normal / Details Atlas",
    2195219320: "Jersey Numbers Font",
    1040589046: "Jersey Wordmark / Name Atlas",
    2304541342: "Team Logo / Color Atlas",
    4196748891: "Jersey Letters / Shorts Font",
}

UNIFORM_DEFAULT_LABELS = [
    "Jersey Wordmark Atlas",
    "Uniform Normal / Details Atlas",
    "Jersey Numbers Font",
    "Jersey Wordmark / Name Atlas",
    "Team Logo / Color Atlas",
    "Jersey Letters / Shorts Font",
    "Uniform Visual / Full Jersey Atlas",
    "Uniform Normal / Chest Wordmark Atlas",
    "Uniform Color / Team Logo Atlas",
]


def _assign_uniform_texture_labels(textures: list[TextureRecord]) -> None:
    for idx, tex in enumerate(textures):
        if not tex.label:
            if tex.texture_hash in UNIFORM_TEXTURE_LABELS:
                tex.label = UNIFORM_TEXTURE_LABELS[tex.texture_hash]
            elif idx < len(UNIFORM_DEFAULT_LABELS):
                tex.label = UNIFORM_DEFAULT_LABELS[idx]


def _find_recorded_block_sizes(path: Path, total: int) -> tuple[list[int] | None, str]:
    """Reuse a desktop-tool ``*.viewer.json`` sidecar when one sits next to the IFF."""
    resolved = path.resolve()
    sidecar = resolved.with_suffix(resolved.suffix + ".viewer.json")
    if not sidecar.is_file():
        return (None, "not recorded")

    try:
        record = json.loads(sidecar.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return (None, "sidecar unreadable")
    sizes = record.get("decompressed_block_sizes")
    if not isinstance(sizes, list) or not sizes:
        return (None, "sidecar has no block sizes")

    if not all((isinstance(value, int) and value > 0 for value in sizes)):
        return (None, "sidecar block sizes invalid")

    if sum(sizes) != total:
        return (None, "sidecar block sizes do not match file")
    return (sizes, str(sidecar))


def open_iff_bytes(raw: bytes, display_path: Path) -> OpenedIff:
    path = display_path.resolve()
    if not raw:
        raise ValueError("IFF file is empty")
    data, block_sizes, wrapper, wrapper_info = decompress_wrapper(raw)
    boundary_source = "compressed wrapper"
    if wrapper == "decompressed IFF":
        [recorded, boundary_source] = _find_recorded_block_sizes(path, len(data))
        if recorded:
            block_sizes = recorded
        else:
            boundary_source = "single block / no companion manifest"
    descriptors_2k20 = scan_headers(data)
    descriptors_2k16 = scan_headers_2k16(data)
    is_uniform_iff = _uniform_layout_signature(path.name, None)
    if descriptors_2k16:
        textures = locate_textures(data, block_sizes, descriptors_2k16, display_name=path.name, end_anchored_adjustment=True, drop_payload_pile_ups=not is_uniform_iff)
    else:
        textures = locate_textures(data, block_sizes, descriptors_2k20, display_name=path.name)
        if not is_uniform_iff:
            textures = drop_piled_new_format_records(textures)
    inline_textures = list(textures)
    textures.extend(locate_detected_rgba8888_texture(data, block_sizes, path.name, inline_textures, len(textures) + 1))
    textures.extend(locate_uniform_streamed_textures(data, block_sizes, path.name, inline_textures, len(textures) + 1))
    if _uniform_layout_signature(path.name, inline_textures):
        _repair_uniform_catalog_payloads(data, textures, block_sizes)
        _redirect_uniform_stream_descriptors(data, textures, block_sizes)
        _assign_uniform_texture_labels(textures)
    is_cyber = is_png_scene_name(path.name)
    if not is_cyber:
        cyber_class = classify_cyberface(data, display_name=path.name, textures=textures)
        resolved_count = sum((t.payload_offset is not None for t in textures))
        if cyber_class["kind"] == "face_scene" and resolved_count < _PACKAGE_RESOLVED_TEXTURE_LIMIT:
            is_cyber = True

        elif cyber_class["kind"] == "face_texture_bank" and len(block_sizes) <= 1 and (resolved_count < _PACKAGE_RESOLVED_TEXTURE_LIMIT):
            is_cyber = True

    if is_cyber:
        textures = attach_scene_references(data, textures, block_sizes)
    return OpenedIff(path=path, source_size=len(raw), wrapper=wrapper, source_raw=raw, original_data=data, data=bytearray(data), block_sizes=block_sizes, boundary_source=boundary_source, textures=textures, wrapper_info=wrapper_info)


def _scene_reference_records(data: bytes) -> list[TextureRecord]:
    "Texture-shaped descriptors inside a scene container, in file order.\n\n    Every record carries a placeholder tagged offset (raw tagged == 1) and\n    points at the shared face atlases whose real payload lives in a separate\n    texture bank.  The record's scan position is its stable identifier (the\n    number the rest of the engine uses), so it is never renumbered.\n    "
    records = []
    search = 0
    while True:
        sig_offset = data.find(_2K16_SIGNATURE, search)
        if sig_offset < 0:
            break
        offset = sig_offset - 88
        if offset >= 0 and offset % 4 == 0 and offset + _2K16_HEADER_SIZE <= len(data):
            if struct.unpack_from("<I", data, offset + 108)[0] == 15:
                format_id = struct.unpack_from("<I", data, offset + 12)[0]
                width, height = struct.unpack_from("<HH", data, offset + 160)
                tagged = struct.unpack_from("<I", data, offset + 172)[0]
                if format_id in FORMATS and width in DIMENSIONS and height in DIMENSIONS and tagged == 1:
                    thash = struct.unpack_from("<I", data, offset)[0]
                    records.append(TextureRecord(number=len(records) + 1, header_offset=offset, texture_hash=thash, format_id=format_id, width=width, height=height, tagged_offset=0, payload_size=payload_size(format_id, width, height), payload_offset=None, location="scene reference descriptor", error="Referenced texture: this scene graph only references the shared face atlases; their data lives in a separate texture bank inside the same OBB.", status="reference", role=scene_descriptor_role(format_id, width, height)))
        search = sig_offset + 1
    for descriptor in scan_headers(data):
        if descriptor["tagged_offset"] != 0:
            continue
        thash = descriptor["texture_hash"]
        if thash not in FACE_TEXTURE_HASHES:
            continue
        format_id = descriptor["format_id"]
        width = descriptor["width"]
        height = descriptor["height"]
        identity = (thash, format_id, width, height)
        if any((record.texture_hash, record.format_id, record.width, record.height) == identity for record in records):
            continue
        records.append(TextureRecord(number=len(records) + 1, header_offset=descriptor["header_offset"], texture_hash=thash, format_id=format_id, width=width, height=height, tagged_offset=0, payload_size=payload_size(format_id, width, height), payload_offset=None, location="scene reference descriptor (VCTEXTURE)", error="Referenced texture: this scene graph only references the shared face atlases; their data lives in a separate texture bank inside the same OBB.", status="reference", role=scene_descriptor_role(format_id, width, height)))
    groups = {}
    for record in records:
        if record.format_id != 16 and record.width < 512:
            groups.setdefault((record.width, record.height), []).append(record)
    role_ladder = ("Material Map", "Normal Map")
    for group in groups.values():
        if len(group) < 2:
            continue
        for index, record in enumerate(sorted(group, key=lambda r: r.header_offset)):
            if index < len(role_ladder):
                record.role = role_ladder[index]
    if records and all(record.width < 512 and record.height < 512 for record in records):
        shared_hash = next((h for h, label in FACE_ROLE_LABELS.items() if label == "Shared Texture"), None)
        if shared_hash is not None:
            records.append(TextureRecord(number=len(records) + 1, header_offset=-1, texture_hash=shared_hash, format_id=15, width=512, height=512, tagged_offset=0, payload_size=payload_size(15, 512, 512), payload_offset=None, location="shared face atlas (implied by scene)", error="Referenced texture: this scene graph only references the shared face atlases; their data lives in a separate texture bank inside the same OBB.", status="reference", role="Shared Texture"))
    return records


def _top_strip_static(rgba: bytes, width: int, rows: int) -> float:
    """Mean per-neighbour RGB jump (0..1) across the top ``rows`` scanlines.

    Bytes that are NOT the texture the record claims (a locate start that
    landed before the real payload, decoding a neighbouring record's tail or
    padding as ETC2) render as high-frequency static, so this score is high.
    Real texture rows (skin, smooth atlas regions) score low.
    """
    jumps = 0
    n = 0
    for y in range(rows):
        base = y * width * 4
        for x in range(width - 1):
            o = base + x * 4
            jumps += abs(rgba[o] - rgba[o + 4]) + abs(rgba[o + 1] - rgba[o + 5]) + abs(rgba[o + 2] - rgba[o + 6])
            n += 1
    return jumps / n / 765.0 if n else 0.0


def _top_static_at(data: bytes, off: int, fmt: int,
    width: int=256,
    rows: int=12) -> float:
    """Static score of the top ``rows`` scanlines decoded at ``off``.

    Only the first block rows are decoded: ETC2 blocks are independent, so a
    short strip is enough to tell real texture rows (smooth) from a
    misaligned start (high-frequency static) while staying fast enough for
    the coarse scan in ``_refine_2k_tail_start``.
    """
    block_rows = (rows + 3) // 4
    blocks = block_rows * (width // 4)
    if off < 0:
        return 0.0

    try:
        if fmt == 16:
            need = blocks * 16
            if off + need > len(data):
                return 0.0
            rgba = etc2.decode_etc2_rgba8(data[off:off + need], width, rows)
        elif fmt == 15:
            need = blocks * 8
            if off + need > len(data):
                return 0.0
            rgba = etc2.decode_etc2_rgb(data[off:off + need], width, rows)
        else:
            return 0.0
    except Exception:
        return 0.0
    return _top_strip_static(rgba, width, rows)


def _refine_2k_tail_start(data: bytes, start: int,
    diffuse_bytes: int=65536,
    material_bytes: int=32768, width: int=256) -> int:
    'Correct a packed-tail locate start that landed before the Face Diffuse.\n\n    A subset of scenes carry a variable-length prefix (a neighbouring payload\n    or padding) immediately before the diffuse.  The face-score scan rewards\n    such early starts (the prefix decodes dark, so the corner penalty stays\n    low), which makes the diffuse\'s first rows read prefix bytes and export as\n    a static band -- the "rainbow at the top of the PNG" glitch.\n\n    When the top strip at ``start`` decodes as static we walk forward looking\n    for the alignment where BOTH the diffuse (fmt 16) and the material map\n    that follows it (fmt 15) start clean, and return that corrected start.\n    Scenes whose top strip is already smooth are returned unchanged, so their\n    exports stay byte-identical (guarded fix: only glitchy textures move).\n    '
    if _top_static_at(data, start, 16, width) < 0.12:
        return start
    coarse_span = 262144
    limit = min(start + coarse_span, len(data) - diffuse_bytes - material_bytes)
    if limit <= start:
        return start
    best = None
    for off in range(start, limit + 1, 1024):
        d = _top_static_at(data, off, 16, width)
        if d > 0.055:
            continue
        m = _top_static_at(data, off + diffuse_bytes, 15, width)
        if m > 0.065:
            continue
        score = d + m
        if best is None or score < best[0]:
            best = (score, off)
    if best is None:
        return start
    lo = max(start, best[1] - 1024)
    hi = min(best[1] + 1024, limit)
    fine = best
    for off in range(lo, hi + 1, 16):
        d = _top_static_at(data, off, 16, width)
        if d > 0.055:
            continue
        m = _top_static_at(data, off + diffuse_bytes, 15, width)
        if m > 0.065:
            continue
        score = d + m
        if score < fine[0]:
            fine = (score, off)
    if fine[1] == start:
        return start
    return fine[1]


def _resolve_2k20_tail_layout(data: bytes, b0_len: int, face_headers: list[dict],
    hair_bytes: int=65536) -> list[dict] | None:
    "Choose the 2K20 packed-tail layout whose slots decode cleanest.\n\n    The classic layout assumed every scene ends with the canonical chain\n    [Diffuse 65536][Material 32768][Normal 131072][Detail 8192][Hair 65536].\n    That breaks on scenes with a smaller final texture: e.g. PNG1292 (2K20\n    v98) carries a 128x128 single-channel hair mask (16384 bytes = w*h), so\n    the EOF-anchored slots were each shifted 49152 bytes too early and every\n    texture in the chain decoded misaligned garbage.\n\n    Candidate layouts cover the known texture-set shapes (with/without hair,\n    full-size vs small 128x128 hair) plus a byte-window scan for anything\n    else.  Each candidate places the chain end-anchored and is scored by\n    decoding only the TOP STRIP of the diffuse+material+detail (a few block\n    rows each -- cheap) and summing their static-ness; misaligned starts read\n    neighbouring bytes and score as static.  The winner must also beat the\n    previously-hardcoded layout's score, so already-correct scenes keep\n    byte-identical results.\n    "
    total = len(data)
    def offsets_from_end(hair_bytes: int, has_hair: bool) -> dict[str, int] | None:
        tail = 237568 + (hair_bytes if has_hair else 0)
        t1 = total - tail
        if t1 < b0_len:
            return None
        return {"t1": t1, "t2": t1 + 65536, "t3": t1 + 65536 + 32768, "t4": t1 + 65536 + 32768 + 131072, "t5": total - hair_bytes if has_hair else None, "hair_bytes": hair_bytes if has_hair else 0}
    candidates = []
    off = offsets_from_end(hair_bytes, True)
    if off:
        candidates.append({**off, "name": "descriptor5"})
    off = offsets_from_end(65536, True)
    if off:
        candidates.append({**off, "name": "canonical5"})
    off = offsets_from_end(0, False)
    if off:
        candidates.append({**off, "name": "canonical4"})
    for alt in (16384, 8192, 32768):
        if alt == hair_bytes:
            continue
        off = offsets_from_end(alt, True)
        if off:
            candidates.append({**off, "name": f"hair{alt}"})
    span_limit = min(total - 237568, total)
    scan_start = max(b0_len, total - 262144)
    if span_limit > scan_start:
        for t1 in range(scan_start, span_limit + 1, 1024):
            candidates.append({"name": "scan", "t1": t1, "t2": t1 + 65536, "t3": t1 + 65536 + 32768, "t4": t1 + 65536 + 32768 + 131072, "t5": None, "hair_bytes": 0})
    def layout_score(off: dict) -> float | None:
        d = _top_static_at(data, off["t1"], 16, 256, rows=24)
        m = _top_static_at(data, off["t2"], 15, 256, rows=24)
        det = _top_static_at(data, off["t4"], 15, 128, rows=24)
        if d < 0 or m < 0 or det < 0:
            return None
        return d + m + det
    structural = [c for c in candidates if c["name"] != "scan"]
    best = None
    for cand in structural:
        score = layout_score(cand)
        if score is None:
            continue
        if best is None or score < best[0]:
            best = (score, cand["name"], cand)
    if best is None or best[0] > 0.14:
        for cand in candidates:
            if cand["name"] == "scan":
                score = layout_score(cand)
                if score is None:
                    continue
                if best is None or score < best[0]:
                    best = (score, cand["name"], cand)
    if best is None:
        return None
    _score, _name, chosen = best
    descriptor = next((c for c in candidates if c["name"] == "descriptor5"), None)
    if descriptor is not None and descriptor["t1"] != chosen["t1"]:
        dscore = layout_score(descriptor)
        if dscore is not None and dscore <= best[0] + 0.03:
            chosen = descriptor
    return chosen


def resolve_cyberface_tail(data: bytes, block_sizes: list[int]) -> list[TextureRecord] | None:
    """Resolve 2K mobile cyberface textures packed in the tail of Block 1.

    Supports both NBA 2K20 (256x256 / 128x128 textures) and NBA 2K16 (512x512 / 512x256 / 256x256 textures).

    NBA 2K20 layout:
      T1: 256x256 ETC2 RGBA8 (fmt 16, 65536 bytes) - Face Diffuse
      T2: 256x256 ETC RGB8   (fmt 15, 32768 bytes) - Material Map (Torso/Tattoos)
      T3: 256x256 EAC RG11   (fmt 7,  65536 bytes) - Normal Map
      T4: 128x128 ETC RGB8   (fmt 15, 8192 bytes)  - Detail Mask
      T5: 128x128 Alpha Mask (fmt 1,  16384 bytes) - Hair/Beard Mask (optional)

    NBA 2K16 layout:
      T1: 512x512 ETC2 RGBA8 (fmt 16, 262144 bytes) - Face Diffuse
      T2: 512x256 ETC RGB8   (fmt 15, 65536 bytes)  - Material Map
      T3: 512x256 EAC RG11   (fmt 7,  131072 bytes) - Normal Map
      T4: 256x256 ETC RGB8   (fmt 15, 32768 bytes)  - Detail Mask
      T5: 256x256 Alpha Mask (fmt 1,  65536 bytes)  - Hair/Beard Mask (optional)
    """
    if len(block_sizes) < 2:
        return None
    b0_len = block_sizes[0]
    b1_len = block_sizes[1]
    if b1_len < 100000:
        return None
    hdrs_16 = scan_headers_2k16(data[:b0_len])
    face_hdrs_16 = [h for h in hdrs_16 if h["texture_hash"] != 34351951 and (h["texture_hash"] in FACE_TEXTURE_HASHES or h["width"] in (256, 512))]
    if len(face_hdrs_16) >= 3:
        records_2k16 = []
        roles_16 = ["Face Diffuse", "Material Map", "Normal Map", "Detail Mask", "Hair Beard Mask"]
        is_5 = len(face_hdrs_16) >= 5
        if face_hdrs_16[0]["width"] <= 256:
            tail_sz = 303104 if is_5 else 237568
            st = len(data) - tail_sz
            if st >= b0_len:
                t1_o = st
                t2_o = st + 65536
                t3_o = st + 65536 + 32768
                t4_o = len(data) - 73728 if is_5 else len(data) - 8192
                t5_o = len(data) - 65536 if is_5 else None
                offsets_2k18 = [t1_o, t2_o, t3_o, t4_o] + ([t5_o] if is_5 else [])
                sizes_2k18 = [65536, 32768, 131072, 8192] + ([65536] if is_5 else [])
                if is_5:
                    h5_18 = face_hdrs_16[4]
                    sizes_2k18[4] = h5_18["width"] * h5_18["height"]

                for num, h in enumerate(face_hdrs_16[:len(offsets_2k18)], start=1):
                    role_16 = roles_16[num - 1] if num - 1 < len(roles_16) else "Face Texture"
                    poff = offsets_2k18[num - 1]
                    psz = sizes_2k18[num - 1]
                    w_dim = 128 if num in (4, 5) else 256
                    h_dim = 128 if num in (4, 5) else 256
                    fmt_val = 16 if num == 1 else 15 if num in (2, 4) else 7 if num == 3 else 1
                    records_2k16.append(TextureRecord(number=num, header_offset=h["header_offset"], texture_hash=h["texture_hash"], format_id=fmt_val, width=w_dim, height=h_dim, tagged_offset=h["tagged_offset"], payload_size=psz, payload_offset=poff, location=f"""Cyberface texture {num}""", allocation_size=psz, encoded_size=psz, uses_mip_chain=False, error=None, label=role_16, has_header=True, status="valid", mip_count=1, payload_bytes=None, role=role_16))
        else:
            tail_sz = 1212416 if is_5 else 950272
            st = len(data) - tail_sz
            if st >= b0_len:
                t1_o = st
                t2_o = st + 262144
                t3_o = t2_o + 131072
                t4_o = t3_o + 524288
                t5_o = t4_o + 32768 if is_5 else None
                offsets_16 = [t1_o, t2_o, t3_o, t4_o] + ([t5_o] if is_5 else [])
                sizes_16 = [262144, 131072, 524288, 32768] + ([262144] if is_5 else [])
                dims_16 = [(512, 512), (512, 512), (512, 512), (256, 256)] + ([(256, 256)] if is_5 else [])
                fmts_16 = [16, 15, 7, 15] + ([1] if is_5 else [])
                if is_5:
                    h5 = face_hdrs_16[4]
                    sizes_16[4] = h5["width"] * h5["height"]

                for num, h in enumerate(face_hdrs_16[:len(offsets_16)], start=1):
                    role_16 = roles_16[num - 1] if num - 1 < len(roles_16) else "Face Texture"
                    poff = offsets_16[num - 1]
                    psz = sizes_16[num - 1]
                    [w_dim, h_dim] = dims_16[num - 1]
                    fmt_val = fmts_16[num - 1]
                    records_2k16.append(TextureRecord(number=num, header_offset=h["header_offset"], texture_hash=h["texture_hash"], format_id=fmt_val, width=w_dim, height=h_dim, tagged_offset=h["tagged_offset"], payload_size=psz, payload_offset=poff, location=f"""Cyberface texture {num}""", allocation_size=psz, encoded_size=psz, uses_mip_chain=False, error=None, label=role_16, has_header=True, status="valid", mip_count=1, payload_bytes=None, role=role_16))

        if records_2k16:
            return records_2k16
    headers = scan_headers(data[:b0_len])
    if not headers or len(headers) < 3:
        return None
    face_headers = [h for h in headers if h["texture_hash"] in FACE_TEXTURE_HASHES or h["width"] in (256, 512)]
    if len(face_headers) < 3:
        return None
    num_headers = len(face_headers)
    hair_bytes = 65536
    if num_headers >= 5:
        h5 = face_headers[4]
        declared = int(h5.get("width", 128)) * int(h5.get("height", 128)) * 4
        if 0 < declared <= 65536 and declared != 65536:
            hair_bytes = declared
    layout = _resolve_2k20_tail_layout(data, b0_len, face_headers, hair_bytes)
    if layout is not None:
        t1_off = layout["t1"]
        t2_off = layout["t2"]
        t3_off = layout["t3"]
        t4_off = layout["t4"]
        t5_off = layout["t5"]
        hair_bytes = layout["hair_bytes"]
    elif num_headers >= 5:
        tail_start = len(data) - 303104
        t1_off = tail_start
        t2_off = len(data) - 237568
        t3_off = len(data) - 204800
        t4_off = len(data) - 73728
        t5_off = len(data) - 65536
        hair_bytes = 65536
    else:
        tail_start = len(data) - 237568
        t1_off = tail_start
        t2_off = len(data) - 172032
        t3_off = len(data) - 139264
        t4_off = len(data) - 8192
        t5_off = None
        hair_bytes = 0

    if t1_off < b0_len:
        return None
    records = []
    if t1_off + 65536 <= len(data):
        records.append(TextureRecord(number=1, header_offset=face_headers[0]["header_offset"], texture_hash=face_headers[0]["texture_hash"], format_id=16, width=256, height=256, tagged_offset=face_headers[0]["tagged_offset"], payload_size=65536, payload_offset=t1_off, location="Cyberface texture 1", allocation_size=65536, encoded_size=65536, uses_mip_chain=False, error=None, label="Face Diffuse", has_header=True, status="valid", mip_count=1, payload_bytes=None, role="Face Diffuse"))

    if t2_off + 32768 <= len(data):
        records.append(TextureRecord(number=2, header_offset=face_headers[1]["header_offset"] if len(face_headers) > 1 else -1, texture_hash=face_headers[1]["texture_hash"] if len(face_headers) > 1 else 0, format_id=15, width=256, height=256, tagged_offset=0, payload_size=32768, payload_offset=t2_off, location="Cyberface texture 2", allocation_size=32768, encoded_size=32768, uses_mip_chain=False, error=None, label="Material Map", has_header=True, status="valid", mip_count=1, payload_bytes=None, role="Material Map"))

    if t3_off + 131072 <= len(data):
        records.append(TextureRecord(number=3, header_offset=face_headers[2]["header_offset"] if len(face_headers) > 2 else -1, texture_hash=face_headers[2]["texture_hash"] if len(face_headers) > 2 else 0, format_id=7, width=256, height=256, tagged_offset=0, payload_size=131072, payload_offset=t3_off, location="Cyberface texture 3", allocation_size=131072, encoded_size=131072, uses_mip_chain=False, error=None, label="Normal Map", has_header=True, status="valid", mip_count=1, payload_bytes=None, role="Normal Map"))

    if t4_off + 8192 <= len(data):
        records.append(TextureRecord(number=4, header_offset=face_headers[3]["header_offset"] if len(face_headers) > 3 else -1, texture_hash=face_headers[3]["texture_hash"] if len(face_headers) > 3 else 0, format_id=15, width=128, height=128, tagged_offset=0, payload_size=8192, payload_offset=t4_off, location="Cyberface texture 4", allocation_size=8192, encoded_size=8192, uses_mip_chain=False, error=None, label="Detail Mask", has_header=True, status="valid", mip_count=1, payload_bytes=None, role="Detail Mask"))

    if t5_off is not None and t5_off + hair_bytes <= len(data):
        records.append(TextureRecord(number=5, header_offset=face_headers[4]["header_offset"], texture_hash=face_headers[4]["texture_hash"], format_id=1, width=128, height=128, tagged_offset=0, payload_size=hair_bytes, payload_offset=t5_off, location="Cyberface texture 5", allocation_size=hair_bytes, encoded_size=hair_bytes, uses_mip_chain=False, error=None, label="Hair / Beard Mask", has_header=True, status="valid", mip_count=1, payload_bytes=None, role="Hair Beard Mask"))
    return records if records else None


_PACKAGE_RESOLVED_TEXTURE_LIMIT = 12


def attach_scene_references(data: bytes, textures: list[TextureRecord],
    block_sizes: list[int] | None=None) -> list[TextureRecord]:
    """Replace/resolve scene-graph texture records with reference or tail records.

    If the cyberface container embeds its textures in the packed tail of Block 1,
    those records are returned directly with valid payload offsets. Otherwise,
    the records are tagged as references to be resolved against the OBB.

    Texture packages (GLOBAL.IFF: 300+ resolved textures across all blocks)
    are returned untouched — running the cyberface tail scan on them used to
    replace the entire catalog with 5 bogus EOF-anchored records, which is
    the reported "GLOBAL.IFF shows only 5 PNGs" regression.
    """
    resolved_count = sum(1 for texture in textures if texture.payload_offset is not None)
    if resolved_count >= _PACKAGE_RESOLVED_TEXTURE_LIMIT:
        return textures

    if block_sizes:
        tail_records = resolve_cyberface_tail(data, block_sizes)
        if tail_records:
            return tail_records
    references = _scene_reference_records(data)
    if not references:
        return textures
    kept = [
        texture
        for texture in textures
        if not (
            texture.has_header
            and texture.tagged_offset == 0
            and (
                texture.location == "inline after VCTEXTURE header"
                or texture.texture_hash in FACE_TEXTURE_HASHES
            )
        )
    ]
    merged = list(kept)
    existing_identities = {(texture.texture_hash, texture.format_id, texture.width, texture.height) for texture in kept}
    for reference in references:
        identity = (reference.texture_hash, reference.format_id, reference.width, reference.height)
        if identity in existing_identities:
            continue
        merged.append(reference)
        existing_identities.add(identity)
    return merged


def open_iff(path: Path) -> OpenedIff:
    path = path.resolve()
    if not path.is_file():
        raise ValueError(f"""IFF file was not found: {path}""")
    return open_iff_bytes(path.read_bytes(), path)


_FACE_BANK_CACHE: dict[tuple[str, int], dict[int, list[tuple[int, str, int, int]]]] = {}
_OBB_PARSE_CACHE: dict[str, object] = {}
_OBB_FULLY_SCANNED: set[tuple[str, int]] = set()


def _face_bank_index(obb_path: Path, needed: set[int]) -> dict[int, list[tuple[int, str, int, int]]]:
    'Map face-texture hash -> list of (entry_index, bank_name, width, height).'
    from . import obb as obbmod
    resolved = obb_path.resolve()
    key = (str(resolved), obb_path.stat().st_mtime_ns)
    cached = _FACE_BANK_CACHE.get(key)
    if cached is None:
        cached = {}
        _FACE_BANK_CACHE[key] = cached
    missing = {hash_value for hash_value in needed if hash_value not in cached}
    if not missing or key in _OBB_FULLY_SCANNED:
        return cached
    parsed = _OBB_PARSE_CACHE.get(str(resolved))
    if parsed is None:
        parsed = obbmod.Obb(resolved)
        _OBB_PARSE_CACHE[str(resolved)] = parsed
    def _scan_entry(entry):
        """Try to find needed hashes in one OBB entry."""
        if not missing:
            return
        name = obbmod.entry_name(entry.name_hash)
        try:
            bank = open_iff_bytes(parsed.read_entry_raw(entry), Path(name))
        except Exception:
            return
        for texture in bank.textures:
            if texture.payload_offset is None or texture.texture_hash not in needed:
                continue
            cached.setdefault(texture.texture_hash, []).append((entry.index, name, texture.width, texture.height))
            missing.discard(texture.texture_hash)
    for entry in parsed.entries:
        if not missing:
            break
        name = obbmod.entry_name(entry.name_hash)
        if len(name) != 8 or not all(character in "0123456789abcdef" for character in name):
            continue
        if not parsed.is_editable(entry):
            continue
        _scan_entry(entry)
    if missing:
        for entry in parsed.entries:
            if not missing:
                break
            name = obbmod.entry_name(entry.name_hash)
            if len(name) == 8 and all(character in "0123456789abcdef" for character in name):
                continue
            if not parsed.is_editable(entry):
                continue
            _scan_entry(entry)
    _OBB_FULLY_SCANNED.add(key)
    return cached


def _pick_face_bank_variant(candidates: list[tuple[int, str, int, int]], preferred_width: int, preferred_height: int) -> tuple[int, str]:
    """Choose the bank variant closest to the scene's own descriptor dims."""
    best = candidates[0]
    best_distance = abs(best[2] - preferred_width) + abs(best[3] - preferred_height)
    for candidate in candidates[1:]:
        distance = abs(candidate[2] - preferred_width) + abs(candidate[3] - preferred_height)
        if distance < best_distance:
            best = candidate
            best_distance = distance
        continue
    return (best[0], best[1])


def resolve_scene_references(opened: OpenedIff, obb_path: Path | list[Path] | tuple[Path, ...]) -> int:
    "Resolve the scene's reference records against OBB texture bank(s).\n\n    ``obb_path`` may be a single OBB path or a list of candidate paths\n    (patch OBB first, then main).  Each unresolved reference is looked up in\n    every OBB in order, so an atlas that only exists in the main OBB still\n    resolves even when a patch OBB is present.\n\n    Each reference's payload bytes are copied onto the record (bounded: a few\n    hundred KB per atlas), so the scene stays decodable without keeping the\n    bank in memory, and the record's format/dimensions are replaced with the\n    bank's actual values -- the scene descriptor only records the shader-side\n    usage, while the bank holds the real texture.  Returns how many records\n    were resolved.\n    "
    if isinstance(obb_path, (list, tuple)):
        resolved_total = 0
        for candidate in obb_path:
            remaining = [texture for texture in opened.textures if texture.status == "reference"]
            if not remaining:
                break
            try:
                resolved_total += _resolve_scene_references_in_obb(opened, Path(str(candidate)))
            except Exception:
                continue
        return resolved_total
    return _resolve_scene_references_in_obb(opened, Path(str(obb_path)))


def _resolve_scene_references_in_obb(opened: OpenedIff, obb_path: Path) -> int:
    references = [
        texture for texture in opened.textures
        if texture.status == "reference"
        and texture.location != "shader reference descriptor"
        and "shader reference" not in (texture.location or "").lower()
        and "shader reference" not in (texture.error or "").lower()
    ]
    if not references:
        return 0
    from . import obb as obbmod
    resolved = obb_path.resolve()
    if not resolved.is_file():
        return 0
    parsed = _OBB_PARSE_CACHE.get(str(resolved))
    if parsed is None:
        try:
            parsed = obbmod.Obb(resolved)
        except Exception:
            return 0
        _OBB_PARSE_CACHE[str(resolved)] = parsed
    needed = {texture.texture_hash for texture in references}
    index = _face_bank_index(resolved, needed)
    count = 0
    for texture in references:
        candidates = index.get(texture.texture_hash)
        if not candidates:
            dim_candidates = _dimension_bank_index(resolved, texture.width, texture.height)
            if dim_candidates:
                candidates = dim_candidates
            else:
                continue
        resolved_this = False
        for entry_index, bank_name, _bank_w, _bank_h in sorted(candidates, key=lambda c: abs(c[2] - texture.width) + abs(c[3] - texture.height)):
            if resolved_this:
                break
            try:
                bank = open_iff_bytes(parsed.read_entry_raw(parsed.entries[entry_index]), Path(bank_name))
            except Exception:
                continue
            sources_to_try = _gather_bank_sources(bank, texture)
            for source in sources_to_try:
                if resolved_this:
                    break
                payload = bytes(bank.data[source.payload_offset:source.payload_offset + source.payload_size])
                if len(payload) != source.payload_size:
                    continue
                if not _validate_resolved_payload(payload, source.format_id, source.width, source.height):
                    continue
                texture.payload_bytes = payload
                texture.format_id = source.format_id
                texture.width = source.width
                texture.height = source.height
                texture.payload_size = source.payload_size
                texture.payload_offset = 0
                texture.allocation_size = source.allocation_size
                texture.encoded_size = source.encoded_size
                texture.uses_mip_chain = source.uses_mip_chain
                texture.mip_count = source.mip_count
                texture.status = "valid"
                texture.error = None
                bank_position = next((idx for idx, t in enumerate(bank.textures) if t.texture_hash == texture.texture_hash), -1)
                if 0 <= bank_position < len(FACE_ROLE_SEQUENCE):
                    texture.role = FACE_ROLE_SEQUENCE[bank_position]
                elif not texture.role:
                    hash_role = FACE_ROLE_LABELS.get(texture.texture_hash, "")
                    if hash_role:
                        texture.role = hash_role
                texture.location = f"resolved from OBB texture bank {bank_name} (entry {entry_index})"
                if not texture.label:
                    texture.label = texture.role or "Face Texture (resolved from bank)"
                resolved_this = True
                count += 1
    return count


def _gather_bank_sources(bank: OpenedIff, texture: TextureRecord) -> list:
    'Collect bank texture sources to try for resolving a scene reference.\n\n    Returns candidates in priority order:\n    1. Exact hash + format match (most common, fastest)\n    2. Exact hash, any format (fallback when scene format differs from bank)\n    3. Matching dimensions, any hash (only in verified face/character banks)\n    '
    sources = []
    seen = set()
    for candidate in bank.textures:
        if candidate.texture_hash == texture.texture_hash and candidate.payload_offset is not None and candidate.format_id == texture.format_id:
            key = (candidate.payload_offset, candidate.format_id)
            if key not in seen:
                sources.append(candidate)
                seen.add(key)
    for candidate in bank.textures:
        if candidate.texture_hash == texture.texture_hash and candidate.payload_offset is not None:
            key = (candidate.payload_offset, candidate.format_id)
            if key not in seen:
                sources.append(candidate)
                seen.add(key)
    bank_hashes = {t.texture_hash for t in bank.textures}
    is_face_bank = bool(bank_hashes & FACE_TEXTURE_HASHES) or bool(CHARACTER_SHADER_RE.search(bank.data))
    if is_face_bank:
        for candidate in bank.textures:
            if candidate.payload_offset is not None and candidate.width == texture.width and candidate.height == texture.height:
                key = (candidate.payload_offset, candidate.format_id)
                if key not in seen:
                    sources.append(candidate)
                    seen.add(key)
    return sources


def _validate_resolved_payload(payload: bytes, format_id: int, width: int, height: int) -> bool:
    'Validate that decoded payload produces a spatially coherent texture.\n\n    Tries the declared format first, then alternative formats (e.g. ETC2-RGB\n    vs ETC2-RGBA8) to handle mismatched format headers. Returns True if\n    any format produces a plausible texture, False if all produce garbage.\n    '
    formats_to_try = [format_id]
    if format_id in (FORMAT_ETC1_RGB, 15):
        if 16 not in formats_to_try:
            formats_to_try.append(16)
    elif format_id == 16:
        for alt in (15, FORMAT_ETC1_RGB):
            if alt not in formats_to_try:
                formats_to_try.append(alt)
    for fmt in formats_to_try:
        try:
            if fmt in (FORMAT_RGBA8888, FORMAT_RGBA8888_RAW):
                rgba = payload[:width * height * 4]
            elif fmt == 2:
                rgba = decode_rgb565_rgba(payload, width, height)
            elif fmt == 4:
                rgba = decode_rgba4444_rgba(payload, width, height)
            elif fmt in (FORMAT_ETC1_RGB, 15):
                rgba = etc2.decode_etc2_rgb(payload, width, height)
            elif fmt == 16:
                rgba = etc2.decode_etc2_rgba8(payload, width, height)
            elif fmt in (FORMAT_RG8, FORMAT_EAC_RG11):
                from . import textureformats
                if len(payload) == width * height * 2:
                    rgba = textureformats.decode_rg8_normal(payload, width, height)
                else:
                    rgba = textureformats.decode_eac_rg11(payload, width, height)
            else:
                continue
            if _is_spatially_coherent(rgba, width, height):
                return True
        except Exception:
            continue
    return False


def _dimension_bank_index(obb_path: Path, width: int, height: int) -> list[tuple[int, str, int, int]]:
    "Find OBB banks containing any texture with matching dimensions.\n\n    Fallback when hash-based lookup fails: the scene descriptor may use a\n    different hash than the bank's own header, or the bank may not have been\n    indexed by ``_face_bank_index`` because its name was not 8-char hex.\n    "
    from . import obb as obbmod
    resolved = obb_path.resolve()
    parsed = _OBB_PARSE_CACHE.get(str(resolved))
    if parsed is None:
        try:
            parsed = obbmod.Obb(resolved)
        except Exception:
            return []
        _OBB_PARSE_CACHE[str(resolved)] = parsed
    results = []
    for entry in parsed.entries:
        if not parsed.is_editable(entry):
            continue
        try:
            bank = open_iff_bytes(parsed.read_entry_raw(entry), Path(obbmod.entry_name(entry.name_hash)))
        except Exception:
            continue
        bank_hashes = {t.texture_hash for t in bank.textures}
        if not (bank_hashes & FACE_TEXTURE_HASHES) and not CHARACTER_SHADER_RE.search(bank.data):
            continue
        for texture in bank.textures:
            if texture.payload_offset is not None and texture.width == width and texture.height == height:
                results.append((entry.index, obbmod.entry_name(entry.name_hash), width, height))
                break
    return results


def _is_spatially_coherent(rgba: bytes, width: int, height: int) -> bool:
    """Check whether decoded RGBA data looks like a real texture vs rainbow noise.

    Garbage data (mesh vertices/indices decoded as ETC2) produces high-frequency
    rainbow noise with chaotic channel variations and heavy block boundary jumps.
    Real textures have smooth gradients, consistent lighting, or recognizable color sets.
    """
    if len(rgba) < width * height * 4 or width < 4 or height < 4:
        return False
    pixel_count = width * height
    step = max(1, pixel_count // 384)
    sample_indices = list(range(0, pixel_count, step))
    if len(sample_indices) < 16:
        return False
    sampled_colors = set()
    neighbor_diffs = []
    extreme_jumps = 0
    for pixel in sample_indices:
        offset = pixel * 4
        r, g, b = rgba[offset], rgba[offset + 1], rgba[offset + 2]
        sampled_colors.add((r, g, b))
        if pixel % width < width - 1:
            n_offset = offset + 4
            nr, ng, nb = rgba[n_offset], rgba[n_offset + 1], rgba[n_offset + 2]
            diff = (abs(r - nr) + abs(g - ng) + abs(b - nb)) / 3.0
            neighbor_diffs.append(diff)
            if diff > 90:
                extreme_jumps += 1


    if not neighbor_diffs:
        return False
    mean_diff = sum(neighbor_diffs) / len(neighbor_diffs)
    extreme_jump_ratio = extreme_jumps / len(neighbor_diffs)
    unique_count = len(sampled_colors)
    if extreme_jump_ratio > 0.28:
        return False

    if mean_diff > 68.0:
        return False
    return True


def face_reference_summary(opened: OpenedIff) -> dict:
    'Per-reference status used by the UI (diagnostic detail view).'
    references = [texture for texture in opened.textures if texture.status == "reference"]
    return {
        "total": len(opened.textures),
        "references": len(references),
        "resolved": sum(1 for texture in opened.textures if texture.payload_bytes is not None),
        "unresolved": sum(1 for texture in references if texture.payload_bytes is None),
        "textures": [{
            "number": texture.number,
            "texture_hash": f"0x{texture.texture_hash:08X}",
            "format": FORMAT_NAMES.get(texture.format_id, f"Unknown ({texture.format_id})"),
            "width": texture.width,
            "height": texture.height,
            "role": texture.role,
            "resolution_status": "resolved" if texture.payload_bytes is not None else "unresolved",
            "error": texture.error,
        } for texture in references],
    }


def decode_rgb565_rgba(payload: bytes, width: int, height: int) -> bytes:
    output = bytearray(width * height * 4)
    target = 0
    for pixel, in struct.iter_unpack("<H", payload):
        red = pixel >> 11 & 31
        green = pixel >> 5 & 63
        blue = pixel & 31
        output[target] = red << 3 | red >> 2
        output[target + 1] = green << 2 | green >> 4
        output[target + 2] = blue << 3 | blue >> 2
        output[target + 3] = 255
        target += 4
    return bytes(output)


def decode_rgba4444_rgba(payload: bytes, width: int, height: int) -> bytes:
    output = bytearray(width * height * 4)
    target = 0
    for pixel, in struct.iter_unpack("<H", payload):
        output[target] = (pixel >> 12 & 15) * 17
        output[target + 1] = (pixel >> 8 & 15) * 17
        output[target + 2] = (pixel >> 4 & 15) * 17
        output[target + 3] = (pixel & 15) * 17
        target += 4
    return bytes(output)


def encode_rgb565(rgba: bytes, width: int, height: int) -> bytes:
    output = bytearray(width * height * 2)
    target = 0
    for source in range(0, len(rgba), 4):
        red, green, blue = rgba[source], rgba[source + 1], rgba[source + 2]
        value = red >> 3 << 11 | green >> 2 << 5 | blue >> 3
        struct.pack_into("<H", output, target, value)
        target += 2
    return bytes(output)


def encode_rgba4444(rgba: bytes, width: int, height: int) -> bytes:
    output = bytearray(width * height * 2)
    target = 0
    for source in range(0, len(rgba), 4):
        red, green, blue, alpha = (rgba[source], rgba[source + 1], rgba[source + 2], rgba[source + 3])
        value = red >> 4 << 12 | green >> 4 << 8 | blue >> 4 << 4 | alpha >> 4
        struct.pack_into("<H", output, target, value)
        target += 2
    return bytes(output)


def sanitized_rgba_bytes(rgba: bytes) -> bytes:
    output = bytearray(rgba)
    for offset in range(0, len(output), 4):
        if output[offset + 3] == 0:
            output[offset:offset + 3] = b"\x00\x00\x00"
        continue
    return bytes(output)


def encode_level(rgba: bytes, format_id: int, width: int, height: int) -> bytes:
    if format_id in (FORMAT_RGBA8888, FORMAT_RGBA8888_RAW):
        return bytes(rgba[:width * height * 4])

    if format_id == 2:
        return encode_rgb565(rgba, width, height)

    if format_id == 4:
        return encode_rgba4444(rgba, width, height)

    if format_id in (FORMAT_ETC1_RGB, 15, 16):
        clean = sanitized_rgba_bytes(rgba)
        if format_id == 16:
            return etc2.encode_etc2_rgba8(clean, width, height)
        return etc2.encode_etc2_rgb(clean, width, height)

    if format_id in (FORMAT_RG8, FORMAT_EAC_RG11):
        from . import textureformats
        return textureformats.encode_rg8_normal(sanitized_rgba_bytes(rgba), width, height)
    raise ValueError(f"""unsupported texture format {format_id}""")


def downscale_half(rgba: bytes, width: int, height: int) -> bytes:
    """Box-filter 2x downscale (used for regenerated mip chains)."""
    new_width = max(1, (width + 1) // 2)
    new_height = max(1, (height + 1) // 2)
    output = bytearray(new_width * new_height * 4)
    target = 0
    for y in range(new_height):
        y0 = y * 2
        y1 = min(y * 2 + 1, height - 1)
        for x in range(new_width):
            x0 = x * 2
            x1 = min(x * 2 + 1, width - 1)
            r = g = b = a = 0
            count = 0
            for yy in range(y0, y1 + 1):
                row = yy * width * 4
                for xx in range(x0, x1 + 1):
                    offset = row + xx * 4
                    r += rgba[offset]
                    g += rgba[offset + 1]
                    b += rgba[offset + 2]
                    a += rgba[offset + 3]
                    count += 1
            output[target] = r // count
            output[target + 1] = g // count
            output[target + 2] = b // count
            output[target + 3] = a // count
            target += 4
    return bytes(output)


def encode_texture(rgba: bytes, texture: TextureRecord) -> bytes:
    if not texture.uses_mip_chain:
        return encode_level(rgba, texture.format_id, texture.width, texture.height)
    width, height = texture.width, texture.height
    output = bytearray()
    level_rgba = rgba
    max_alloc = texture.allocation_size or texture.encoded_size or float("inf")
    while True:
        level_bytes = encode_level(level_rgba, texture.format_id, width, height)
        if len(output) + len(level_bytes) > max_alloc and len(output) > 0:
            break
        output.extend(level_bytes)
        if width == 1 and height == 1:
            break
        level_rgba = downscale_half(level_rgba, width, height)
        width = max(1, width // 2)
        height = max(1, height // 2)
    if texture.allocation_size and len(output) <= texture.allocation_size:
        texture.encoded_size = len(output)
    elif texture.encoded_size and len(output) != texture.encoded_size:
        texture.encoded_size = len(output)
    return bytes(output)


def analyze_unknown_texture(opened: OpenedIff, texture: TextureRecord) -> dict:
    """Run binary analysis on a texture whose IFF format id is unknown.

    The IFF header may carry a format id the scanner has never seen, or the
    payload may be a standard container (DDS/KTX/PNG/...) re-packed into the
    IFF.  This inspects the actual payload bytes and returns ranked decode
    candidates with confidence levels; the best one is also cached on the
    record so decode/preview/export use it consistently.
    """
    from . import textureformats
    if texture.payload_offset is None:
        return {"status": "unknown", "best": None, "candidates": []}
    start = texture.payload_offset
    payload = bytes(opened.data[start:start + texture.payload_size])
    if not payload:
        return {"status": "unknown", "best": None, "candidates": []}
    prefer = ("ETC2", "ETC1", "ETC2A1", "ETC2A8", "EACR", "EACRG")
    analysis = textureformats.analyze_payload(payload, hint_width=texture.width, hint_height=texture.height, prefer=prefer)
    best = analysis.get("best")
    if best is not None:
        if best.get("format"):
            texture.detected = best["format"]
            texture.confidence = best.get("confidence", "low")
            texture.alternative_candidates = [c["format"] for c in analysis.get("candidates", [])[:5]]
    return analysis


def decode_texture_rgba(opened: OpenedIff, texture: TextureRecord) -> bytes:
    payload = texture_payload_bytes(opened, texture)
    if len(payload) != texture.payload_size:
        raise ValueError("texture payload is truncated")

    if texture.format_id in (FORMAT_RGBA8888, FORMAT_RGBA8888_RAW):
        expected = texture.width * texture.height * 4
        if len(payload) == expected:
            return payload

        if len(payload) == texture.width * texture.height:
            rgba = bytearray(expected)
            for i in range(texture.width * texture.height):
                v = payload[i]
                base = i * 4
                rgba[base] = rgba[base + 1] = rgba[base + 2] = v
                rgba[base + 3] = 255
            return bytes(rgba)

        if len(payload) == texture.width * texture.height // 2:
            return etc2.decode_etc2_rgb(payload, texture.width, texture.height)

        if len(payload) < expected:
            return payload + b"\x00" * (expected - len(payload))
        return payload[:expected]

    if texture.format_id == 2:
        return decode_rgb565_rgba(payload, texture.width, texture.height)

    if texture.format_id == 4:
        return decode_rgba4444_rgba(payload, texture.width, texture.height)

    if texture.format_id in (FORMAT_ETC1_RGB, 15):
        return etc2.decode_etc2_rgb(payload, texture.width, texture.height)

    if texture.format_id == 16:
        return etc2.decode_etc2_rgba8(payload, texture.width, texture.height)

    if texture.format_id in (FORMAT_RG8, FORMAT_EAC_RG11):
        from . import textureformats
        if len(payload) == texture.width * texture.height * 2:
            return textureformats.decode_rg8_normal(payload, texture.width, texture.height)
        return textureformats.decode_eac_rg11(payload, texture.width, texture.height)

    if texture.format_id == 1:
        expected_rgba = texture.width * texture.height * 4
        if len(payload) >= expected_rgba:
            return payload[:expected_rgba]
        expected_alpha = texture.width * texture.height
        p = payload[:expected_alpha]
        rgba = bytearray(expected_rgba)
        for i in range(len(p)):
            v = p[i]
            rgba[i * 4] = v
            rgba[i * 4 + 1] = v
            rgba[i * 4 + 2] = v
            rgba[i * 4 + 3] = 255
        return bytes(rgba)
    from . import textureformats
    analysis = analyze_unknown_texture(opened, texture)
    best = analysis.get("best")
    if best is not None:
        if best.get("format"):
            if best.get("decode"):
                fmt = best["format"]
                return textureformats.decode_candidate(payload, fmt, best.get("width", texture.width), best.get("height", texture.height))

    if best is not None:
        if best.get("format"):
            if not best.get("decode"):
                raise ValueError(f"unable to decode texture: detected {best['format']} ({best.get('confidence', 'low')} confidence) but this build has no decoder for it; use Export Raw Resource to keep the original bytes")
    raise ValueError(f"""unsupported texture format {texture.format_id} and no recognizable binary signature, size match or coherent pixel layout in the payload; use Export Raw Resource to keep the original bytes""")


def texture_filename(texture: TextureRecord) -> str:
    if texture.label:
        label = re.sub("[^A-Za-z0-9._-]+", "_", texture.label).strip("._")
        return f"""texture_{texture.number:02d}_{label}_{texture.width}x{texture.height}_fmt{texture.format_id}.png"""
    return f"""texture_{texture.number:02d}_h{texture.texture_hash:08X}_{texture.width}x{texture.height}_fmt{texture.format_id}.png"""


def texture_png(opened: OpenedIff, texture: TextureRecord) -> bytes:
    """Decode one texture and return PNG bytes."""
    rgba = decode_texture_rgba(opened, texture)
    return pngio.write_png_rgba(texture.width, texture.height, rgba)


def texture_payload_bytes(opened: OpenedIff, texture: TextureRecord) -> bytes:
    """The texture's exact payload bytes, wherever they live.

    Regular records are sliced from the opened IFF; scene references resolved
    against a texture bank carry their payload copied onto the record
    (``payload_bytes``) so they decode without keeping the bank in memory.
    """
    if texture.payload_bytes is not None:
        return texture.payload_bytes

    if texture.payload_offset is None:
        raise ValueError(texture.error or "texture payload location is unknown")
    start = texture.payload_offset
    payload = bytes(opened.data[start:start + texture.payload_size])
    if len(payload) != texture.payload_size:
        raise ValueError("texture payload is truncated")
    return payload


def raw_resource_to_file(opened: OpenedIff, texture: TextureRecord, path: Path) -> int:
    """Write the original binary resource bytes to ``path``.

    The raw payload is the exact bytes the game stores (compressed texture
    data, container, whatever the resource actually is).  Exporting it is
    always possible, even when decoding fails, so no resource is ever lost.
    """
    raw = texture_payload_bytes(opened, texture)
    return path.write_bytes(raw)


def texture_png_to_file(opened: OpenedIff, texture: TextureRecord, path: Path) -> int:
    """Decode one texture and write the PNG to ``path`` with bounded memory.

    The RGBA buffer is the only large allocation: the PNG itself is streamed
    to disk row by row instead of being built in memory, so exporting very
    large textures (4096x4096+) does not triple the peak memory the way
    :func:`texture_png` does.
    """
    rgba = decode_texture_rgba(opened, texture)
    return pngio.write_png_rgba_to_file(path, texture.width, texture.height, rgba)


def texture_thumb_to_file(opened: OpenedIff, texture: TextureRecord, path: Path,
    max_dim: int=128) -> int:
    """Decode one texture and write a downscaled PNG (for thumbnails).

    Block-based formats (ETC2, RGB565, RGBA4444) cannot be partially decoded,
    so the full RGBA buffer is still produced once, but the PNG written to
    ``path`` is box-filtered down to ``max_dim`` on its longest side first.
    The PNG encode dominates the pure-Python cost, and the thumbnail is
    ~(scale)^2 smaller, so generating a strip of thumbnails for a large IFF
    (e.g. the portrait bank b9610aac.iff) is far cheaper than writing a
    full-resolution PNG per texture and downsampling it in the app afterwards.
    """
    rgba = decode_texture_rgba(opened, texture)
    width, height = texture.width, texture.height
    while max(width, height) > max_dim:
        rgba = downscale_half(rgba, width, height)
        width = max(1, (width + 1) // 2)
        height = max(1, (height + 1) // 2)
    return pngio.write_png_rgba_to_file(path, width, height, rgba)


def _alpha_stats(rgba: bytes) -> tuple[float, float]:
    """Return (transparent_ratio, opaque_ratio) for an RGBA byte buffer.

    ``transparent`` counts pixels with alpha < 8; ``opaque`` counts pixels
    with alpha == 255.
    """
    total = max(1, len(rgba) // 4)
    transparent = 0
    opaque = 0
    for offset in range(3, len(rgba), 4):
        alpha = rgba[offset]
        if alpha < 8:
            transparent += 1
            continue

        if alpha == 255:
            opaque += 1
        continue
    return (transparent / total, opaque / total)


def _preserve_original_alpha(rgba: bytes, opened: OpenedIff, texture: TextureRecord) -> tuple[bytes, dict | None]:
    """Re-apply the original alpha mask when the PNG lost its transparency.

    Logo and portrait atlases are masked by their alpha channel (logos are
    ~30% transparent, portraits ~55%).  Editors and downloaded artwork
    routinely flatten that channel to fully opaque, which makes the game
    render the whole quad -- including the white RGB stored under the old
    transparent pixels -- i.e. the classic "logo/portrait turns white"
    report.  When the target texture is genuinely transparent and the
    replacement is (nearly) fully opaque, treat the PNG's alpha as lost and
    copy the original alpha channel back over the new RGB.  Returns the
    (possibly corrected) RGBA buffer and a report dict, or (rgba, None)
    when no preservation happened.
    """
    try:
        original_rgba = decode_texture_rgba(opened, texture)
    except Exception:
        return (rgba, None)

    if len(original_rgba) != len(rgba):
        return (rgba, None)
    [original_transparent, _original_opaque] = _alpha_stats(original_rgba)
    [_png_transparent, png_opaque] = _alpha_stats(rgba)
    if original_transparent < 0.02 or png_opaque < 0.98:
        return (rgba, None)
    output = bytearray(rgba)
    for offset in range(3, len(output), 4):
        output[offset] = original_rgba[offset]
    return (bytes(output), {"applied": True, "original_transparent_ratio": round(original_transparent, 4), "reason": "replacement PNG was fully opaque but the original texture uses its alpha channel as a mask; the original alpha was preserved to avoid a solid (white) result in-game"})


def import_png_bytes(opened: OpenedIff, texture: TextureRecord, png_bytes: bytes) -> dict:
    """Replace one texture from PNG bytes; identical rules to the desktop tool."""
    if texture.payload_offset is None:
        raise ValueError(texture.error or "texture payload location is unknown")

    if texture.payload_bytes is not None:
        raise ValueError("this texture is a scene reference whose data lives in a separate texture bank; open that bank's IFF in the OBB to replace it")
    width, height, rgba = pngio.read_png_rgba(png_bytes)
    if (width, height) != (texture.width, texture.height):
        raise ValueError(f"""edited PNG is {width}x{height}; expected {texture.width}x{texture.height}""")
    [rgba, alpha_report] = _preserve_original_alpha(rgba, opened, texture)
    if texture.uses_mip_chain and texture.allocation_size and (mip_chain_size(texture.format_id, texture.width, texture.height) > texture.allocation_size):
        texture.uses_mip_chain = False
        texture.mip_count = 1
        texture.encoded_size = texture.payload_size
    encoded = encode_texture(rgba, texture)
    if len(encoded) > texture.allocation_size:
        raise ValueError(f"""encoded texture needs {len(encoded)} bytes but its IFF allocation contains only {texture.allocation_size} bytes""")
    start = texture.payload_offset
    replacement_offsets = [start]
    if texture.texture_hash in LINKED_RUNTIME_TEXTURE_HASHES:
        original = bytes(opened.data[start:start + len(encoded)])
        if len(original) != len(encoded):
            raise ValueError("linked texture payload is truncated")
        replacement_offsets = []
        search = 0
        while True:
            position = opened.data.find(original, search)
            if position < 0:
                break
            replacement_offsets.append(position)
            search = position + len(original)

        if start not in replacement_offsets:
            raise ValueError("selected linked texture payload was not found in its IFF")

    for replacement_offset in replacement_offsets:
        end = replacement_offset + len(encoded)
        if replacement_offset < 0 or end > len(opened.data):
            raise ValueError("linked texture replacement is outside the IFF")
        opened.data[replacement_offset:end] = encoded
    return {"texture": texture.number, "encoded_size": len(encoded), "mip_chain": texture.uses_mip_chain, "linked_payload_copies_replaced": len(replacement_offsets), "alpha_preserved": alpha_report}


def compress_zlib_max(data: bytes | bytearray) -> bytes:
    candidates = [zlib.compress(data, level=9)]
    for memory_level in (8, 9):
        for strategy in (zlib.Z_DEFAULT_STRATEGY, zlib.Z_FILTERED):
            compressor = zlib.compressobj(level=9, method=zlib.DEFLATED, wbits=15, memLevel=memory_level, strategy=strategy)
            candidates.append(compressor.compress(data) + compressor.flush())
    return min(candidates, key=len)


def rebuild_compressed_iff(opened: OpenedIff) -> tuple[bytes, str, int]:
    info = opened.wrapper_info if hasattr(opened, "wrapper_info") else None
    if info is None:
        return (bytes(opened.data), "decompressed", 0)

    if len(opened.data) != len(opened.original_data):
        raise ValueError("edited decompressed IFF changed size")
    prepared = []
    preserve_layout = True
    changed_blocks = 0
    for block in info.blocks:
        start = block.unpacked_offset
        end = start + block.unpacked_size
        modified = bytes(opened.data[start:end])
        original = opened.original_data[start:end]
        changed = modified != original
        packed = compress_zlib_max(modified) if changed else None
        if changed:
            changed_blocks += 1
            if 16 + len(packed) > block.stored_size:
                preserve_layout = False
        prepared.append((block, packed, changed))

    if changed_blocks == 0:
        return (opened.source_raw, "unchanged", 0)

    if preserve_layout:
        pieces = [opened.source_raw[:info.first_offset]]
        for block, packed, changed in prepared:
            if not changed:
                pieces.append(opened.source_raw[block.position:block.position + block.stored_size])
                continue

            assert packed is not None
            compact_size = 16 + len(packed)
            pieces.append(TYPE_ZLIB + struct.pack(">III", block.unpacked_size, block.declared_stored_size, block.flags) + packed + b"\x00" * (block.stored_size - compact_size))
        last = info.blocks[-1]
        tail = last.position + last.stored_size
        pieces.append(opened.source_raw[tail:])
        rebuilt = b"".join(pieces)
        return (rebuilt, "compressed layout preserved", changed_blocks)
    compact_blocks = []
    for block, packed, changed in prepared:
        if not changed:
            compact_blocks.append(opened.source_raw[block.position:block.position + block.stored_size])
            continue

        assert packed is not None
        compact_blocks.append(TYPE_ZLIB + struct.pack(">III", block.unpacked_size, 16 + len(packed), block.flags) + packed)

    if info.compressed_wrapper:
        prefix = bytearray(opened.source_raw[:info.first_offset])
        position = info.first_offset
        for index, block_bytes in enumerate(compact_blocks):
            descriptor = 44 + index * 56
            if descriptor + 48 > len(prefix):
                raise ValueError("compressed IFF wrapper has no matching block descriptor")
            struct.pack_into("<I", prefix, descriptor + 36, position)
            struct.pack_into("<I", prefix, descriptor + 44, len(block_bytes))
            position += len(block_bytes)
        rebuilt_array = bytearray(prefix + b"".join(compact_blocks))
        struct.pack_into(">I", rebuilt_array, 8, len(rebuilt_array))
        rebuilt = bytes(rebuilt_array)
    else:
        rebuilt = b"".join(compact_blocks)
    return (rebuilt, "compressed layout compacted", changed_blocks)


def save_iff_copy(opened: OpenedIff, destination: Path) -> dict:
    """Save a verified edited copy; never overwrites the source."""
    destination = destination.resolve()
    rebuilt, mode, changed_blocks = rebuild_compressed_iff(opened)
    check_data, check_sizes, _wrapper, _info = decompress_wrapper(rebuilt)
    if check_data != bytes(opened.data):
        raise ValueError("saved IFF verification failed: decompressed bytes differ")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".partial")
    try:
        temporary.unlink(missing_ok=True)
    except OSError:
        pass

    try:
        temporary.write_bytes(rebuilt)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    sidecar = destination.with_suffix(destination.suffix + ".viewer.json")
    sidecar.write_text(json.dumps({"source_iff": str(opened.path), "saved_iff": str(destination), "container_mode": mode, "changed_compressed_blocks": changed_blocks, "decompressed_size": len(opened.data), "decompressed_block_sizes": check_sizes if hasattr(opened, "wrapper_info") and opened.wrapper_info is not None else opened.block_sizes, "verification": "PASS"}, indent=2) + "\n", encoding="utf-8")
    return {"output": str(destination), "sidecar": str(sidecar), "mode": mode, "changed_blocks": changed_blocks, "size": len(rebuilt)}
