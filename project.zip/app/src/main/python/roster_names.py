"""
RosterNameResolver port — resolves string refs → real names.

Combine with:
  roster_crypto.py  → decrypt .ros to packed binary
  roster_map.py     → parse player/team tables
  roster_names.py   → resolve names  (this file)
"""
import json

STRING_INDEX_MASK = 0x1FFFFF       # 21 bits
STRING_SECTION    = 48
STANDARD_POOL_BIT_OFFSET = 36432787
MYCAREER_POOL_BIT_OFFSET = 71905107

ANCHOR_TEAM_SLOTS = [0, 1, 2, 4, 13, 28]
ANCHOR_TEAM_NAMES = ["76ers", "Bucks", "Bulls", "Celtics", "Lakers", "Warriors"]


def _read_bits(data, bit_pos, width):
    val = 0
    for i in range(width):
        bp = bit_pos + i
        bit = (data[bp >> 3] >> (7 - (bp & 7))) & 1
        val = (val << 1) | bit
    return val & 0xFFFFFFFF


def _shifted_byte(data, i, shift):
    if i < 0 or i >= len(data):
        return -1
    b0 = data[i] & 0xFF
    if shift == 0:
        return b0
    if i + 1 >= len(data):
        return -1
    return ((b0 << shift) & 0xFF) | ((data[i + 1] & 0xFF) >> (8 - shift))


def is_supported_string_ref(ref):
    return ((ref >> 21) & 0xFF) == STRING_SECTION


def read_roster_string(data, pool_bit_offset, string_ref):
    """Read UTF-16 LE string from the pool at the given ref."""
    if not is_supported_string_ref(string_ref):
        return ""
    idx = string_ref & STRING_INDEX_MASK
    start = pool_bit_offset + idx * 16
    total_bits = len(data) * 8
    if start < 0 or start + 16 > total_bits:
        return ""

    chars = []
    for i in range(96):
        bp = start + i * 16
        if bp + 16 > total_bits:
            break
        raw = _read_bits(data, bp, 16)
        # Java reads MSB-first; on-disk is LE — byte-swap to recover
        code = ((raw & 0xFF) << 8) | ((raw >> 8) & 0xFF)
        if code == 0 or code == 0xFFFF:
            break
        if code < 32 and code != 9:
            return ""
        chars.append(chr(code))
    return "".join(chars)


def _clean(s):
    if not s:
        return ""
    s = s.strip()
    out = []
    pending = False
    for c in s:
        if c.isspace():
            if out:
                pending = True
        else:
            if pending and out:
                out.append(' ')
            pending = False
            out.append(c)
    return "".join(out).strip()


def _validate_pool(data, pool_offset, teams):
    """Sanity check: >=26 teams should resolve to sane strings."""
    sane = 0
    for i in range(min(30, len(teams))):
        t = teams[i]
        name = _clean(read_roster_string(data, pool_offset, t["teamNameRef"]))
        abbr = _clean(read_roster_string(data, pool_offset, t["abbreviationRef"]))
        if 2 <= len(name) <= 32 and 2 <= len(abbr) <= 5:
            sane += 1
    return sane >= 26


def _find_pool_by_anchors(data, teams):
    """Slow fallback: scan for known team names in the raw bytes."""
    for i, slot in enumerate(ANCHOR_TEAM_SLOTS):
        if slot >= len(teams):
            continue
        ref = teams[slot]["teamNameRef"]
        if not is_supported_string_ref(ref):
            continue
        needle = ANCHOR_TEAM_NAMES[i].encode("utf-16-le")
        offset_in_pool = (ref & STRING_INDEX_MASK) * 16
        for shift in range(8):
            for pos in range(0, len(data) - len(needle)):
                if all(_shifted_byte(data, pos + k, shift) == b
                       for k, b in enumerate(needle)):
                    candidate = (pos * 8 + shift) - offset_in_pool
                    if 0 <= candidate < len(data) * 8:
                        if _validate_pool(data, candidate, teams):
                            return candidate
    return -1


def find_pool_offset(data, teams):
    if _validate_pool(data, STANDARD_POOL_BIT_OFFSET, teams):
        return STANDARD_POOL_BIT_OFFSET
    if _validate_pool(data, MYCAREER_POOL_BIT_OFFSET, teams):
        return MYCAREER_POOL_BIT_OFFSET
    return _find_pool_by_anchors(data, teams)


def _join_player_name(first, last, slot):
    f, l = _clean(first), _clean(last)
    if not f and not l:
        return "Player %04d" % slot
    if not f: return l
    if not l: return f
    return f + " " + l


def _join_team_name(city, team, display):
    c, t, d = _clean(city), _clean(team), _clean(display)
    if c and t:
        if t.lower().startswith(c.lower() + " "):
            return t
        return c + " " + t
    return t or c or d or ""


def resolve_names(data, parsed):
    """Fill in name fields for players and teams. Mutates parsed in-place."""
    players = parsed["players"]
    teams = parsed["teams"]

    pool_offset = find_pool_offset(data, teams)
    if pool_offset < 0:
        for p in players:
            p["firstName"] = p["lastName"] = ""
            p["displayName"] = "Player %04d" % p["slot"]
        for t in teams:
            t["teamName"] = t["abbreviation"] = t["cityName"] = ""
            t["fullName"] = "Team %02d" % t["slot"]
        return {"poolBitOffset": -1, "resolvedPlayers": 0, "resolvedTeams": 0}

    rp = rt = 0
    for t in teams:
        t["teamName"]     = _clean(read_roster_string(data, pool_offset, t["teamNameRef"]))
        t["abbreviation"] = _clean(read_roster_string(data, pool_offset, t["abbreviationRef"]))
        t["cityName"]     = _clean(read_roster_string(data, pool_offset, t["cityRef"]))
        disp = _clean(read_roster_string(data, pool_offset, t["displayRef"]))
        full = _join_team_name(t["cityName"], t["teamName"], disp)
        if full: rt += 1
        else: full = "Team %02d" % t["slot"]
        t["fullName"] = full

    for p in players:
        p["firstName"] = _clean(read_roster_string(data, pool_offset, p["firstNameRef"]))
        p["lastName"]  = _clean(read_roster_string(data, pool_offset, p["lastNameRef"]))
        p["displayName"] = _join_player_name(p["firstName"], p["lastName"], p["slot"])
        if p["firstName"] or p["lastName"]: rp += 1

    return {"poolBitOffset": pool_offset,
            "resolvedPlayers": rp, "resolvedTeams": rt}


# ─────────────────────────────────────────────────────────────
# Bridge functions for Java
# ─────────────────────────────────────────────────────────────
def load_roster_full(path):
    from roster_crypto import decode_roster
    from roster_map import parse_roster
    with open(path, "rb") as f:
        raw = f.read()
    decrypted, mode = decode_roster(raw)
    parsed = parse_roster(decrypted)
    parsed["cryptoMode"] = mode
    parsed["nameStats"] = resolve_names(decrypted, parsed)
    return parsed


def list_players_from_java(path):
    try:
        parsed = load_roster_full(path)
        out = [{
            "slot": p["slot"],
            "firstName": p["firstName"],
            "lastName": p["lastName"],
            "displayName": p["displayName"],
            "jerseyNumber": p["jerseyNumber"],
            "cyberfaceId": p["cyberfaceId"],
            "portraitId": p["portraitId"],
            "activeTeamSlot": p["activeTeamSlot"],
        } for p in parsed["players"]]
        return json.dumps(out)
    except Exception as e:
        return "ERROR: " + str(e)


def list_teams_from_java(path):
    try:
        parsed = load_roster_full(path)
        out = [{
            "slot": t["slot"],
            "teamName": t["teamName"],
            "abbreviation": t["abbreviation"],
            "cityName": t["cityName"],
            "fullName": t["fullName"],
            "playerCount": t["playerCount"],
            "playerSlots": t["playerSlots"],
        } for t in parsed["teams"]]
        return json.dumps(out)
    except Exception as e:
        return "ERROR: " + str(e)