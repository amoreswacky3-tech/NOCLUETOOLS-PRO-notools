"""
RosterPlayerMap port — bit-level reader for 2K20 .ros files.
Companion to roster_crypto.py (which decrypts first).
"""
import struct

PLAYER_TAG_BASE     = 543162368       # 0x20600000
PLAYER_STRIDE_BITS  = 4075
TEAM_TAG_BASE       = 557842432       # 0x21400000
TEAM_STRIDE_BITS    = 6356
TEAM_PLAYER_REF_COUNT = 20

# Player field bit offsets (relative to record start, after the 32-bit tag)
P_FIRST_REF_BITS     = 0
P_FIRST_CRC_BITS     = 96
P_LAST_REF_BITS      = 0
P_LAST_CRC_BITS      = 64
P_PORTRAIT_BITS      = 256
P_JERSEY_BITS        = 301
P_CF_BITS            = 528
P_BODY_TYPE_BITS     = 1461
P_MUSCLE_TYPE_BITS   = 1463
P_SKIN_TONE_BITS     = 1464
P_EYE_COLOR_BITS     = 1477

# Team field bit offsets
T_TEAM_NAME_REF_BITS    = 640
T_TEAM_ABBREV_REF_BITS  = 672
T_TEAM_CITY_REF_BITS    = 704
T_TEAM_DISPLAY_REF_BITS = 736
T_TEAM_NAME_CRC_BITS    = 768
T_TEAM_SHORT_CRC_BITS   = 800
T_TEAM_PLAYER_COUNT_BITS = 1000


def read_bits(data, bit_pos, width):
    """MSB-first bit read (matches Java readBits)."""
    if width < 1 or width > 32:
        raise ValueError("width")
    total = len(data) * 8
    if bit_pos < 0 or bit_pos + width > total:
        raise ValueError("bitPosition")
    val = 0
    for i in range(width):
        bp = bit_pos + i
        bit = (data[bp >> 3] >> (7 - (bp & 7))) & 1
        val = (val << 1) | bit
    return val & 0xFFFFFFFF


def _shifted_byte(data, i, shift):
    """Read a byte from a bit-shifted position."""
    return (((data[i] & 0xFF) << shift) & 0xFF) | ((data[i+1] & 0xFF) >> (8 - shift))


def _verify_sequence(data, start_bit, tag_base, stride, count):
    total = len(data) * 8
    for i in range(count):
        bp = start_bit + i * stride
        if bp + 32 > total:
            return False
        tag = read_bits(data, bp, 32)
        expected = tag_base | (i & 0xFFFFF)
        if tag != expected:
            return False
    return True


def _find_sequential_table(data, tag_base, stride, min_records):
    """Scan for the tag signature at byte-aligned positions, then bit-shifted."""
    # Byte 0 of tag_base big-endian
    b0 = (tag_base >> 24) & 0xFF
    b1 = (tag_base >> 16) & 0xFF
    b2 = (tag_base >> 8)  & 0xFF
    b3 = tag_base         & 0xFF
    pattern = bytes([b0, b1, b2, b3])

    # Byte-aligned scan
    for i in range(0, len(data) - 4):
        if data[i:i+4] == pattern:
            bp = i * 8
            if _verify_sequence(data, bp, tag_base, stride, min_records):
                return bp

    # Bit-shifted scan (1..7)
    for shift in range(1, 8):
        for i in range(0, len(data) - 4):
            if (_shifted_byte(data, i,     shift) == b0
                    and _shifted_byte(data, i + 1, shift) == b1
                    and _shifted_byte(data, i + 2, shift) == b2
                    and _shifted_byte(data, i + 3, shift) == b3):
                bp = i * 8 + shift
                if _verify_sequence(data, bp, tag_base, stride, min_records):
                    return bp

    return -1


def _count_sequential_records(data, start_bit, tag_base, stride, max_count):
    total = len(data) * 8
    count = 0
    while count < max_count:
        bp = start_bit + count * stride
        if bp + 32 > total:
            break
        tag = read_bits(data, bp, 32)
        expected = tag_base | (count & 0xFFFFF)
        if tag != expected:
            break
        count += 1
    return count


def parse_roster(decrypted_bytes):
    """
    Parse a decrypted .ros file → dict with players[] and teams[].
    Returns:
      {
        "playerTableBitOffset": int,
        "teamTableBitOffset": int,
        "players": [ { slot, cyberfaceId, portraitId, jerseyNumber, bodyType,
                       muscleType, skinTone, eyeColor, firstNameRef, lastNameRef,
                       firstNameCrc, lastNameCrc }, ... ],
        "teams":   [ { slot, playerCount, playerSlots[], teamNameRef,
                       abbreviationRef, cityRef, displayRef,
                       teamNameCrc, shortNameCrc }, ... ],
      }
    """
    data = bytes(decrypted_bytes)
    if len(data) < 1024:
        raise ValueError("Decoded roster payload is empty.")

    # Find player table
    player_start = _find_sequential_table(data, PLAYER_TAG_BASE, PLAYER_STRIDE_BITS, 3)
    if player_start < 0:
        raise ValueError("PLAYERDATA table signature was not found.")

    player_count = _count_sequential_records(data, player_start, PLAYER_TAG_BASE,
                                             PLAYER_STRIDE_BITS, 10000)
    if player_count < 100:
        raise ValueError("PLAYERDATA table too small: %d" % player_count)

    players = []
    for i in range(player_count):
        base = player_start + i * PLAYER_STRIDE_BITS + 32   # skip tag
        players.append({
            "slot":          i,
            "cyberfaceId":   read_bits(data, base + P_CF_BITS, 16),
            "portraitId":    read_bits(data, base + P_PORTRAIT_BITS, 16),
            "jerseyNumber":  read_bits(data, base + P_JERSEY_BITS, 7),
            "bodyType":      read_bits(data, base + P_BODY_TYPE_BITS, 2),
            "muscleType":    read_bits(data, base + P_MUSCLE_TYPE_BITS, 1),
            "skinTone":      read_bits(data, base + P_SKIN_TONE_BITS, 3),
            "eyeColor":      read_bits(data, base + P_EYE_COLOR_BITS, 3),
            "lastNameRef":   read_bits(data, base + 0, 32),
            "firstNameRef":  read_bits(data, base + 32, 32),
            "lastNameCrc":   read_bits(data, base + P_LAST_CRC_BITS, 32),
            "firstNameCrc":  read_bits(data, base + P_FIRST_CRC_BITS, 32),
            "activeTeamSlot": -1,
        })

    # Find team table
    team_start = _find_sequential_table(data, TEAM_TAG_BASE, TEAM_STRIDE_BITS, 4)
    if team_start < 0:
        raise ValueError("TEAMDATA table signature was not found.")

    team_count = _count_sequential_records(data, team_start, TEAM_TAG_BASE,
                                           TEAM_STRIDE_BITS, 1024)
    if team_count < 30:
        raise ValueError("TEAMDATA table too small: %d" % team_count)

    teams = []
    for i in range(30):
        base = team_start + i * TEAM_STRIDE_BITS + 32   # skip tag

        pc = read_bits(data, base + T_TEAM_PLAYER_COUNT_BITS, 8)
        pc = max(0, min(pc, TEAM_PLAYER_REF_COUNT))

        slots = []
        for j in range(pc):
            ref = read_bits(data, base + j * 32, 32)
            slot = ref - PLAYER_TAG_BASE
            if 0 <= slot < player_count:
                slots.append(slot)
                if players[slot]["activeTeamSlot"] < 0:
                    players[slot]["activeTeamSlot"] = i

        teams.append({
            "slot":              i,
            "playerCount":       len(slots),
            "playerSlots":       slots,
            "teamNameRef":       read_bits(data, base + T_TEAM_NAME_REF_BITS, 32),
            "abbreviationRef":   read_bits(data, base + T_TEAM_ABBREV_REF_BITS, 32),
            "cityRef":           read_bits(data, base + T_TEAM_CITY_REF_BITS, 32),
            "displayRef":        read_bits(data, base + T_TEAM_DISPLAY_REF_BITS, 32),
            "teamNameCrc":       read_bits(data, base + T_TEAM_NAME_CRC_BITS, 32),
            "shortNameCrc":      read_bits(data, base + T_TEAM_SHORT_CRC_BITS, 32),
        })

    return {
        "playerTableBitOffset": player_start,
        "teamTableBitOffset":   team_start,
        "players": players,
        "teams":   teams,
    }